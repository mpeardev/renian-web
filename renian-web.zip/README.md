## renian-web

Renian website: National animal identity registry in Peru.

<br />

### Tools:

    Next.js
    Sass

### Run Project:

    yarn
    yarn dev

<br />

_By: MPearDev_
