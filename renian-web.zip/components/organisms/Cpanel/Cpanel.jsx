import React from "react";

export const Cpanel = () => {
  return <div>Cpanel</div>;
};
