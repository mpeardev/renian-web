"use strict";
(() => {
var exports = {};
exports.id = 888;
exports.ids = [888];
exports.modules = {

/***/ 2188:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

// ESM COMPAT FLAG
__webpack_require__.r(__webpack_exports__);

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "default": () => (/* binding */ _app)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
;// CONCATENATED MODULE: external "next/head"
const head_namespaceObject = require("next/head");
var head_default = /*#__PURE__*/__webpack_require__.n(head_namespaceObject);
;// CONCATENATED MODULE: external "web3"
const external_web3_namespaceObject = require("web3");
var external_web3_default = /*#__PURE__*/__webpack_require__.n(external_web3_namespaceObject);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./contexts/Web3/Web3Context.jsx
var Web3Context = __webpack_require__(3918);
;// CONCATENATED MODULE: ./contexts/Web3/Web3Reducer.jsx
const Web3Reducer = (state, action)=>{
    switch(action.type){
        case "provider":
            return {
                ...state,
                wallet: action.payload.web3,
                provider: action.payload.provider,
                providerString: action.payload.providerString
            };
        case "account":
            return {
                ...state,
                account: action.payload
            };
        case "chainId":
            return {
                ...state,
                chainId: action.payload
            };
        case "token":
            return {
                ...state,
                authToken: action.payload.authToken,
                authTimeOut: action.payload.authTimeOut
            };
        default:
            return state;
    }
};

// EXTERNAL MODULE: ./config/index.js + 6 modules
var config = __webpack_require__(8104);
;// CONCATENATED MODULE: ./contexts/Web3/Web3Provider.jsx






const INIT = {
    account: "",
    network: new (external_web3_default())(new (external_web3_default()).providers.HttpProvider(config/* WEB3_NETWORK */.nH)),
    networkWar: new (external_web3_default())(new (external_web3_default()).providers.HttpProvider(config/* WEB3_NETWORKWAR */.iw)),
    wallet: null,
    provider: null,
    providerString: "",
    chainId: null,
    authToken: "",
    authTimeOut: ""
};
const Web3Provider = ({ children  })=>{
    const { 0: state , 1: dispatch  } = (0,external_react_.useReducer)(Web3Reducer, INIT);
    const handleWeb3 = (0,external_react_.useCallback)((provider, providerString)=>{
        dispatch({
            type: "provider",
            payload: {
                web3: provider === null ? null : new (external_web3_default())(provider),
                provider,
                providerString
            }
        });
    }, []);
    const handleAccount = (0,external_react_.useCallback)((account)=>{
        dispatch({
            type: "account",
            payload: account
        });
    }, []);
    const handleChainId = (0,external_react_.useCallback)((chainId)=>{
        dispatch({
            type: "chainId",
            payload: chainId
        });
    }, []);
    const handleToken = (0,external_react_.useCallback)((authToken, authTimeOut)=>{
        dispatch({
            type: "token",
            payload: {
                authToken,
                authTimeOut
            }
        });
    }, []);
    (0,external_react_.useEffect)(()=>{
        const getAccounts = async ()=>await state.wallet?.eth.getAccounts();
        if (state.wallet !== null) {
            getAccounts().then((accounts)=>handleAccount(accounts[0]));
        }
    }, [
        state.wallet,
        handleAccount
    ]);
    (0,external_react_.useEffect)(()=>{
        const getChainId = async ()=>await state.wallet?.eth.getChainId();
        if (state.wallet !== null) {
            getChainId().then((chainId)=>{
                handleChainId(`0x${Number(chainId).toString(16)}`);
            });
        }
    }, [
        state.wallet,
        handleChainId
    ]);
    const web3 = (0,external_react_.useMemo)(()=>state, [
        state
    ]);
    return /*#__PURE__*/ jsx_runtime_.jsx(Web3Context/* Web3Context.Provider */.S.Provider, {
        value: {
            web3,
            handleWeb3,
            handleAccount,
            handleChainId,
            handleToken
        },
        children: children
    });
};

;// CONCATENATED MODULE: ./pages/_app.js




function MyApp({ Component , pageProps  }) {
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)((head_default()), {
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("title", {
                        children: "Renian | Registro Nacional de Identidad Animal"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("meta", {
                        name: "description",
                        content: "Generated by create next app"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        href: "https://cdn.jsdelivr.net/npm/bootstrap@5.2.0/dist/css/bootstrap.min.css",
                        rel: "stylesheet",
                        integrity: "sha384-gH2yIJqKdNHPEq0n4Mqa/HGKIhSkIHeL5AyhkYV8i59U5AR6csBvApHHNl/vI1Bx",
                        crossOrigin: "anonymous"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("link", {
                        rel: "icon",
                        href: "/renian.ico"
                    })
                ]
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Web3Provider, {
                children: /*#__PURE__*/ jsx_runtime_.jsx(Component, {
                    ...pageProps
                })
            })
        ]
    });
}
/* harmony default export */ const _app = (MyApp);


/***/ }),

/***/ 6689:
/***/ ((module) => {

module.exports = require("react");

/***/ }),

/***/ 997:
/***/ ((module) => {

module.exports = require("react/jsx-runtime");

/***/ })

};
;

// load runtime
var __webpack_require__ = require("../webpack-runtime.js");
__webpack_require__.C(exports);
var __webpack_exec__ = (moduleId) => (__webpack_require__(__webpack_require__.s = moduleId))
var __webpack_exports__ = __webpack_require__.X(0, [643], () => (__webpack_exec__(2188)));
module.exports = __webpack_exports__;

})();