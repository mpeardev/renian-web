exports.id = 959;
exports.ids = [959];
exports.modules = {

/***/ 8753:
/***/ ((module) => {

// Exports
module.exports = {
	"modal": "informative_modal___qJy2",
	"modalDialog": "informative_modalDialog__KASg_",
	"flex": "informative_flex__RB_w_",
	"content": "informative_content__I8pUZ"
};


/***/ }),

/***/ 8168:
/***/ ((module) => {

// Exports
module.exports = {
	"wallet": "wallet_wallet__beWa3",
	"session": "wallet_session__UZ7_U",
	"options": "wallet_options__eYy_e",
	"option": "wallet_option__0QuGG",
	"center": "wallet_center__q4k_d"
};


/***/ }),

/***/ 4076:
/***/ ((module) => {

// Exports
module.exports = {
	"containerConnect": "connect-button_containerConnect__u_eap"
};


/***/ }),

/***/ 4598:
/***/ ((module) => {

// Exports
module.exports = {
	"containerButton": "sign_containerButton___ZLd_",
	"designButton": "sign_designButton__f84vK",
	"disabled": "sign_disabled__Ou6lS"
};


/***/ }),

/***/ 1941:
/***/ ((module) => {

// Exports
module.exports = {
	"about": "about_about__3UsIZ",
	"about__container": "about_about__container__UysB3",
	"about__text": "about_about__text__as__z",
	"about__image": "about_about__image__ThCz5",
	"about__card": "about_about__card__CVVvz",
	"about__cardIcon": "about_about__cardIcon__kgNjn",
	"about__cardText": "about_about__cardText__lE2D4"
};


/***/ }),

/***/ 4401:
/***/ ((module) => {

// Exports
module.exports = {
	"advantage": "advantage_advantage__BsCiS",
	"advantage__container": "advantage_advantage__container__O0nTZ",
	"advantage__text": "advantage_advantage__text__zMMQy"
};


/***/ }),

/***/ 4586:
/***/ ((module) => {

// Exports
module.exports = {
	"banner": "banner_banner__h9oWm",
	"banner__slide": "banner_banner__slide__ZHBE0",
	"banner__image": "banner_banner__image__uwywy",
	"banner__description": "banner_banner__description__BLQkW",
	"banner__right": "banner_banner__right__aaLgP",
	"banner__left": "banner_banner__left__T36OU"
};


/***/ }),

/***/ 1407:
/***/ ((module) => {

// Exports
module.exports = {
	"section": "card-section_section__gtZT6",
	"section__container": "card-section_section__container__Fyj0E",
	"section__card": "card-section_section__card__DqGaX",
	"section__cardDeg": "card-section_section__cardDeg__bu1_U",
	"section__cardText": "card-section_section__cardText__eVv2Q",
	"section__cardImage": "card-section_section__cardImage__sbOwN"
};


/***/ }),

/***/ 6424:
/***/ ((module) => {

// Exports
module.exports = {
	"owner": "login-owner_owner__6_QR1",
	"owner__form": "login-owner_owner__form__w3jSe",
	"owner__formBox": "login-owner_owner__formBox__xDdqk",
	"owner__formButton": "login-owner_owner__formButton__RKpsr",
	"owner__decorate": "login-owner_owner__decorate__M19N1"
};


/***/ }),

/***/ 7768:
/***/ ((module) => {

// Exports
module.exports = {
	"microchip": "microchip_microchip__ynej_",
	"microchip__container": "microchip_microchip__container__dbUGh",
	"microchip__description": "microchip_microchip__description__cYm_t",
	"microchip__descriptionImage": "microchip_microchip__descriptionImage__Q69hg",
	"microchip__descriptionText": "microchip_microchip__descriptionText__w4Ydr",
	"microchip__how": "microchip_microchip__how__0FxTk"
};


/***/ }),

/***/ 9742:
/***/ ((module) => {

// Exports
module.exports = {
	"mission": "mission_mission__M8Jmx",
	"mission__container": "mission_mission__container__yBi86",
	"mission__text": "mission_mission__text__E4LJN",
	"mission__image": "mission_mission__image__c7p_g",
	"scale": "mission_scale__oHtBY",
	"mission__bg": "mission_mission__bg__FdGTH"
};


/***/ }),

/***/ 2830:
/***/ ((module) => {

// Exports
module.exports = {
	"play": "play-video_play__Aj4wm",
	"play__container": "play-video_play__container__Sxggu",
	"play__text": "play-video_play__text__8mn5x",
	"play__video": "play-video_play__video__Uvoiy",
	"play__videoPreview": "play-video_play__videoPreview__U_WqT"
};


/***/ }),

/***/ 4052:
/***/ ((module) => {

// Exports
module.exports = {
	"projection": "projection_projection__GR6W8",
	"projection__container": "projection_projection__container__Gfk7S",
	"projection__text": "projection_projection__text__AM_Kq",
	"projection__image": "projection_projection__image__a0uRi",
	"scale": "projection_scale__0KKIq"
};


/***/ }),

/***/ 4908:
/***/ ((module) => {

// Exports
module.exports = {
	"copyright": "copyright_copyright__ep59_",
	"copyright__container": "copyright_copyright__container__N6hYr"
};


/***/ }),

/***/ 4982:
/***/ ((module) => {

// Exports
module.exports = {
	"footer": "footer_footer__n6Zu8",
	"footer__container": "footer_footer__container__Mi_tT",
	"footer__descriptionImage": "footer_footer__descriptionImage__uskMy",
	"footer__description": "footer_footer__description__4XMgZ",
	"footer__contact": "footer_footer__contact__mgfgt"
};


/***/ }),

/***/ 7765:
/***/ ((module) => {

// Exports
module.exports = {
	"contact": "contact-head_contact__aWJ0m",
	"contact__container": "contact-head_contact__container__b1G7a",
	"contact__info": "contact-head_contact__info__gkPzo",
	"contact__networks": "contact-head_contact__networks__PteaO"
};


/***/ }),

/***/ 9986:
/***/ ((module) => {

// Exports
module.exports = {
	"header": "header_header__09iv7",
	"header__container": "header_header__container__HFLOV",
	"header__links": "header_header__links__Hni05",
	"header__login": "header_header__login__KdBPq"
};


/***/ }),

/***/ 6425:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "A": () => (/* binding */ Background)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);

const Background = ({ children  })=>{
    const bg = {
        width: "100%",
        height: "100%",
        backgroundImage: `url("/img/background4.jpg")`,
        backgroundPosition: "left",
        backgroundRepeat: "repeat-y",
        backgroundSize: "cover",
        filter: "blur(1rem)",
        position: "absolute",
        zIndex: "-1"
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        style: {
            position: "relative"
        },
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("main", {
                style: bg
            }),
            children
        ]
    });
};


/***/ }),

/***/ 6959:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$U": () => (/* reexport safe */ _molecules_Mission_Mission__WEBPACK_IMPORTED_MODULE_7__.$),
/* harmony export */   "$_": () => (/* reexport safe */ _organisms_Footer_Footer__WEBPACK_IMPORTED_MODULE_11__.$),
/* harmony export */   "Aq": () => (/* reexport safe */ _atoms_brackground__WEBPACK_IMPORTED_MODULE_0__.A),
/* harmony export */   "CL": () => (/* reexport safe */ _molecules_About_About__WEBPACK_IMPORTED_MODULE_1__.C),
/* harmony export */   "IN": () => (/* reexport safe */ _molecules_Advantage_Advantage__WEBPACK_IMPORTED_MODULE_2__.I),
/* harmony export */   "Q1": () => (/* reexport safe */ _molecules_LoginOwner_LoginOwner__WEBPACK_IMPORTED_MODULE_5__.Q),
/* harmony export */   "QE": () => (/* reexport safe */ _templates_CPanelView__WEBPACK_IMPORTED_MODULE_15__.Q),
/* harmony export */   "dh": () => (/* reexport safe */ _molecules_PlayVideo_PlayVideo__WEBPACK_IMPORTED_MODULE_9__.d),
/* harmony export */   "h4": () => (/* reexport safe */ _organisms_Header_Header__WEBPACK_IMPORTED_MODULE_12__.h),
/* harmony export */   "jL": () => (/* reexport safe */ _molecules_Banner_Banner__WEBPACK_IMPORTED_MODULE_3__.j),
/* harmony export */   "kv": () => (/* reexport safe */ _molecules_Projection_Projection__WEBPACK_IMPORTED_MODULE_10__.k),
/* harmony export */   "mb": () => (/* reexport safe */ _molecules_Microchip_Microchip__WEBPACK_IMPORTED_MODULE_6__.m),
/* harmony export */   "qg": () => (/* reexport safe */ _templates_LoginView__WEBPACK_IMPORTED_MODULE_14__.q),
/* harmony export */   "uO": () => (/* reexport safe */ _molecules_CardSection_CardSection__WEBPACK_IMPORTED_MODULE_4__.u),
/* harmony export */   "ug": () => (/* reexport safe */ _templates_HomeView__WEBPACK_IMPORTED_MODULE_13__.u)
/* harmony export */ });
/* harmony import */ var _atoms_brackground__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6425);
/* harmony import */ var _molecules_About_About__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5168);
/* harmony import */ var _molecules_Advantage_Advantage__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1263);
/* harmony import */ var _molecules_Banner_Banner__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4172);
/* harmony import */ var _molecules_CardSection_CardSection__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(6450);
/* harmony import */ var _molecules_LoginOwner_LoginOwner__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(362);
/* harmony import */ var _molecules_Microchip_Microchip__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9368);
/* harmony import */ var _molecules_Mission_Mission__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(2989);
/* harmony import */ var _molecules_OptionsLogin_OptionsLogin__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(6788);
/* harmony import */ var _molecules_PlayVideo_PlayVideo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(2867);
/* harmony import */ var _molecules_Projection_Projection__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(7330);
/* harmony import */ var _organisms_Footer_Footer__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(4068);
/* harmony import */ var _organisms_Header_Header__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4151);
/* harmony import */ var _templates_HomeView__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4748);
/* harmony import */ var _templates_LoginView__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(9003);
/* harmony import */ var _templates_CPanelView__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(6732);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_molecules_About_About__WEBPACK_IMPORTED_MODULE_1__, _molecules_Banner_Banner__WEBPACK_IMPORTED_MODULE_3__, _molecules_CardSection_CardSection__WEBPACK_IMPORTED_MODULE_4__, _molecules_OptionsLogin_OptionsLogin__WEBPACK_IMPORTED_MODULE_8__, _organisms_Header_Header__WEBPACK_IMPORTED_MODULE_12__, _templates_HomeView__WEBPACK_IMPORTED_MODULE_13__, _templates_LoginView__WEBPACK_IMPORTED_MODULE_14__, _templates_CPanelView__WEBPACK_IMPORTED_MODULE_15__]);
([_molecules_About_About__WEBPACK_IMPORTED_MODULE_1__, _molecules_Banner_Banner__WEBPACK_IMPORTED_MODULE_3__, _molecules_CardSection_CardSection__WEBPACK_IMPORTED_MODULE_4__, _molecules_OptionsLogin_OptionsLogin__WEBPACK_IMPORTED_MODULE_8__, _organisms_Header_Header__WEBPACK_IMPORTED_MODULE_12__, _templates_HomeView__WEBPACK_IMPORTED_MODULE_13__, _templates_LoginView__WEBPACK_IMPORTED_MODULE_14__, _templates_CPanelView__WEBPACK_IMPORTED_MODULE_15__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);
/* -----ATOMS----- */ 
/* -----MOLECULES----- */ 









/* -----ORGANISMS----- */ 

/* -----TEMPLATES----- */ 



__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5168:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "C": () => (/* binding */ About)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _about_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1941);
/* harmony import */ var _about_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_about_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _react_hook_hover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6881);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__]);
_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const About = ()=>{
    const target01 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const target02 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const target03 = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const hover01 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__["default"])(target01);
    const hover02 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__["default"])(target02);
    const hover03 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__["default"])(target03);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__container),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__text),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "\xbfQuienes"
                                }),
                                " somos?"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "RENIAN es una instituci\xf3n que tiene como principal objetivo el REGISTRO NACIONAL DE LOS ANIMALES (considerando a los animales dom\xe9sticos y no dom\xe9sticos ), que se ejecuta bajo un sistema de plataforma interinstitucional unificada de nombre “SRM”. RENIAN trabaja dentro del marco de Pol\xedticas P\xfablicas de Protecci\xf3n y Bienestar Animal Nacional e Internacional y se encuentra incluido dentro de varios proyectos nacionales priorizados por los Ministerios de Agricultura y de Salud."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__card),
                                    ref: target01,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__cardIcon),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/cqqydgge.json",
                                                trigger: hover01 ? "loop" : "none",
                                                colors: hover01 ? "primary:#000000,secondary:#dd0000" : "primary:#606060,secondary:#606060",
                                                style: {
                                                    width: "80px",
                                                    height: "80px"
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__cardText),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    children: "30k+"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    style: {
                                                        color: hover01 ? "#212121" : "#757575"
                                                    },
                                                    children: "Mascotas Registradas"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__card),
                                    ref: target02,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__cardIcon),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/tnfwimua.json",
                                                trigger: hover02 ? "loop" : "none",
                                                colors: hover02 ? "primary:#000000,secondary:#dd0000" : "primary:#606060,secondary:#606060",
                                                style: {
                                                    width: "80px",
                                                    height: "80px"
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__cardText),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    children: "325+"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    style: {
                                                        color: hover02 ? "#212121" : "#757575"
                                                    },
                                                    children: "Veterinarias Afiliadas"
                                                })
                                            ]
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__card),
                                    ref: target03,
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__cardIcon),
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/mxuuhaan.json",
                                                trigger: hover03 ? "loop" : "none",
                                                colors: hover03 ? "primary:#000000,secondary:#dd0000" : "primary:#606060,secondary:#606060",
                                                style: {
                                                    width: "80px",
                                                    height: "80px"
                                                }
                                            })
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__cardText),
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h2", {
                                                    children: "15+"
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    style: {
                                                        color: hover03 ? "#212121" : "#757575"
                                                    },
                                                    children: "Municipalidades"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_about_module_scss__WEBPACK_IMPORTED_MODULE_4___default().about__image),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_3___default()), {
                        src: "/img/about-image.png",
                        layout: "responsive",
                        width: 28,
                        height: 28,
                        alt: "image"
                    })
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 1263:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "I": () => (/* binding */ Advantage)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _advantage_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4401);
/* harmony import */ var _advantage_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_advantage_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const Advantage = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_advantage_module_scss__WEBPACK_IMPORTED_MODULE_3___default().advantage),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_advantage_module_scss__WEBPACK_IMPORTED_MODULE_3___default().advantage__container),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_advantage_module_scss__WEBPACK_IMPORTED_MODULE_3___default().advantage__image),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "/img/advantage-image.jpg",
                        layout: "responsive",
                        width: 40,
                        height: 40,
                        alt: "image"
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_advantage_module_scss__WEBPACK_IMPORTED_MODULE_3___default().advantage__text),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                            children: "Conoce las ventajas de los"
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Animales"
                                }),
                                " registrados"
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                            src: "https://cdn.lordicon.com/euyxudqt.json",
                                            trigger: "loop",
                                            colors: "primary:#000000,secondary:#dd0000",
                                            style: {
                                                width: "55px",
                                                height: "55px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Identidad unica del animal de por vida"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                            src: "https://cdn.lordicon.com/euyxudqt.json",
                                            trigger: "loop",
                                            colors: "primary:#000000,secondary:#dd0000",
                                            style: {
                                                width: "55px",
                                                height: "55px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Conocer al propietario legal"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                            src: "https://cdn.lordicon.com/euyxudqt.json",
                                            trigger: "loop",
                                            colors: "primary:#000000,secondary:#dd0000",
                                            style: {
                                                width: "55px",
                                                height: "55px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Conocer las catacteristicas del animal"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                            src: "https://cdn.lordicon.com/euyxudqt.json",
                                            trigger: "loop",
                                            colors: "primary:#000000,secondary:#dd0000",
                                            style: {
                                                width: "55px",
                                                height: "55px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Recuperar animales perdidos o robados"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("li", {
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                            src: "https://cdn.lordicon.com/euyxudqt.json",
                                            trigger: "loop",
                                            colors: "primary:#000000,secondary:#dd0000",
                                            style: {
                                                width: "55px",
                                                height: "55px"
                                            }
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            children: "Controles sanitarios y ficha clinica"
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 4172:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "j": () => (/* binding */ Banner)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _banner_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(4586);
/* harmony import */ var _banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_banner_module_scss__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var swiper_react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3015);
/* harmony import */ var swiper__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3877);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_5__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__]);
([swiper_react__WEBPACK_IMPORTED_MODULE_2__, swiper__WEBPACK_IMPORTED_MODULE_3__] = __webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__);



// import "swiper/css/bundle";







const Banner = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_5__.useRouter)();
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
            className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner),
            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(swiper_react__WEBPACK_IMPORTED_MODULE_2__.Swiper, {
                slidesPerView: 1,
                loop: true,
                centeredSlides: true,
                autoplay: {
                    delay: 5000,
                    disableOnInteraction: false
                },
                // navigation={true}
                modules: [
                    swiper__WEBPACK_IMPORTED_MODULE_3__.Autoplay,
                    swiper__WEBPACK_IMPORTED_MODULE_3__.Navigation
                ],
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__slide),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__image),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        src: "/img/pets/6.jpg",
                                        layout: "fill",
                                        priority: "true",
                                        alt: "image"
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__description),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__right),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                children: "Al servicio del cuidado de las mascotas"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                children: [
                                                    "Nunca fue tan facil ser parte de esta comunidad",
                                                    " ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "RENIAN"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: ()=>router.push("/contact"),
                                                    children: "Contactanos"
                                                })
                                            })
                                        ]
                                    })
                                })
                            ]
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(swiper_react__WEBPACK_IMPORTED_MODULE_2__.SwiperSlide, {
                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__slide),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__description),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__left),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h5", {
                                                children: "Al servicio del cuidado de las mascotas"
                                            }),
                                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h1", {
                                                children: [
                                                    "Ellos tambien tienen derechos a una identificacion, protejamoslos. ",
                                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                        children: "(Ley 30407)"
                                                    })
                                                ]
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                                    onClick: ()=>router.push("/contact"),
                                                    children: "Contactanos"
                                                })
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_banner_module_scss__WEBPACK_IMPORTED_MODULE_6___default().banner__image),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_4___default()), {
                                        src: "/img/pets/8.jpg",
                                        layout: "fill",
                                        priority: "true",
                                        alt: "image"
                                    })
                                })
                            ]
                        })
                    })
                ]
            })
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6450:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ CardSection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _react_hook_hover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6881);
/* harmony import */ var _card_section_module_scss__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(1407);
/* harmony import */ var _card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__]);
_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const CardSection = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const target01 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const target02 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const target03 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const target04 = (0,react__WEBPACK_IMPORTED_MODULE_2__.useRef)(null);
    const hover01 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(target01);
    const hover02 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(target02);
    const hover03 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(target03);
    const hover04 = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(target04);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__container),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h3", {
                    children: "Explora nuestras opciones"
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__card),
                            ref: target01,
                            onClick: ()=>router.push("/owner"),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardDeg),
                                    style: hover01 ? {
                                        display: "block"
                                    } : {
                                        display: "none"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/zniqnylq.json",
                                                trigger: "loop",
                                                colors: "primary:#f5f5f5,secondary:#f5f5f5",
                                                style: {
                                                    width: "120px",
                                                    height: "120px"
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "Consultar"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardText),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Consulta"
                                            }),
                                            " el registro de tu mascota"
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardImage),
                                    style: hover01 ? {
                                        filter: "opacity(0.3)"
                                    } : {
                                        filter: "none"
                                    },
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: "/img/cards/1.jpg",
                                        layout: "fill",
                                        priority: true,
                                        alt: "image"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__card),
                            ref: target02,
                            onClick: ()=>router.push("/owner/registry"),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardDeg),
                                    style: hover02 ? {
                                        display: "block"
                                    } : {
                                        display: "none"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/hiqmdfkt.json",
                                                trigger: "loop",
                                                colors: "primary:#f5f5f5,secondary:#f5f5f5",
                                                style: {
                                                    width: "120px",
                                                    height: "120px"
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "Registrar"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardText),
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "Registra"
                                            }),
                                            " a tu mascota en ",
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                children: "RENIAN"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardImage),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: "/img/cards/2.jpg",
                                        layout: "fill",
                                        priority: true,
                                        alt: "image",
                                        style: hover02 ? {
                                            filter: "opacity(0.3)"
                                        } : {
                                            filter: "none"
                                        }
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__card),
                            ref: target03,
                            onClick: ()=>router.push("/cpanel"),
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardDeg),
                                    style: hover03 ? {
                                        display: "block"
                                    } : {
                                        display: "none"
                                    },
                                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/wnnosluj.json",
                                                trigger: "loop",
                                                colors: "primary:#f5f5f5,secondary:#f5f5f5",
                                                style: {
                                                    width: "120px",
                                                    height: "120px"
                                                }
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                children: "Ingresar"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardText),
                                    children: [
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "Ingresa"
                                                }),
                                                " a nuestra ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "Intranet"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                            children: "(Centros veterinarios e instituciones)"
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                    className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardImage),
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                        src: "/img/cards/3.jpg",
                                        layout: "fill",
                                        priority: true,
                                        alt: "image",
                                        style: hover03 ? {
                                            filter: "opacity(0.3)"
                                        } : {
                                            filter: "none"
                                        }
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "https://firulaixcoin.finance/war-office",
                            target: "_blank",
                            rel: "noreferrer noopener",
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__card),
                                ref: target04,
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardDeg),
                                        style: hover04 ? {
                                            display: "block"
                                        } : {
                                            display: "none"
                                        },
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                    src: "https://cdn.lordicon.com/zniqnylq.json",
                                                    trigger: "loop",
                                                    colors: "primary:#f5f5f5,secondary:#f5f5f5",
                                                    style: {
                                                        width: "120px",
                                                        height: "120px"
                                                    }
                                                }),
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                                    children: "Consultar"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardText),
                                        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h3", {
                                            children: [
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "Consulta"
                                                }),
                                                " el registro en ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "WAR"
                                                })
                                            ]
                                        })
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                        className: (_card_section_module_scss__WEBPACK_IMPORTED_MODULE_5___default().section__cardImage),
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                            src: "/img/cards/4.jpg",
                                            layout: "fill",
                                            priority: true,
                                            alt: "image",
                                            style: hover04 ? {
                                                filter: "opacity(0.3)"
                                            } : {
                                                filter: "none"
                                            }
                                        })
                                    })
                                ]
                            })
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 362:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* binding */ LoginOwner)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/molecules/LoginOwner/login-owner.module.scss
var login_owner_module = __webpack_require__(6424);
var login_owner_module_default = /*#__PURE__*/__webpack_require__.n(login_owner_module);
// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./node_modules/next/link.js
var next_link = __webpack_require__(1664);
// EXTERNAL MODULE: ./components/atoms/ConnectButton/connect-button.module.scss
var connect_button_module = __webpack_require__(4076);
var connect_button_module_default = /*#__PURE__*/__webpack_require__.n(connect_button_module);
// EXTERNAL MODULE: ./components/atoms/Wallet/wallet.module.css
var wallet_module = __webpack_require__(8168);
var wallet_module_default = /*#__PURE__*/__webpack_require__.n(wallet_module);
// EXTERNAL MODULE: ./components/atoms/Modal/Informative/informative.module.css
var informative_module = __webpack_require__(8753);
var informative_module_default = /*#__PURE__*/__webpack_require__.n(informative_module);
;// CONCATENATED MODULE: ./components/atoms/Modal/Informative/Informative.jsx


const Informative_Informative = ({ children , w =0 , transparent =false , handleClose ,  })=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
        className: (informative_module_default()).modal,
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (informative_module_default()).modalDialog,
                onClick: handleClose
            }),
            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                className: (informative_module_default()).flex,
                children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
                    className: (informative_module_default()).content,
                    style: {
                        background: `${transparent ? "transparent" : "#fff"}`
                    },
                    children: children
                })
            })
        ]
    });
};

// EXTERNAL MODULE: ./contexts/Web3/Web3Context.jsx
var Web3_Web3Context = __webpack_require__(3918);
// EXTERNAL MODULE: ./utils/web3.js + 1 modules
var web3 = __webpack_require__(7464);
;// CONCATENATED MODULE: ./components/atoms/Wallet/Connect.jsx







const Connect = ({ handleClose  })=>{
    const { handleWeb3  } = (0,external_react_.useContext)(Web3_Web3Context/* Web3Context */.S);
    const validate = async (providerString)=>{
        (0,web3/* web3Provider */.r)(handleWeb3, providerString);
        handleClose();
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(Informative_Informative, {
        handleClose: handleClose,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("h4", {
                    children: "Connect"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Al conectar una billetera, acepta los T\xe9rminos de servicio de Firulaix Labs y reconoce que ha le\xeddo y entendido el Protocolo de exenci\xf3n de responsabilidad."
                }),
                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (wallet_module_default()).wallet,
                    onClick: ()=>validate("metamask"),
                    children: [
                        "Metamask",
                        /*#__PURE__*/ jsx_runtime_.jsx("div", {
                            style: {
                                width: "3rem"
                            },
                            children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                src: "/svg/metamask-logo.svg",
                                layout: "responsive",
                                width: 30,
                                height: 30,
                                alt: "image"
                            })
                        })
                    ]
                })
            ]
        })
    });
};

;// CONCATENATED MODULE: ./components/atoms/Wallet/Session.jsx





const Session = ({ handleClose  })=>{
    const { web3 , handleAccount , handleWeb3  } = useContext(Web3Context);
    // const { message } = useToast();
    const logout = async ()=>{
        try {
            if (web3.providerString === "walletconnect") {
                await web3.provider.disconnect();
            }
            handleWeb3(null, null);
            handleAccount("");
            handleClose();
        } catch (error) {
            console.log(error);
        }
    };
    const copy = ()=>{
        navigator.clipboard.writeText(web3.account ?? "");
    // message("success", "firuTower.firstFloor.faq.modal.notify");
    };
    return /*#__PURE__*/ _jsxs(Informative, {
        handleClose: handleClose,
        children: [
            /*#__PURE__*/ _jsx("h5", {
                children: "Sesion"
            }),
            /*#__PURE__*/ _jsx("hr", {}),
            /*#__PURE__*/ _jsxs("div", {
                children: [
                    /*#__PURE__*/ _jsx("p", {
                        className: classes.center,
                        children: web3.account
                    }),
                    /*#__PURE__*/ _jsxs("div", {
                        className: classes.options,
                        children: [
                            /*#__PURE__*/ _jsx("a", {
                                className: classes.option,
                                href: "https://blockscout.moonriver.moonbeam.network/address/0x2FBE6b6F1e3e2EFC69495F0c380A01c003e47225/transactions",
                                target: "_blank",
                                rel: "noreferrer noopener",
                                children: "Scan"
                            }),
                            /*#__PURE__*/ _jsx("div", {
                                className: classes.option,
                                onClick: copy,
                                style: {
                                    cursor: "pointer"
                                },
                                children: "Copy"
                            })
                        ]
                    }),
                    /*#__PURE__*/ _jsx("div", {
                        className: classes.center,
                        onClick: logout,
                        children: /*#__PURE__*/ _jsx("button", {
                            children: "Logout"
                        })
                    })
                ]
            })
        ]
    });
};

;// CONCATENATED MODULE: ./components/atoms/ConnectButton/ConnectButton.jsx







const ConnectButton = ({ open , setOpen  })=>{
    const { web3  } = (0,external_react_.useContext)(Web3_Web3Context/* Web3Context */.S);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (connect_button_module_default()).containerConnect,
                onClick: ()=>setOpen(true),
                children: [
                    web3.account && `${web3.account.substring(0, 10)}...`,
                    !web3.account && /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        style: {
                            display: "flex",
                            alignItems: "center",
                            justifyContent: "center"
                        },
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                style: {
                                    width: "3rem"
                                },
                                children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                    src: "/svg/metamask-logo.svg",
                                    layout: "responsive",
                                    width: 30,
                                    height: 30,
                                    style: {
                                        opacity: "10"
                                    },
                                    alt: "image"
                                })
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                style: {
                                    margin: "0"
                                },
                                children: "Metamask"
                            })
                        ]
                    })
                ]
            }),
            open && !web3.account && /*#__PURE__*/ jsx_runtime_.jsx(Connect, {
                handleClose: ()=>setOpen(false)
            })
        ]
    });
};

// EXTERNAL MODULE: ./components/atoms/Sign/sign.module.scss
var sign_module = __webpack_require__(4598);
var sign_module_default = /*#__PURE__*/__webpack_require__.n(sign_module);
// EXTERNAL MODULE: ./utils/war/auth.js
var auth = __webpack_require__(2858);
// EXTERNAL MODULE: external "next/router"
var router_ = __webpack_require__(1853);
;// CONCATENATED MODULE: ./components/atoms/Sign/Sign.jsx






const Sign = ()=>{
    const { web3 , handleToken  } = (0,external_react_.useContext)(Web3_Web3Context/* Web3Context */.S);
    // const { handlePreloader } = useContext(PreloaderContext);
    const router = (0,router_.useRouter)();
    const handleClick = ()=>{
        // handlePreloader(true);
        (0,auth/* handleUser */.Eu)(web3.account).then((resolve)=>{
            if (String(resolve?.user.publicAddress).toUpperCase() === String(web3.account).toUpperCase()) {
                (0,auth/* handleSignMessage */.jD)(web3.wallet, resolve?.user.publicAddress, resolve?.user.nonce).then((resolve2)=>{
                    (0,auth/* handleAuthenticate */.im)(resolve?.user.publicAddress, resolve2, handleToken).then(()=>{
                        router.push("/cpanel");
                    });
                // handlePreloader(false);
                }).catch((e)=>{
                    console.log(e);
                // handlePreloader(false);
                });
            } else {
            // message("danger", "app.errorPost.sign");
            // handlePreloader(false);
            }
        }).catch((e)=>{
            alert("Primero Inicia seccion con Metamask");
        // message("danger", "app.errorPost.sign");
        // handlePreloader(false);
        });
    };
    return /*#__PURE__*/ jsx_runtime_.jsx(jsx_runtime_.Fragment, {
        children: /*#__PURE__*/ jsx_runtime_.jsx("div", {
            className: (sign_module_default()).containerButton,
            children: /*#__PURE__*/ jsx_runtime_.jsx("button", {
                className: (sign_module_default()).designButton,
                onClick: handleClick,
                children: /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Registrar"
                })
            })
        })
    });
};

;// CONCATENATED MODULE: ./components/molecules/LoginOwner/LoginOwner.jsx







const LoginOwner = ()=>{
    const { 0: open , 1: setOpen  } = (0,external_react_.useState)(false);
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)("section", {
        className: (login_owner_module_default()).owner,
        children: [
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (login_owner_module_default()).owner__form,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                        children: "Ingresar"
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("h6", {
                        children: "Bienvenido! Porfavor ingrese sus datos."
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("main", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (login_owner_module_default()).owner__formBox,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        children: "Usuario"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "text",
                                        placeholder: "Usuario"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                                className: (login_owner_module_default()).owner__formBox,
                                children: [
                                    /*#__PURE__*/ jsx_runtime_.jsx("h5", {
                                        children: "Contrase\xf1a"
                                    }),
                                    /*#__PURE__*/ jsx_runtime_.jsx("input", {
                                        type: "password",
                                        placeholder: "••••••••"
                                    })
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                className: (login_owner_module_default()).owner__formButton,
                                children: /*#__PURE__*/ jsx_runtime_.jsx("button", {})
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                style: {
                                    color: "black"
                                },
                                children: "Inicia sesion con:"
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(ConnectButton, {
                                setOpen: setOpen,
                                open: open
                            })
                        ]
                    })
                ]
            }),
            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                className: (login_owner_module_default()).owner__decorate,
                children: [
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/svg/war-logo.svg",
                            layout: "responsive",
                            width: 50,
                            height: 50,
                            alt: "fb-icon"
                        })
                    }),
                    /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                        children: [
                            /*#__PURE__*/ (0,jsx_runtime_.jsxs)("p", {
                                children: [
                                    "*Solo para entidades registradoras",
                                    " "
                                ]
                            }),
                            /*#__PURE__*/ jsx_runtime_.jsx(Sign, {})
                        ]
                    }),
                    /*#__PURE__*/ jsx_runtime_.jsx("span", {
                        children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                            src: "/svg/renian-logo.svg",
                            layout: "responsive",
                            width: 160,
                            height: 50,
                            alt: "renian-logo",
                            priority: true
                        })
                    })
                ]
            })
        ]
    });
};


/***/ }),

/***/ 9368:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "m": () => (/* binding */ Microchip)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _microchip_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7768);
/* harmony import */ var _microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Microchip = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default().microchip),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default().microchip__container),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default().microchip__description),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            children: [
                                "\xbfQue es un ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "Microchip?"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Es un dispositivo de identificacion animal."
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("ul", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: "Es biocompatible"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: "Es del tama\xf1o de un grano de arroz"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: "Va debajo de la piel del animal"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: "Es pasivo (no emite se\xf1al alguna)"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("li", {
                                    children: "Es de por vida"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default().microchip__descriptionImage),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                            src: "/img/microchip-null.png",
                                            layout: "responsive",
                                            width: 10,
                                            height: 10,
                                            alt: "image"
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/uypveeyg.json",
                                                trigger: "loop",
                                                colors: "primary:#606060,secondary:#606060",
                                                style: {
                                                    width: "150px",
                                                    height: "150px"
                                                }
                                            })
                                        })
                                    ]
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    className: (_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default().microchip__descriptionText),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("h4", {
                                            children: "\xa1IMPORTANTE!"
                                        }),
                                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                                            children: [
                                                "El microchip ",
                                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                                    children: "no es un dispositivo GPS."
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_microchip_module_scss__WEBPACK_IMPORTED_MODULE_3___default().microchip__how),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "\xbfComo"
                                }),
                                " funciona el Registro?"
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/img/microchip-how.png",
                                layout: "responsive",
                                width: 60,
                                height: 29,
                                alt: "image"
                            })
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 2989:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ Mission)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mission_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(9742);
/* harmony import */ var _mission_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mission_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);




const Mission = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
        className: (_mission_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mission),
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                className: (_mission_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mission__container),
                children: [
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: (_mission_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mission__text),
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                        children: "Nuestra"
                                    }),
                                    " Misi\xf3n"
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                children: "Reducir significativamente la poblaci\xf3n de animales callejeros y en abandono, adem\xe1s de llevar un monitoreo constante de su estado de salud, promoviendo de esta manera una cultura de tenencia responsable."
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: (_mission_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mission__image),
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/img/mission/our.png",
                                layout: "responsive",
                                width: 120,
                                height: 50,
                                alt: "image"
                            })
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: (_mission_module_scss__WEBPACK_IMPORTED_MODULE_3___default().mission__bg),
                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                    src: "/img/footer-dogs.png",
                    layout: "responsive",
                    width: 120,
                    height: 28,
                    priority: "true",
                    alt: "image"
                })
            })
        ]
    });
};


/***/ }),

/***/ 6788:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* unused harmony export OptionsLogin */
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _react_hook_hover__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6881);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__]);
_react_hook_hover__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];






const OptionsLogin = ()=>{
    const router = useRouter();
    const target01 = useRef(null);
    const target02 = useRef(null);
    const hover01 = useHover(target01);
    const hover02 = useHover(target02);
    return /*#__PURE__*/ _jsx("section", {
        className: classes.options,
        children: /*#__PURE__*/ _jsxs("div", {
            className: classes.options__container,
            children: [
                /*#__PURE__*/ _jsx("h5", {
                    children: "Login"
                }),
                /*#__PURE__*/ _jsxs("h3", {
                    children: [
                        "Selecciona una ",
                        /*#__PURE__*/ _jsx("span", {
                            children: "opcion para ingresar"
                        })
                    ]
                }),
                /*#__PURE__*/ _jsxs("div", {
                    children: [
                        /*#__PURE__*/ _jsxs("div", {
                            className: classes.options__card,
                            ref: target01,
                            onClick: ()=>router.push("/login/owner"),
                            children: [
                                /*#__PURE__*/ _jsx("div", {
                                    className: classes.options__cardDeg,
                                    style: hover01 ? {
                                        display: "block"
                                    } : {
                                        display: "none"
                                    },
                                    children: /*#__PURE__*/ _jsxs("div", {
                                        children: [
                                            /*#__PURE__*/ _jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/wnnosluj.json",
                                                trigger: "loop",
                                                colors: "primary:#f5f5f5,secondary:#f5f5f5",
                                                style: {
                                                    width: "120px",
                                                    height: "120px"
                                                }
                                            }),
                                            /*#__PURE__*/ _jsx("p", {
                                                children: "Ingresar"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ _jsx("div", {
                                    className: classes.options__cardText,
                                    children: /*#__PURE__*/ _jsx("h3", {
                                        children: "Due\xf1o/a de mascota registrada"
                                    })
                                }),
                                /*#__PURE__*/ _jsx("div", {
                                    className: classes.options__cardImage,
                                    style: hover01 ? {
                                        filter: "opacity(0.3)"
                                    } : {
                                        filter: "none"
                                    },
                                    children: /*#__PURE__*/ _jsx(Image, {
                                        src: "/img/option-owner.png",
                                        layout: "fill",
                                        alt: "image"
                                    })
                                })
                            ]
                        }),
                        /*#__PURE__*/ _jsxs("div", {
                            className: classes.options__card,
                            ref: target02,
                            onClick: ()=>router.push("/cpanel"),
                            children: [
                                /*#__PURE__*/ _jsx("div", {
                                    className: classes.options__cardDeg,
                                    style: hover02 ? {
                                        display: "block"
                                    } : {
                                        display: "none"
                                    },
                                    children: /*#__PURE__*/ _jsxs("div", {
                                        children: [
                                            /*#__PURE__*/ _jsx("lord-icon", {
                                                src: "https://cdn.lordicon.com/wnnosluj.json",
                                                trigger: "loop",
                                                colors: "primary:#f5f5f5,secondary:#f5f5f5",
                                                style: {
                                                    width: "120px",
                                                    height: "120px"
                                                }
                                            }),
                                            /*#__PURE__*/ _jsx("p", {
                                                children: "Ingresar"
                                            })
                                        ]
                                    })
                                }),
                                /*#__PURE__*/ _jsx("div", {
                                    className: classes.options__cardText,
                                    children: /*#__PURE__*/ _jsx("h3", {
                                        children: "Entidades registradoras e instituciones"
                                    })
                                }),
                                /*#__PURE__*/ _jsx("div", {
                                    className: classes.options__cardImage,
                                    children: /*#__PURE__*/ _jsx(Image, {
                                        src: "/img/option-register.png",
                                        layout: "fill",
                                        alt: "image",
                                        style: hover02 ? {
                                            filter: "opacity(0.3)"
                                        } : {
                                            filter: "none"
                                        }
                                    })
                                })
                            ]
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 2867:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "d": () => (/* binding */ PlayVideo)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _play_video_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(2830);
/* harmony import */ var _play_video_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_play_video_module_scss__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var react_player_lazy__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(782);
/* harmony import */ var react_player_lazy__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react_player_lazy__WEBPACK_IMPORTED_MODULE_2__);




const PlayVideo = ()=>{
    const { 0: state , 1: setState  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)(false);
    const { 0: stylesButton , 1: setStylesButton  } = (0,react__WEBPACK_IMPORTED_MODULE_1__.useState)({
        background: "auto",
        color: "auto",
        border: "auto"
    });
    const openVideo = ()=>{
        setState(true);
        setStylesButton(null);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_play_video_module_scss__WEBPACK_IMPORTED_MODULE_3___default().play),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_play_video_module_scss__WEBPACK_IMPORTED_MODULE_3___default().play__container),
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_play_video_module_scss__WEBPACK_IMPORTED_MODULE_3___default().play__text),
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("p", {
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "RENIAN"
                            }),
                            " permite identificar, registrar y realizar un seguimiento a los animales de compa\xf1\xeda y no de compa\xf1\xeda que habitan en cualquier ciudad del Per\xfa, esto mediante el",
                            " ",
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                children: "implante de un microchip de identificaci\xf3n animal de standard mundial."
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_play_video_module_scss__WEBPACK_IMPORTED_MODULE_3___default().play__video),
                    children: [
                        stylesButton && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            onClick: openVideo,
                            style: stylesButton,
                            className: (_play_video_module_scss__WEBPACK_IMPORTED_MODULE_3___default().play__videoPreview),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                src: "https://cdn.lordicon.com/ujphzprf.json",
                                trigger: "hover",
                                colors: "primary:#000000,secondary:#dd0000",
                                style: {
                                    width: "75px",
                                    height: "75px"
                                }
                            })
                        }),
                        state === true && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_player_lazy__WEBPACK_IMPORTED_MODULE_2___default()), {
                            url: "https://www.youtube.com/watch?v=W-yP0CYFSaU&feature=emb_title"
                        })
                    ]
                })
            ]
        })
    });
};


/***/ }),

/***/ 7330:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "k": () => (/* binding */ Projection)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _projection_module_scss__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4052);
/* harmony import */ var _projection_module_scss__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_projection_module_scss__WEBPACK_IMPORTED_MODULE_3__);




const Projection = ()=>{
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("section", {
        className: (_projection_module_scss__WEBPACK_IMPORTED_MODULE_3___default().projection),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
            className: (_projection_module_scss__WEBPACK_IMPORTED_MODULE_3___default().projection__container),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_projection_module_scss__WEBPACK_IMPORTED_MODULE_3___default().projection__text),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("h2", {
                            children: [
                                "Proyeccion a ",
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("span", {
                                    children: "mediano y largo plazo"
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                            children: "Sin un control adecuado de la poblacion de animales domesticos esto podria llegar a ser una realidad."
                        })
                    ]
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                    className: (_projection_module_scss__WEBPACK_IMPORTED_MODULE_3___default().projection__image),
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                        src: "/img/mission/projection.png",
                        layout: "responsive",
                        width: 120,
                        height: 60,
                        alt: "image"
                    })
                })
            ]
        })
    });
};


/***/ }),

/***/ 5846:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ Dashboard)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(8442);
/* harmony import */ var _mui_material_styles__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(4960);
/* harmony import */ var _mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7898);
/* harmony import */ var _mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(19);
/* harmony import */ var _mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Box__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3882);
/* harmony import */ var _mui_material_AppBar__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(1431);
/* harmony import */ var _mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(4192);
/* harmony import */ var _mui_material_List__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_material_List__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(3646);
/* harmony import */ var _mui_material_Divider__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Divider__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(7934);
/* harmony import */ var _mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11__);
/* harmony import */ var _mui_material_Badge__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(283);
/* harmony import */ var _mui_material_Badge__WEBPACK_IMPORTED_MODULE_12___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Badge__WEBPACK_IMPORTED_MODULE_12__);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_13__ = __webpack_require__(4475);
/* harmony import */ var _mui_material_Container__WEBPACK_IMPORTED_MODULE_13___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Container__WEBPACK_IMPORTED_MODULE_13__);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_14__ = __webpack_require__(5612);
/* harmony import */ var _mui_material_Grid__WEBPACK_IMPORTED_MODULE_14___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Grid__WEBPACK_IMPORTED_MODULE_14__);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_15__ = __webpack_require__(1168);
/* harmony import */ var _mui_material_Paper__WEBPACK_IMPORTED_MODULE_15___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Paper__WEBPACK_IMPORTED_MODULE_15__);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_16__ = __webpack_require__(5246);
/* harmony import */ var _mui_material_Link__WEBPACK_IMPORTED_MODULE_16___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Link__WEBPACK_IMPORTED_MODULE_16__);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_17__ = __webpack_require__(3365);
/* harmony import */ var _mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_17___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_17__);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_18__ = __webpack_require__(142);
/* harmony import */ var _mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_18___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_18__);
/* harmony import */ var _mui_icons_material_Notifications__WEBPACK_IMPORTED_MODULE_19__ = __webpack_require__(1567);
/* harmony import */ var _mui_icons_material_Notifications__WEBPACK_IMPORTED_MODULE_19___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Notifications__WEBPACK_IMPORTED_MODULE_19__);
/* harmony import */ var _listItems__WEBPACK_IMPORTED_MODULE_20__ = __webpack_require__(3550);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_21__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_21___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_21__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_22__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_22___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_22__);
/* harmony import */ var _mui_icons_material_ExitToApp__WEBPACK_IMPORTED_MODULE_23__ = __webpack_require__(3773);
/* harmony import */ var _mui_icons_material_ExitToApp__WEBPACK_IMPORTED_MODULE_23___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_ExitToApp__WEBPACK_IMPORTED_MODULE_23__);
/* harmony import */ var _mui_icons_material_MoreVert__WEBPACK_IMPORTED_MODULE_24__ = __webpack_require__(6952);
/* harmony import */ var _mui_icons_material_MoreVert__WEBPACK_IMPORTED_MODULE_24___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_MoreVert__WEBPACK_IMPORTED_MODULE_24__);
/* harmony import */ var _FormNewUser__WEBPACK_IMPORTED_MODULE_25__ = __webpack_require__(6611);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_26__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_26___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_26__);
/* harmony import */ var _utils_war_auth__WEBPACK_IMPORTED_MODULE_27__ = __webpack_require__(2858);
/* harmony import */ var _contexts_Web3_Web3Context__WEBPACK_IMPORTED_MODULE_28__ = __webpack_require__(3918);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_FormNewUser__WEBPACK_IMPORTED_MODULE_25__]);
_FormNewUser__WEBPACK_IMPORTED_MODULE_25__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





























function Copyright(props) {
    return /*#__PURE__*/ _jsxs(Typography, {
        variant: "body2",
        color: "text.secondary",
        align: "center",
        ...props,
        children: [
            "Copyright \xa9",
            /*#__PURE__*/ _jsx(Link, {
                color: "inherit",
                href: "https://mui.com/",
                children: "Your Website"
            }),
            " ",
            new Date().getFullYear(),
            "."
        ]
    });
}
const drawerWidth = 240;
const AppBar = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_AppBar__WEBPACK_IMPORTED_MODULE_6___default()), {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        zIndex: theme.zIndex.drawer + 1,
        transition: theme.transitions.create([
            "width",
            "margin"
        ], {
            easing: theme.transitions.easing.sharp,
            duration: theme.transitions.duration.leavingScreen
        }),
        ...open && {
            marginLeft: drawerWidth,
            width: `calc(100% - ${drawerWidth}px)`,
            transition: theme.transitions.create([
                "width",
                "margin"
            ], {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            })
        }
    }));
const Drawer = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.styled)((_mui_material_Drawer__WEBPACK_IMPORTED_MODULE_4___default()), {
    shouldForwardProp: (prop)=>prop !== "open"
})(({ theme , open  })=>({
        "& .MuiDrawer-paper": {
            position: "relative",
            whiteSpace: "nowrap",
            width: drawerWidth,
            transition: theme.transitions.create("width", {
                easing: theme.transitions.easing.sharp,
                duration: theme.transitions.duration.enteringScreen
            }),
            boxSizing: "border-box",
            ...!open && {
                overflowX: "hidden",
                transition: theme.transitions.create("width", {
                    easing: theme.transitions.easing.sharp,
                    duration: theme.transitions.duration.leavingScreen
                }),
                width: theme.spacing(7),
                [theme.breakpoints.up("sm")]: {
                    width: theme.spacing(9)
                }
            }
        }
    }));
const mdTheme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.createTheme)();
const darkTheme = (0,_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.createTheme)({
    palette: {
        // mode: "dark",
        primary: {
            main: "#0096A4"
        }
    }
});
const DashboardContent = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_26__.useRouter)();
    const { web3 , handleWeb3 , handleToken , handleAccount  } = react__WEBPACK_IMPORTED_MODULE_1__.useContext(_contexts_Web3_Web3Context__WEBPACK_IMPORTED_MODULE_28__/* .Web3Context */ .S);
    const [open, setOpen] = react__WEBPACK_IMPORTED_MODULE_1__.useState(true);
    const toggleDrawer = ()=>{
        setOpen(!open);
    };
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material_styles__WEBPACK_IMPORTED_MODULE_2__.ThemeProvider, {
        theme: darkTheme,
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
            sx: {
                display: "flex"
            },
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_CssBaseline__WEBPACK_IMPORTED_MODULE_3___default()), {}),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(AppBar, {
                    position: "absolute",
                    open: open,
                    children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_7___default()), {
                        sx: {
                            pr: "24px"
                        },
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                edge: "start",
                                color: "inherit",
                                "aria-label": "open drawer",
                                onClick: toggleDrawer,
                                sx: {
                                    marginRight: "36px",
                                    ...open && {
                                        display: "none"
                                    }
                                },
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Menu__WEBPACK_IMPORTED_MODULE_17___default()), {})
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_9___default()), {
                                component: "h1",
                                variant: "h6",
                                color: "inherit",
                                noWrap: true,
                                sx: {
                                    flexGrow: 1,
                                    textShadow: "1px 1px 4px black"
                                },
                                children: "WAR Dashboard > Nuevo registro"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                color: "inherit",
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_MoreVert__WEBPACK_IMPORTED_MODULE_24___default()), {})
                            })
                        ]
                    })
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(Drawer, {
                    variant: "permanent",
                    open: open,
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_7___default()), {
                            sx: {
                                display: "flex",
                                alignItems: "center",
                                justifyContent: "space-between",
                                px: [
                                    1
                                ]
                            },
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_21___default()), {
                                    src: "/svg/war-logo.svg",
                                    width: 160,
                                    height: 50,
                                    alt: "renian-icon"
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_IconButton__WEBPACK_IMPORTED_MODULE_11___default()), {
                                    onClick: toggleDrawer,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ChevronLeft__WEBPACK_IMPORTED_MODULE_18___default()), {})
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_10___default()), {}),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_List__WEBPACK_IMPORTED_MODULE_8___default()), {
                            component: "nav",
                            children: [
                                _listItems__WEBPACK_IMPORTED_MODULE_20__/* .mainListItems */ .z,
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Divider__WEBPACK_IMPORTED_MODULE_10___default()), {
                                    sx: {
                                        my: 1
                                    }
                                }),
                                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(_mui_material__WEBPACK_IMPORTED_MODULE_22__.ListItemButton, {
                                    onClick: ()=>{
                                        (0,_utils_war_auth__WEBPACK_IMPORTED_MODULE_27__/* .logout */ .kS)(web3, handleWeb3, handleToken, handleAccount);
                                    },
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_22__.ListItemIcon, {
                                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_ExitToApp__WEBPACK_IMPORTED_MODULE_23___default()), {})
                                        }),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_22__.ListItemText, {
                                            primary: "Salir"
                                        })
                                    ]
                                })
                            ]
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_List__WEBPACK_IMPORTED_MODULE_8___default()), {
                            component: "nav"
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_Box__WEBPACK_IMPORTED_MODULE_5___default()), {
                    component: "main",
                    sx: {
                        backgroundColor: (theme)=>theme.palette.mode === "light" ? theme.palette.grey[100] : theme.palette.grey[900],
                        flexGrow: 1,
                        height: "100vh",
                        overflow: "auto"
                    },
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Toolbar__WEBPACK_IMPORTED_MODULE_7___default()), {}),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Container__WEBPACK_IMPORTED_MODULE_13___default()), {
                            maxWidth: "lg",
                            sx: {
                                mt: 4,
                                mb: 4
                            },
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_14___default()), {
                                container: true,
                                spacing: 3,
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Grid__WEBPACK_IMPORTED_MODULE_14___default()), {
                                    item: true,
                                    xs: 12,
                                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Paper__WEBPACK_IMPORTED_MODULE_15___default()), {
                                        sx: {
                                            p: 2,
                                            display: "flex",
                                            flexDirection: "column"
                                        },
                                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_FormNewUser__WEBPACK_IMPORTED_MODULE_25__/* .FormNewUser */ .u, {})
                                    })
                                })
                            })
                        })
                    ]
                })
            ]
        })
    });
};
function Dashboard() {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(DashboardContent, {});
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6611:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ FormNewUser)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5692);
/* harmony import */ var _mui_material__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(_mui_material__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5641);
/* harmony import */ var _Title__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8001);
/* harmony import */ var _utils_war_adopters__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7756);
/* harmony import */ var _contexts_Web3_Web3Context__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(3918);
/* harmony import */ var _utils_war_UsersSystem__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(8095);
/* harmony import */ var _utils_helpers__WEBPACK_IMPORTED_MODULE_12__ = __webpack_require__(4108);
/* harmony import */ var _utils_war_RegisteringEntities__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(3820);
/* harmony import */ var _useUbigeo__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8741);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(1929);
/* harmony import */ var react_select__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(react_select__WEBPACK_IMPORTED_MODULE_10__);
/* harmony import */ var _mui_icons_material_AccountBalanceWallet__WEBPACK_IMPORTED_MODULE_11__ = __webpack_require__(5808);
/* harmony import */ var _mui_icons_material_AccountBalanceWallet__WEBPACK_IMPORTED_MODULE_11___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AccountBalanceWallet__WEBPACK_IMPORTED_MODULE_11__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([react_hook_form__WEBPACK_IMPORTED_MODULE_3__]);
react_hook_form__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];













const FormNewUser = ()=>{
    const { register , handleSubmit , setValue , watch , formState: { errors  } ,  } = (0,react_hook_form__WEBPACK_IMPORTED_MODULE_3__.useForm)();
    const { 0: sendData , 1: setSendData  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)();
    const { 0: user , 1: setUser  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const { 0: userEntity , 1: setUserEntity  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const { 0: publicAddress , 1: setPublicAddress  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useState)({});
    const { departments , provinces , districts , handleDepartaments , handleProvinces , handleDistricts ,  } = (0,_useUbigeo__WEBPACK_IMPORTED_MODULE_9__/* .useUbigeo */ .K)();
    const regexNum = /^[0-9]+/;
    const regexText = /^[a-zA-Z0-9 ]+$/;
    const regexEmail = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
    const onSubmit = (data)=>{
        const newPassword = Math.random().toString(36).slice(-8);
        const info = {
            _id: "",
            status: false,
            idRegisteringEntity: userEntity,
            sendEmail: true,
            privateKey: publicAddress.privateKey,
            password: newPassword,
            ...(0,_utils_helpers__WEBPACK_IMPORTED_MODULE_12__/* .objectUppercase */ .b)(data)
        };
        setSendData(info);
        (0,_utils_war_adopters__WEBPACK_IMPORTED_MODULE_5__/* .handlePost */ .B$)(info, web3.authToken, "POST");
    };
    const { web3 , handleWeb3 , handleAccount , handleChainId , handleToken  } = (0,react__WEBPACK_IMPORTED_MODULE_2__.useContext)(_contexts_Web3_Web3Context__WEBPACK_IMPORTED_MODULE_6__/* .Web3Context */ .S);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        handleDepartaments();
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        web3.account != "" && web3.wallet != null && (0,_utils_war_UsersSystem__WEBPACK_IMPORTED_MODULE_7__/* .Users */ .Q)(web3.wallet, web3.account).then((resolve)=>{
            !(0,_utils_helpers__WEBPACK_IMPORTED_MODULE_12__/* .isObjEmpty */ .Z)(resolve) ? setUser(resolve) : setUser({});
        }).catch((e)=>console.log(e));
    }, [
        web3.account,
        web3.wallet,
        web3.chainId
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_2__.useEffect)(()=>{
        if (user?.registeringEntity != "" && user?.registeringEntity != undefined) {
            (0,_utils_war_RegisteringEntities__WEBPACK_IMPORTED_MODULE_8__/* .getResponsibility */ .b)(web3.wallet, user?.registeringEntity).then((resolve2)=>{
                setUserEntity(resolve2);
            });
        }
    }, [
        user?.registeringEntity,
        web3.wallet
    ]);
    const newAddress = async ()=>{
        const response = await web3.wallet.eth.accounts.create();
        setPublicAddress(response);
        setValue("address", response.address);
    };
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
        children: [
            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("form", {
                onSubmit: handleSubmit(onSubmit),
                children: [
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Title__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        children: "Identificacion"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        style: {
                            display: "grid",
                            gridTemplateColumns: "repeat(2, 1fr)",
                            columnGap: "1.5rem",
                            marginTop: "2rem"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Pais*"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                        className: "form-select",
                                        ...register("country", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        }),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "PE",
                                                children: "Peru"
                                            })
                                        ]
                                    }),
                                    errors.country && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.country.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Tipo Persona*"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                        className: "form-select",
                                        ...register("person", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        }),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "natural",
                                                children: "Natural"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "juridic",
                                                children: "Juridico"
                                            })
                                        ]
                                    }),
                                    errors.person && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.person.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Documento de Identificacion*"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                        className: "form-select",
                                        ...register("document", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        }),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "d.n.i.",
                                                children: "D.N.I"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "c.e.",
                                                children: "C.E"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "r.u.c.",
                                                children: "RUC"
                                            })
                                        ]
                                    }),
                                    errors.document && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.document.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Numero Documento*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "number",
                                        className: "form-control",
                                        ...register("documentNumber", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            },
                                            minLength: {
                                                value: 8,
                                                message: "Formato incorrecto"
                                            },
                                            maxLength: {
                                                value: 11,
                                                message: "Formato incorrecto"
                                            },
                                            pattern: {
                                                value: regexNum,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.documentNumber && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.documentNumber.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Tipo*"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                        className: "form-select",
                                        ...register("type", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        }),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "adopter",
                                                children: "Adoptante"
                                            })
                                        ]
                                    }),
                                    errors.type && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.type.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                                className: "mb-3",
                                style: {
                                    display: "flex",
                                    alignItems: "flex-end",
                                    justifyContent: "flex-start"
                                },
                                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                    style: {
                                        display: "flex",
                                        border: "1px solid rgb(191, 193, 193)",
                                        padding: ".5rem 1rem",
                                        borderRadius: "0.375rem",
                                        cursor: "pointer"
                                    },
                                    onClick: ()=>newAddress(),
                                    children: [
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AccountBalanceWallet__WEBPACK_IMPORTED_MODULE_11___default()), {}),
                                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                            style: {
                                                margin: "0 0 0 8px"
                                            },
                                            children: "Crear address"
                                        })
                                    ]
                                })
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "form-label",
                                children: "Address*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                placeholder: "0x...",
                                className: "form-control",
                                ...register("address", {
                                    required: {
                                        value: true,
                                        message: "Campo requerido"
                                    },
                                    minLength: {
                                        value: 42,
                                        message: "Formato incorrecto"
                                    },
                                    maxLength: {
                                        value: 42,
                                        message: "Formato incorrecto"
                                    },
                                    pattern: {
                                        value: regexText,
                                        message: "Formato incorrecto"
                                    }
                                }),
                                disabled: true,
                                readOnly: true
                            }),
                            errors.address && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                className: "text-danger",
                                children: errors.address.message
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                        sx: {
                            my: 5
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Title__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        children: "Datos Personales"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        style: {
                            display: "grid",
                            gridTemplateColumns: "repeat(2, 1fr)",
                            columnGap: "1.5rem",
                            marginTop: "2rem"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Primer Nombre*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        ...register("name", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            },
                                            minLength: {
                                                value: 3,
                                                message: "Nombre muy corto"
                                            },
                                            maxLength: {
                                                value: 20,
                                                message: "Nombre muy largo"
                                            },
                                            pattern: {
                                                value: regexText,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.name && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.name.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Segundo Nombre"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        ...register("secondName", {
                                            minLength: {
                                                value: 3,
                                                message: "Apellido muy corto"
                                            },
                                            maxLength: {
                                                value: 20,
                                                message: "Apellido muy largo"
                                            },
                                            pattern: {
                                                value: regexText,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.secondName && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.secondName.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Primer Apellido*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        ...register("lastName", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            },
                                            minLength: {
                                                value: 3,
                                                message: "Apellido muy corto"
                                            },
                                            maxLength: {
                                                value: 20,
                                                message: "Apellido muy largo"
                                            },
                                            pattern: {
                                                value: regexText,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.lastName && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.lastName.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Segundo Apellido*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        ...register("mLastName", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            },
                                            minLength: {
                                                value: 3,
                                                message: "Apellido muy corto"
                                            },
                                            maxLength: {
                                                value: 20,
                                                message: "Apellido muy largo"
                                            },
                                            pattern: {
                                                value: regexText,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.mLastName && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.mLastName.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Fecha de Nacimiento*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "date",
                                        className: "form-control",
                                        ...register("date", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        })
                                    }),
                                    errors.date && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.date.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Genero*"
                                    }),
                                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("select", {
                                        className: "form-select",
                                        ...register("gender", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        }),
                                        children: [
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: ""
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "male",
                                                children: "Hombre"
                                            }),
                                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("option", {
                                                value: "female",
                                                children: "Mujer"
                                            })
                                        ]
                                    }),
                                    errors.gender && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.gender.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Celular*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "number",
                                        className: "form-control",
                                        ...register("phone", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            },
                                            minLength: {
                                                value: 9,
                                                message: "Formato incorrecto"
                                            },
                                            maxLength: {
                                                value: 9,
                                                message: "Formato incorrecto"
                                            },
                                            pattern: {
                                                value: regexNum,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.phone && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.phone.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Correo Electronico*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "text",
                                        className: "form-control",
                                        ...register("email", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            },
                                            pattern: {
                                                value: regexEmail,
                                                message: "Formato incorrecto"
                                            }
                                        })
                                    }),
                                    errors.email && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.email.message
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "form-check mt-3",
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                            className: "form-check-label",
                            children: "Acepto compartir mi informacion personal en las busquedas en la Platafora"
                        })
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                        sx: {
                            my: 5
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_Title__WEBPACK_IMPORTED_MODULE_4__/* ["default"] */ .Z, {
                        children: "Localidad"
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("section", {
                        style: {
                            display: "grid",
                            gridTemplateColumns: "repeat(3, 1fr)",
                            columnGap: "1.5rem",
                            marginTop: "2rem"
                        },
                        children: [
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Departamento*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_select__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        options: departments,
                                        value: {
                                            label: watch("department")
                                        },
                                        onChange: (target)=>{
                                            setValue("department", target.value);
                                            setValue("province", "");
                                            setValue("district", "");
                                            handleProvinces(target.value);
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "hidden",
                                        ...register("department", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        })
                                    }),
                                    errors.department && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.department.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Provincia*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_select__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        options: provinces,
                                        value: {
                                            label: watch("province")
                                        },
                                        onChange: (target)=>{
                                            setValue("province", target.value);
                                            setValue("district", "");
                                            handleDistricts(target.value);
                                        }
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "hidden",
                                        ...register("province", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        })
                                    }),
                                    errors.province && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.province.message
                                    })
                                ]
                            }),
                            /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                className: "mb-3",
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                        className: "form-label",
                                        children: "Distrito*"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((react_select__WEBPACK_IMPORTED_MODULE_10___default()), {
                                        options: districts,
                                        value: {
                                            label: watch("district")
                                        },
                                        onChange: (target)=>{
                                            setValue("district", target.value);
                                        },
                                        name: "district",
                                        id: "district",
                                        required: true
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                        type: "hidden",
                                        ...register("district", {
                                            required: {
                                                value: true,
                                                message: "Campo requerido"
                                            }
                                        })
                                    }),
                                    errors.district && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                        className: "text-danger",
                                        children: errors.district.message
                                    })
                                ]
                            })
                        ]
                    }),
                    /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                        className: "mb-3",
                        children: [
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("label", {
                                className: "form-label",
                                children: "Direccion*"
                            }),
                            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("input", {
                                type: "text",
                                className: "form-control",
                                ...register("direction", {
                                    required: {
                                        value: true,
                                        message: "Campo requerido"
                                    },
                                    minLength: {
                                        value: 5,
                                        message: "Direccion muy corta"
                                    },
                                    maxLength: {
                                        value: 100,
                                        message: "Direccion muy larga"
                                    },
                                    pattern: {
                                        value: regexText,
                                        message: "Formato incorrecto"
                                    }
                                })
                            }),
                            errors.direction && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("small", {
                                className: "text-danger",
                                children: errors.direction.message
                            })
                        ]
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_mui_material__WEBPACK_IMPORTED_MODULE_1__.Divider, {
                        sx: {
                            my: 5
                        }
                    }),
                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                        className: "mb-3 mt-5",
                        style: {
                            width: "100%",
                            display: "flex",
                            justifyContent: "center"
                        },
                        children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                            className: "btn btn-dark",
                            type: "submit",
                            style: {
                                width: "100%"
                            },
                            children: "Guardar"
                        })
                    })
                ]
            }),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                className: "alert alert-warning",
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("code", {
                    children: [
                        "Data sent: ",
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("br", {}),
                        JSON.stringify(sendData)
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 8001:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (__WEBPACK_DEFAULT_EXPORT__)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(580);
/* harmony import */ var prop_types__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(prop_types__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7163);
/* harmony import */ var _mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3__);




function Title(props) {
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_Typography__WEBPACK_IMPORTED_MODULE_3___default()), {
        component: "h2",
        variant: "h6",
        color: "primary",
        gutterBottom: true,
        children: props.children
    });
}
Title.propTypes = {
    children: (prop_types__WEBPACK_IMPORTED_MODULE_2___default().node)
};
/* harmony default export */ const __WEBPACK_DEFAULT_EXPORT__ = (Title);


/***/ }),

/***/ 3550:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "z": () => (/* binding */ mainListItems)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1011);
/* harmony import */ var _mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(3787);
/* harmony import */ var _mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(8315);
/* harmony import */ var _mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _mui_icons_material_People__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(7166);
/* harmony import */ var _mui_icons_material_People__WEBPACK_IMPORTED_MODULE_5___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_People__WEBPACK_IMPORTED_MODULE_5__);
/* harmony import */ var _mui_icons_material_Layers__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(476);
/* harmony import */ var _mui_icons_material_Layers__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Layers__WEBPACK_IMPORTED_MODULE_6__);
/* harmony import */ var _mui_icons_material_Pets__WEBPACK_IMPORTED_MODULE_7__ = __webpack_require__(6837);
/* harmony import */ var _mui_icons_material_Pets__WEBPACK_IMPORTED_MODULE_7___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Pets__WEBPACK_IMPORTED_MODULE_7__);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_8__ = __webpack_require__(8017);
/* harmony import */ var _mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_8___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_8__);
/* harmony import */ var _mui_icons_material_AssignmentInd__WEBPACK_IMPORTED_MODULE_9__ = __webpack_require__(8235);
/* harmony import */ var _mui_icons_material_AssignmentInd__WEBPACK_IMPORTED_MODULE_9___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AssignmentInd__WEBPACK_IMPORTED_MODULE_9__);
/* harmony import */ var _mui_icons_material_AddCard__WEBPACK_IMPORTED_MODULE_10__ = __webpack_require__(4236);
/* harmony import */ var _mui_icons_material_AddCard__WEBPACK_IMPORTED_MODULE_10___default = /*#__PURE__*/__webpack_require__.n(_mui_icons_material_AddCard__WEBPACK_IMPORTED_MODULE_10__);





// import ListSubheader from "@mui/material/ListSubheader";






const mainListItems = /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react__WEBPACK_IMPORTED_MODULE_1__.Fragment, {
    children: [
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_People__WEBPACK_IMPORTED_MODULE_5___default()), {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4___default()), {
                    primary: "Mis Mascotas"
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Search__WEBPACK_IMPORTED_MODULE_8___default()), {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4___default()), {
                    primary: "Buscar"
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_Pets__WEBPACK_IMPORTED_MODULE_7___default()), {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4___default()), {
                    primary: "Mascotas General"
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AssignmentInd__WEBPACK_IMPORTED_MODULE_9___default()), {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4___default()), {
                    primary: "Veterinarios"
                })
            ]
        }),
        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)((_mui_material_ListItemButton__WEBPACK_IMPORTED_MODULE_2___default()), {
            children: [
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemIcon__WEBPACK_IMPORTED_MODULE_3___default()), {
                    children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_icons_material_AddCard__WEBPACK_IMPORTED_MODULE_10___default()), {})
                }),
                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((_mui_material_ListItemText__WEBPACK_IMPORTED_MODULE_4___default()), {
                    primary: "Crear Carnet"
                })
            ]
        })
    ]
}); // export const secondaryListItems = (
 //   <React.Fragment>
 //     <ListSubheader component="div" inset>
 //       Saved reports
 //     </ListSubheader>
 //     <ListItemButton>
 //       <ListItemIcon>
 //         <AssignmentIcon />
 //       </ListItemIcon>
 //       <ListItemText primary="Current month" />
 //     </ListItemButton>
 //     <ListItemButton>
 //       <ListItemIcon>
 //         <AssignmentIcon />
 //       </ListItemIcon>
 //       <ListItemText primary="Last quarter" />
 //     </ListItemButton>
 //     <ListItemButton>
 //       <ListItemIcon>
 //         <AssignmentIcon />
 //       </ListItemIcon>
 //       <ListItemText primary="Year-end sale" />
 //     </ListItemButton>
 //   </React.Fragment>
 // );


/***/ }),

/***/ 8741:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "K": () => (/* binding */ useUbigeo)
});

// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
;// CONCATENATED MODULE: ./public/json/departments.json
const departments_namespaceObject = JSON.parse('[{"id":"01","name":"AMAZONAS"},{"id":"02","name":"ÁNCASH"},{"id":"03","name":"APURÍMAC"},{"id":"04","name":"AREQUIPA"},{"id":"05","name":"AYACUCHO"},{"id":"06","name":"CAJAMARCA"},{"id":"07","name":"CALLAO"},{"id":"08","name":"CUSCO"},{"id":"09","name":"HUANCAVELICA"},{"id":"10","name":"HUÁNUCO"},{"id":"11","name":"ICA"},{"id":"12","name":"JUNÍN"},{"id":"13","name":"LA LIBERTAD"},{"id":"14","name":"LAMBAYEQUE"},{"id":"15","name":"LIMA"},{"id":"16","name":"LORETO"},{"id":"17","name":"MADRE DE DIOS"},{"id":"18","name":"MOQUEGUA"},{"id":"19","name":"PASCO"},{"id":"20","name":"PIURA"},{"id":"21","name":"PUNO"},{"id":"22","name":"SAN MARTÍN"},{"id":"23","name":"TACNA"},{"id":"24","name":"TUMBES"},{"id":"25","name":"UCAYALI"}]');
;// CONCATENATED MODULE: ./public/json/provinces.json
const provinces_namespaceObject = JSON.parse('[{"id":"0101","name":"CHACHAPOYAS","department_id":"01"},{"id":"0102","name":"BAGUA","department_id":"01"},{"id":"0103","name":"BONGARÁ","department_id":"01"},{"id":"0104","name":"CONDORCANQUI","department_id":"01"},{"id":"0105","name":"LUYA","department_id":"01"},{"id":"0106","name":"RODRÍGUEZ DE MENDOZA","department_id":"01"},{"id":"0107","name":"UTCUBAMBA","department_id":"01"},{"id":"0201","name":"HUARAZ","department_id":"02"},{"id":"0202","name":"AIJA","department_id":"02"},{"id":"0203","name":"ANTONIO RAYMONDI","department_id":"02"},{"id":"0204","name":"ASUNCIÓN","department_id":"02"},{"id":"0205","name":"BOLOGNESI","department_id":"02"},{"id":"0206","name":"CARHUAZ","department_id":"02"},{"id":"0207","name":"CARLOS FERMÍN FITZCARRALD","department_id":"02"},{"id":"0208","name":"CASMA","department_id":"02"},{"id":"0209","name":"CORONGO","department_id":"02"},{"id":"0210","name":"HUARI","department_id":"02"},{"id":"0211","name":"HUARMEY","department_id":"02"},{"id":"0212","name":"HUAYLAS","department_id":"02"},{"id":"0213","name":"MARISCAL LUZURIAGA","department_id":"02"},{"id":"0214","name":"OCROS","department_id":"02"},{"id":"0215","name":"PALLASCA","department_id":"02"},{"id":"0216","name":"POMABAMBA","department_id":"02"},{"id":"0217","name":"RECUAY","department_id":"02"},{"id":"0218","name":"SANTA","department_id":"02"},{"id":"0219","name":"SIHUAS","department_id":"02"},{"id":"0220","name":"YUNGAY","department_id":"02"},{"id":"0301","name":"ABANCAY","department_id":"03"},{"id":"0302","name":"ANDAHUAYLAS","department_id":"03"},{"id":"0303","name":"ANTABAMBA","department_id":"03"},{"id":"0304","name":"AYMARAES","department_id":"03"},{"id":"0305","name":"COTABAMBAS","department_id":"03"},{"id":"0306","name":"CHINCHEROS","department_id":"03"},{"id":"0307","name":"GRAU","department_id":"03"},{"id":"0401","name":"AREQUIPA","department_id":"04"},{"id":"0402","name":"CAMANÁ","department_id":"04"},{"id":"0403","name":"CARAVELÍ","department_id":"04"},{"id":"0404","name":"CASTILLA","department_id":"04"},{"id":"0405","name":"CAYLLOMA","department_id":"04"},{"id":"0406","name":"CONDESUYOS","department_id":"04"},{"id":"0407","name":"ISLAY","department_id":"04"},{"id":"0408","name":"LA UNIÒN","department_id":"04"},{"id":"0501","name":"HUAMANGA","department_id":"05"},{"id":"0502","name":"CANGALLO","department_id":"05"},{"id":"0503","name":"HUANCA SANCOS","department_id":"05"},{"id":"0504","name":"HUANTA","department_id":"05"},{"id":"0505","name":"LA MAR","department_id":"05"},{"id":"0506","name":"LUCANAS","department_id":"05"},{"id":"0507","name":"PARINACOCHAS","department_id":"05"},{"id":"0508","name":"PÀUCAR DEL SARA SARA","department_id":"05"},{"id":"0509","name":"SUCRE","department_id":"05"},{"id":"0510","name":"VÍCTOR FAJARDO","department_id":"05"},{"id":"0511","name":"VILCAS HUAMÁN","department_id":"05"},{"id":"0601","name":"CAJAMARCA","department_id":"06"},{"id":"0602","name":"CAJABAMBA","department_id":"06"},{"id":"0603","name":"CELENDÍN","department_id":"06"},{"id":"0604","name":"CHOTA","department_id":"06"},{"id":"0605","name":"CONTUMAZÁ","department_id":"06"},{"id":"0606","name":"CUTERVO","department_id":"06"},{"id":"0607","name":"HUALGAYOC","department_id":"06"},{"id":"0608","name":"JAÉN","department_id":"06"},{"id":"0609","name":"SAN IGNACIO","department_id":"06"},{"id":"0610","name":"SAN MARCOS","department_id":"06"},{"id":"0611","name":"SAN MIGUEL","department_id":"06"},{"id":"0612","name":"SAN PABLO","department_id":"06"},{"id":"0613","name":"SANTA CRUZ","department_id":"06"},{"id":"0701","name":"PROV. CONST. DEL CALLAO","department_id":"07"},{"id":"0801","name":"CUSCO","department_id":"08"},{"id":"0802","name":"ACOMAYO","department_id":"08"},{"id":"0803","name":"ANTA","department_id":"08"},{"id":"0804","name":"CALCA","department_id":"08"},{"id":"0805","name":"CANAS","department_id":"08"},{"id":"0806","name":"CANCHIS","department_id":"08"},{"id":"0807","name":"CHUMBIVILCAS","department_id":"08"},{"id":"0808","name":"ESPINAR","department_id":"08"},{"id":"0809","name":"LA CONVENCIÓN","department_id":"08"},{"id":"0810","name":"PARURO","department_id":"08"},{"id":"0811","name":"PAUCARTAMBO","department_id":"08"},{"id":"0812","name":"QUISPICANCHI","department_id":"08"},{"id":"0813","name":"URUBAMBA","department_id":"08"},{"id":"0901","name":"HUANCAVELICA","department_id":"09"},{"id":"0902","name":"ACOBAMBA","department_id":"09"},{"id":"0903","name":"ANGARAES","department_id":"09"},{"id":"0904","name":"CASTROVIRREYNA","department_id":"09"},{"id":"0905","name":"CHURCAMPA","department_id":"09"},{"id":"0906","name":"HUAYTARÁ","department_id":"09"},{"id":"0907","name":"TAYACAJA","department_id":"09"},{"id":"1001","name":"HUÁNUCO","department_id":"10"},{"id":"1002","name":"AMBO","department_id":"10"},{"id":"1003","name":"DOS DE MAYO","department_id":"10"},{"id":"1004","name":"HUACAYBAMBA","department_id":"10"},{"id":"1005","name":"HUAMALÍES","department_id":"10"},{"id":"1006","name":"LEONCIO PRADO","department_id":"10"},{"id":"1007","name":"MARAÑÓN","department_id":"10"},{"id":"1008","name":"PACHITEA","department_id":"10"},{"id":"1009","name":"PUERTO INCA","department_id":"10"},{"id":"1010","name":"LAURICOCHA ","department_id":"10"},{"id":"1011","name":"YAROWILCA ","department_id":"10"},{"id":"1101","name":"ICA ","department_id":"11"},{"id":"1102","name":"CHINCHA ","department_id":"11"},{"id":"1103","name":"NASCA ","department_id":"11"},{"id":"1104","name":"PALPA ","department_id":"11"},{"id":"1105","name":"PISCO ","department_id":"11"},{"id":"1201","name":"HUANCAYO ","department_id":"12"},{"id":"1202","name":"CONCEPCIÓN ","department_id":"12"},{"id":"1203","name":"CHANCHAMAYO ","department_id":"12"},{"id":"1204","name":"JAUJA ","department_id":"12"},{"id":"1205","name":"JUNÍN ","department_id":"12"},{"id":"1206","name":"SATIPO ","department_id":"12"},{"id":"1207","name":"TARMA ","department_id":"12"},{"id":"1208","name":"YAULI ","department_id":"12"},{"id":"1209","name":"CHUPACA ","department_id":"12"},{"id":"1301","name":"TRUJILLO ","department_id":"13"},{"id":"1302","name":"ASCOPE ","department_id":"13"},{"id":"1303","name":"BOLÍVAR ","department_id":"13"},{"id":"1304","name":"CHEPÉN ","department_id":"13"},{"id":"1305","name":"JULCÁN ","department_id":"13"},{"id":"1306","name":"OTUZCO ","department_id":"13"},{"id":"1307","name":"PACASMAYO ","department_id":"13"},{"id":"1308","name":"PATAZ ","department_id":"13"},{"id":"1309","name":"SÁNCHEZ CARRIÓN ","department_id":"13"},{"id":"1310","name":"SANTIAGO DE CHUCO ","department_id":"13"},{"id":"1311","name":"GRAN CHIMÚ ","department_id":"13"},{"id":"1312","name":"VIRÚ ","department_id":"13"},{"id":"1401","name":"CHICLAYO ","department_id":"14"},{"id":"1402","name":"FERREÑAFE ","department_id":"14"},{"id":"1403","name":"LAMBAYEQUE ","department_id":"14"},{"id":"1501","name":"LIMA ","department_id":"15"},{"id":"1502","name":"BARRANCA ","department_id":"15"},{"id":"1503","name":"CAJATAMBO ","department_id":"15"},{"id":"1504","name":"CANTA ","department_id":"15"},{"id":"1505","name":"CAÑETE ","department_id":"15"},{"id":"1506","name":"HUARAL ","department_id":"15"},{"id":"1507","name":"HUAROCHIRÍ ","department_id":"15"},{"id":"1508","name":"HUAURA ","department_id":"15"},{"id":"1509","name":"OYÓN ","department_id":"15"},{"id":"1510","name":"YAUYOS ","department_id":"15"},{"id":"1601","name":"MAYNAS ","department_id":"16"},{"id":"1602","name":"ALTO AMAZONAS ","department_id":"16"},{"id":"1603","name":"LORETO ","department_id":"16"},{"id":"1604","name":"MARISCAL RAMÓN CASTILLA ","department_id":"16"},{"id":"1605","name":"REQUENA ","department_id":"16"},{"id":"1606","name":"UCAYALI ","department_id":"16"},{"id":"1607","name":"DATEM DEL MARAÑÓN ","department_id":"16"},{"id":"1608","name":"PUTUMAYO","department_id":"16"},{"id":"1701","name":"TAMBOPATA ","department_id":"17"},{"id":"1702","name":"MANU ","department_id":"17"},{"id":"1703","name":"TAHUAMANU ","department_id":"17"},{"id":"1801","name":"MARISCAL NIETO ","department_id":"18"},{"id":"1802","name":"GENERAL SÁNCHEZ CERRO ","department_id":"18"},{"id":"1803","name":"ILO ","department_id":"18"},{"id":"1901","name":"PASCO ","department_id":"19"},{"id":"1902","name":"DANIEL ALCIDES CARRIÓN ","department_id":"19"},{"id":"1903","name":"OXAPAMPA ","department_id":"19"},{"id":"2001","name":"PIURA ","department_id":"20"},{"id":"2002","name":"AYABACA ","department_id":"20"},{"id":"2003","name":"HUANCABAMBA ","department_id":"20"},{"id":"2004","name":"MORROPÓN ","department_id":"20"},{"id":"2005","name":"PAITA ","department_id":"20"},{"id":"2006","name":"SULLANA ","department_id":"20"},{"id":"2007","name":"TALARA ","department_id":"20"},{"id":"2008","name":"SECHURA ","department_id":"20"},{"id":"2101","name":"PUNO ","department_id":"21"},{"id":"2102","name":"AZÁNGARO ","department_id":"21"},{"id":"2103","name":"CARABAYA ","department_id":"21"},{"id":"2104","name":"CHUCUITO ","department_id":"21"},{"id":"2105","name":"EL COLLAO ","department_id":"21"},{"id":"2106","name":"HUANCANÉ ","department_id":"21"},{"id":"2107","name":"LAMPA ","department_id":"21"},{"id":"2108","name":"MELGAR ","department_id":"21"},{"id":"2109","name":"MOHO ","department_id":"21"},{"id":"2110","name":"SAN ANTONIO DE PUTINA ","department_id":"21"},{"id":"2111","name":"SAN ROMÁN ","department_id":"21"},{"id":"2112","name":"SANDIA ","department_id":"21"},{"id":"2113","name":"YUNGUYO ","department_id":"21"},{"id":"2201","name":"MOYOBAMBA ","department_id":"22"},{"id":"2202","name":"BELLAVISTA ","department_id":"22"},{"id":"2203","name":"EL DORADO ","department_id":"22"},{"id":"2204","name":"HUALLAGA ","department_id":"22"},{"id":"2205","name":"LAMAS ","department_id":"22"},{"id":"2206","name":"MARISCAL CÁCERES ","department_id":"22"},{"id":"2207","name":"PICOTA ","department_id":"22"},{"id":"2208","name":"RIOJA ","department_id":"22"},{"id":"2209","name":"SAN MARTÍN ","department_id":"22"},{"id":"2210","name":"TOCACHE ","department_id":"22"},{"id":"2301","name":"TACNA ","department_id":"23"},{"id":"2302","name":"CANDARAVE ","department_id":"23"},{"id":"2303","name":"JORGE BASADRE ","department_id":"23"},{"id":"2304","name":"TARATA ","department_id":"23"},{"id":"2401","name":"TUMBES ","department_id":"24"},{"id":"2402","name":"CONTRALMIRANTE VILLAR ","department_id":"24"},{"id":"2403","name":"ZARUMILLA ","department_id":"24"},{"id":"2501","name":"CORONEL PORTILLO ","department_id":"25"},{"id":"2502","name":"ATALAYA ","department_id":"25"},{"id":"2503","name":"PADRE ABAD ","department_id":"25"},{"id":"2504","name":"PURÚS","department_id":"25"}]');
;// CONCATENATED MODULE: ./public/json/districts.json
const districts_namespaceObject = JSON.parse('[{"id":"010101","name":"CHACHAPOYAS","province_id":"0101","department_id":"01"},{"id":"010102","name":"ASUNCIÓN","province_id":"0101","department_id":"01"},{"id":"010103","name":"BALSAS","province_id":"0101","department_id":"01"},{"id":"010104","name":"CHETO","province_id":"0101","department_id":"01"},{"id":"010105","name":"CHILIQUIN","province_id":"0101","department_id":"01"},{"id":"010106","name":"CHUQUIBAMBA","province_id":"0101","department_id":"01"},{"id":"010107","name":"GRANADA","province_id":"0101","department_id":"01"},{"id":"010108","name":"HUANCAS","province_id":"0101","department_id":"01"},{"id":"010109","name":"LA JALCA","province_id":"0101","department_id":"01"},{"id":"010110","name":"LEIMEBAMBA","province_id":"0101","department_id":"01"},{"id":"010111","name":"LEVANTO","province_id":"0101","department_id":"01"},{"id":"010112","name":"MAGDALENA","province_id":"0101","department_id":"01"},{"id":"010113","name":"MARISCAL CASTILLA","province_id":"0101","department_id":"01"},{"id":"010114","name":"MOLINOPAMPA","province_id":"0101","department_id":"01"},{"id":"010115","name":"MONTEVIDEO","province_id":"0101","department_id":"01"},{"id":"010116","name":"OLLEROS","province_id":"0101","department_id":"01"},{"id":"010117","name":"QUINJALCA","province_id":"0101","department_id":"01"},{"id":"010118","name":"SAN FRANCISCO DE DAGUAS","province_id":"0101","department_id":"01"},{"id":"010119","name":"SAN ISIDRO DE MAINO","province_id":"0101","department_id":"01"},{"id":"010120","name":"SOLOCO","province_id":"0101","department_id":"01"},{"id":"010121","name":"SONCHE","province_id":"0101","department_id":"01"},{"id":"010201","name":"BAGUA","province_id":"0102","department_id":"01"},{"id":"010202","name":"ARAMANGO","province_id":"0102","department_id":"01"},{"id":"010203","name":"COPALLIN","province_id":"0102","department_id":"01"},{"id":"010204","name":"EL PARCO","province_id":"0102","department_id":"01"},{"id":"010205","name":"IMAZA","province_id":"0102","department_id":"01"},{"id":"010206","name":"LA PECA","province_id":"0102","department_id":"01"},{"id":"010301","name":"JUMBILLA","province_id":"0103","department_id":"01"},{"id":"010302","name":"CHISQUILLA","province_id":"0103","department_id":"01"},{"id":"010303","name":"CHURUJA","province_id":"0103","department_id":"01"},{"id":"010304","name":"COROSHA","province_id":"0103","department_id":"01"},{"id":"010305","name":"CUISPES","province_id":"0103","department_id":"01"},{"id":"010306","name":"FLORIDA","province_id":"0103","department_id":"01"},{"id":"010307","name":"JAZAN","province_id":"0103","department_id":"01"},{"id":"010308","name":"RECTA","province_id":"0103","department_id":"01"},{"id":"010309","name":"SAN CARLOS","province_id":"0103","department_id":"01"},{"id":"010310","name":"SHIPASBAMBA","province_id":"0103","department_id":"01"},{"id":"010311","name":"VALERA","province_id":"0103","department_id":"01"},{"id":"010312","name":"YAMBRASBAMBA","province_id":"0103","department_id":"01"},{"id":"010401","name":"NIEVA","province_id":"0104","department_id":"01"},{"id":"010402","name":"EL CENEPA","province_id":"0104","department_id":"01"},{"id":"010403","name":"RÍO SANTIAGO","province_id":"0104","department_id":"01"},{"id":"010501","name":"LAMUD","province_id":"0105","department_id":"01"},{"id":"010502","name":"CAMPORREDONDO","province_id":"0105","department_id":"01"},{"id":"010503","name":"COCABAMBA","province_id":"0105","department_id":"01"},{"id":"010504","name":"COLCAMAR","province_id":"0105","department_id":"01"},{"id":"010505","name":"CONILA","province_id":"0105","department_id":"01"},{"id":"010506","name":"INGUILPATA","province_id":"0105","department_id":"01"},{"id":"010507","name":"LONGUITA","province_id":"0105","department_id":"01"},{"id":"010508","name":"LONYA CHICO","province_id":"0105","department_id":"01"},{"id":"010509","name":"LUYA","province_id":"0105","department_id":"01"},{"id":"010510","name":"LUYA VIEJO","province_id":"0105","department_id":"01"},{"id":"010511","name":"MARÍA","province_id":"0105","department_id":"01"},{"id":"010512","name":"OCALLI","province_id":"0105","department_id":"01"},{"id":"010513","name":"OCUMAL","province_id":"0105","department_id":"01"},{"id":"010514","name":"PISUQUIA","province_id":"0105","department_id":"01"},{"id":"010515","name":"PROVIDENCIA","province_id":"0105","department_id":"01"},{"id":"010516","name":"SAN CRISTÓBAL","province_id":"0105","department_id":"01"},{"id":"010517","name":"SAN FRANCISCO DE YESO","province_id":"0105","department_id":"01"},{"id":"010518","name":"SAN JERÓNIMO","province_id":"0105","department_id":"01"},{"id":"010519","name":"SAN JUAN DE LOPECANCHA","province_id":"0105","department_id":"01"},{"id":"010520","name":"SANTA CATALINA","province_id":"0105","department_id":"01"},{"id":"010521","name":"SANTO TOMAS","province_id":"0105","department_id":"01"},{"id":"010522","name":"TINGO","province_id":"0105","department_id":"01"},{"id":"010523","name":"TRITA","province_id":"0105","department_id":"01"},{"id":"010601","name":"SAN NICOLÁS","province_id":"0106","department_id":"01"},{"id":"010602","name":"CHIRIMOTO","province_id":"0106","department_id":"01"},{"id":"010603","name":"COCHAMAL","province_id":"0106","department_id":"01"},{"id":"010604","name":"HUAMBO","province_id":"0106","department_id":"01"},{"id":"010605","name":"LIMABAMBA","province_id":"0106","department_id":"01"},{"id":"010606","name":"LONGAR","province_id":"0106","department_id":"01"},{"id":"010607","name":"MARISCAL BENAVIDES","province_id":"0106","department_id":"01"},{"id":"010608","name":"MILPUC","province_id":"0106","department_id":"01"},{"id":"010609","name":"OMIA","province_id":"0106","department_id":"01"},{"id":"010610","name":"SANTA ROSA","province_id":"0106","department_id":"01"},{"id":"010611","name":"TOTORA","province_id":"0106","department_id":"01"},{"id":"010612","name":"VISTA ALEGRE","province_id":"0106","department_id":"01"},{"id":"010701","name":"BAGUA GRANDE","province_id":"0107","department_id":"01"},{"id":"010702","name":"CAJARURO","province_id":"0107","department_id":"01"},{"id":"010703","name":"CUMBA","province_id":"0107","department_id":"01"},{"id":"010704","name":"EL MILAGRO","province_id":"0107","department_id":"01"},{"id":"010705","name":"JAMALCA","province_id":"0107","department_id":"01"},{"id":"010706","name":"LONYA GRANDE","province_id":"0107","department_id":"01"},{"id":"010707","name":"YAMON","province_id":"0107","department_id":"01"},{"id":"020101","name":"HUARAZ","province_id":"0201","department_id":"02"},{"id":"020102","name":"COCHABAMBA","province_id":"0201","department_id":"02"},{"id":"020103","name":"COLCABAMBA","province_id":"0201","department_id":"02"},{"id":"020104","name":"HUANCHAY","province_id":"0201","department_id":"02"},{"id":"020105","name":"INDEPENDENCIA","province_id":"0201","department_id":"02"},{"id":"020106","name":"JANGAS","province_id":"0201","department_id":"02"},{"id":"020107","name":"LA LIBERTAD","province_id":"0201","department_id":"02"},{"id":"020108","name":"OLLEROS","province_id":"0201","department_id":"02"},{"id":"020109","name":"PAMPAS GRANDE","province_id":"0201","department_id":"02"},{"id":"020110","name":"PARIACOTO","province_id":"0201","department_id":"02"},{"id":"020111","name":"PIRA","province_id":"0201","department_id":"02"},{"id":"020112","name":"TARICA","province_id":"0201","department_id":"02"},{"id":"020201","name":"AIJA","province_id":"0202","department_id":"02"},{"id":"020202","name":"CORIS","province_id":"0202","department_id":"02"},{"id":"020203","name":"HUACLLAN","province_id":"0202","department_id":"02"},{"id":"020204","name":"LA MERCED","province_id":"0202","department_id":"02"},{"id":"020205","name":"SUCCHA","province_id":"0202","department_id":"02"},{"id":"020301","name":"LLAMELLIN","province_id":"0203","department_id":"02"},{"id":"020302","name":"ACZO","province_id":"0203","department_id":"02"},{"id":"020303","name":"CHACCHO","province_id":"0203","department_id":"02"},{"id":"020304","name":"CHINGAS","province_id":"0203","department_id":"02"},{"id":"020305","name":"MIRGAS","province_id":"0203","department_id":"02"},{"id":"020306","name":"SAN JUAN DE RONTOY","province_id":"0203","department_id":"02"},{"id":"020401","name":"CHACAS","province_id":"0204","department_id":"02"},{"id":"020402","name":"ACOCHACA","province_id":"0204","department_id":"02"},{"id":"020501","name":"CHIQUIAN","province_id":"0205","department_id":"02"},{"id":"020502","name":"ABELARDO PARDO LEZAMETA","province_id":"0205","department_id":"02"},{"id":"020503","name":"ANTONIO RAYMONDI","province_id":"0205","department_id":"02"},{"id":"020504","name":"AQUIA","province_id":"0205","department_id":"02"},{"id":"020505","name":"CAJACAY","province_id":"0205","department_id":"02"},{"id":"020506","name":"CANIS","province_id":"0205","department_id":"02"},{"id":"020507","name":"COLQUIOC","province_id":"0205","department_id":"02"},{"id":"020508","name":"HUALLANCA","province_id":"0205","department_id":"02"},{"id":"020509","name":"HUASTA","province_id":"0205","department_id":"02"},{"id":"020510","name":"HUAYLLACAYAN","province_id":"0205","department_id":"02"},{"id":"020511","name":"LA PRIMAVERA","province_id":"0205","department_id":"02"},{"id":"020512","name":"MANGAS","province_id":"0205","department_id":"02"},{"id":"020513","name":"PACLLON","province_id":"0205","department_id":"02"},{"id":"020514","name":"SAN MIGUEL DE CORPANQUI","province_id":"0205","department_id":"02"},{"id":"020515","name":"TICLLOS","province_id":"0205","department_id":"02"},{"id":"020601","name":"CARHUAZ","province_id":"0206","department_id":"02"},{"id":"020602","name":"ACOPAMPA","province_id":"0206","department_id":"02"},{"id":"020603","name":"AMASHCA","province_id":"0206","department_id":"02"},{"id":"020604","name":"ANTA","province_id":"0206","department_id":"02"},{"id":"020605","name":"ATAQUERO","province_id":"0206","department_id":"02"},{"id":"020606","name":"MARCARA","province_id":"0206","department_id":"02"},{"id":"020607","name":"PARIAHUANCA","province_id":"0206","department_id":"02"},{"id":"020608","name":"SAN MIGUEL DE ACO","province_id":"0206","department_id":"02"},{"id":"020609","name":"SHILLA","province_id":"0206","department_id":"02"},{"id":"020610","name":"TINCO","province_id":"0206","department_id":"02"},{"id":"020611","name":"YUNGAR","province_id":"0206","department_id":"02"},{"id":"020701","name":"SAN LUIS","province_id":"0207","department_id":"02"},{"id":"020702","name":"SAN NICOLÁS","province_id":"0207","department_id":"02"},{"id":"020703","name":"YAUYA","province_id":"0207","department_id":"02"},{"id":"020801","name":"CASMA","province_id":"0208","department_id":"02"},{"id":"020802","name":"BUENA VISTA ALTA","province_id":"0208","department_id":"02"},{"id":"020803","name":"COMANDANTE NOEL","province_id":"0208","department_id":"02"},{"id":"020804","name":"YAUTAN","province_id":"0208","department_id":"02"},{"id":"020901","name":"CORONGO","province_id":"0209","department_id":"02"},{"id":"020902","name":"ACO","province_id":"0209","department_id":"02"},{"id":"020903","name":"BAMBAS","province_id":"0209","department_id":"02"},{"id":"020904","name":"CUSCA","province_id":"0209","department_id":"02"},{"id":"020905","name":"LA PAMPA","province_id":"0209","department_id":"02"},{"id":"020906","name":"YANAC","province_id":"0209","department_id":"02"},{"id":"020907","name":"YUPAN","province_id":"0209","department_id":"02"},{"id":"021001","name":"HUARI","province_id":"0210","department_id":"02"},{"id":"021002","name":"ANRA","province_id":"0210","department_id":"02"},{"id":"021003","name":"CAJAY","province_id":"0210","department_id":"02"},{"id":"021004","name":"CHAVIN DE HUANTAR","province_id":"0210","department_id":"02"},{"id":"021005","name":"HUACACHI","province_id":"0210","department_id":"02"},{"id":"021006","name":"HUACCHIS","province_id":"0210","department_id":"02"},{"id":"021007","name":"HUACHIS","province_id":"0210","department_id":"02"},{"id":"021008","name":"HUANTAR","province_id":"0210","department_id":"02"},{"id":"021009","name":"MASIN","province_id":"0210","department_id":"02"},{"id":"021010","name":"PAUCAS","province_id":"0210","department_id":"02"},{"id":"021011","name":"PONTO","province_id":"0210","department_id":"02"},{"id":"021012","name":"RAHUAPAMPA","province_id":"0210","department_id":"02"},{"id":"021013","name":"RAPAYAN","province_id":"0210","department_id":"02"},{"id":"021014","name":"SAN MARCOS","province_id":"0210","department_id":"02"},{"id":"021015","name":"SAN PEDRO DE CHANA","province_id":"0210","department_id":"02"},{"id":"021016","name":"UCO","province_id":"0210","department_id":"02"},{"id":"021101","name":"HUARMEY","province_id":"0211","department_id":"02"},{"id":"021102","name":"COCHAPETI","province_id":"0211","department_id":"02"},{"id":"021103","name":"CULEBRAS","province_id":"0211","department_id":"02"},{"id":"021104","name":"HUAYAN","province_id":"0211","department_id":"02"},{"id":"021105","name":"MALVAS","province_id":"0211","department_id":"02"},{"id":"021201","name":"CARAZ","province_id":"0212","department_id":"02"},{"id":"021202","name":"HUALLANCA","province_id":"0212","department_id":"02"},{"id":"021203","name":"HUATA","province_id":"0212","department_id":"02"},{"id":"021204","name":"HUAYLAS","province_id":"0212","department_id":"02"},{"id":"021205","name":"MATO","province_id":"0212","department_id":"02"},{"id":"021206","name":"PAMPAROMAS","province_id":"0212","department_id":"02"},{"id":"021207","name":"PUEBLO LIBRE","province_id":"0212","department_id":"02"},{"id":"021208","name":"SANTA CRUZ","province_id":"0212","department_id":"02"},{"id":"021209","name":"SANTO TORIBIO","province_id":"0212","department_id":"02"},{"id":"021210","name":"YURACMARCA","province_id":"0212","department_id":"02"},{"id":"021301","name":"PISCOBAMBA","province_id":"0213","department_id":"02"},{"id":"021302","name":"CASCA","province_id":"0213","department_id":"02"},{"id":"021303","name":"ELEAZAR GUZMÁN BARRON","province_id":"0213","department_id":"02"},{"id":"021304","name":"FIDEL OLIVAS ESCUDERO","province_id":"0213","department_id":"02"},{"id":"021305","name":"LLAMA","province_id":"0213","department_id":"02"},{"id":"021306","name":"LLUMPA","province_id":"0213","department_id":"02"},{"id":"021307","name":"LUCMA","province_id":"0213","department_id":"02"},{"id":"021308","name":"MUSGA","province_id":"0213","department_id":"02"},{"id":"021401","name":"OCROS","province_id":"0214","department_id":"02"},{"id":"021402","name":"ACAS","province_id":"0214","department_id":"02"},{"id":"021403","name":"CAJAMARQUILLA","province_id":"0214","department_id":"02"},{"id":"021404","name":"CARHUAPAMPA","province_id":"0214","department_id":"02"},{"id":"021405","name":"COCHAS","province_id":"0214","department_id":"02"},{"id":"021406","name":"CONGAS","province_id":"0214","department_id":"02"},{"id":"021407","name":"LLIPA","province_id":"0214","department_id":"02"},{"id":"021408","name":"SAN CRISTÓBAL DE RAJAN","province_id":"0214","department_id":"02"},{"id":"021409","name":"SAN PEDRO","province_id":"0214","department_id":"02"},{"id":"021410","name":"SANTIAGO DE CHILCAS","province_id":"0214","department_id":"02"},{"id":"021501","name":"CABANA","province_id":"0215","department_id":"02"},{"id":"021502","name":"BOLOGNESI","province_id":"0215","department_id":"02"},{"id":"021503","name":"CONCHUCOS","province_id":"0215","department_id":"02"},{"id":"021504","name":"HUACASCHUQUE","province_id":"0215","department_id":"02"},{"id":"021505","name":"HUANDOVAL","province_id":"0215","department_id":"02"},{"id":"021506","name":"LACABAMBA","province_id":"0215","department_id":"02"},{"id":"021507","name":"LLAPO","province_id":"0215","department_id":"02"},{"id":"021508","name":"PALLASCA","province_id":"0215","department_id":"02"},{"id":"021509","name":"PAMPAS","province_id":"0215","department_id":"02"},{"id":"021510","name":"SANTA ROSA","province_id":"0215","department_id":"02"},{"id":"021511","name":"TAUCA","province_id":"0215","department_id":"02"},{"id":"021601","name":"POMABAMBA","province_id":"0216","department_id":"02"},{"id":"021602","name":"HUAYLLAN","province_id":"0216","department_id":"02"},{"id":"021603","name":"PAROBAMBA","province_id":"0216","department_id":"02"},{"id":"021604","name":"QUINUABAMBA","province_id":"0216","department_id":"02"},{"id":"021701","name":"RECUAY","province_id":"0217","department_id":"02"},{"id":"021702","name":"CATAC","province_id":"0217","department_id":"02"},{"id":"021703","name":"COTAPARACO","province_id":"0217","department_id":"02"},{"id":"021704","name":"HUAYLLAPAMPA","province_id":"0217","department_id":"02"},{"id":"021705","name":"LLACLLIN","province_id":"0217","department_id":"02"},{"id":"021706","name":"MARCA","province_id":"0217","department_id":"02"},{"id":"021707","name":"PAMPAS CHICO","province_id":"0217","department_id":"02"},{"id":"021708","name":"PARARIN","province_id":"0217","department_id":"02"},{"id":"021709","name":"TAPACOCHA","province_id":"0217","department_id":"02"},{"id":"021710","name":"TICAPAMPA","province_id":"0217","department_id":"02"},{"id":"021801","name":"CHIMBOTE","province_id":"0218","department_id":"02"},{"id":"021802","name":"CÁCERES DEL PERÚ","province_id":"0218","department_id":"02"},{"id":"021803","name":"COISHCO","province_id":"0218","department_id":"02"},{"id":"021804","name":"MACATE","province_id":"0218","department_id":"02"},{"id":"021805","name":"MORO","province_id":"0218","department_id":"02"},{"id":"021806","name":"NEPEÑA","province_id":"0218","department_id":"02"},{"id":"021807","name":"SAMANCO","province_id":"0218","department_id":"02"},{"id":"021808","name":"SANTA","province_id":"0218","department_id":"02"},{"id":"021809","name":"NUEVO CHIMBOTE","province_id":"0218","department_id":"02"},{"id":"021901","name":"SIHUAS","province_id":"0219","department_id":"02"},{"id":"021902","name":"ACOBAMBA","province_id":"0219","department_id":"02"},{"id":"021903","name":"ALFONSO UGARTE","province_id":"0219","department_id":"02"},{"id":"021904","name":"CASHAPAMPA","province_id":"0219","department_id":"02"},{"id":"021905","name":"CHINGALPO","province_id":"0219","department_id":"02"},{"id":"021906","name":"HUAYLLABAMBA","province_id":"0219","department_id":"02"},{"id":"021907","name":"QUICHES","province_id":"0219","department_id":"02"},{"id":"021908","name":"RAGASH","province_id":"0219","department_id":"02"},{"id":"021909","name":"SAN JUAN","province_id":"0219","department_id":"02"},{"id":"021910","name":"SICSIBAMBA","province_id":"0219","department_id":"02"},{"id":"022001","name":"YUNGAY","province_id":"0220","department_id":"02"},{"id":"022002","name":"CASCAPARA","province_id":"0220","department_id":"02"},{"id":"022003","name":"MANCOS","province_id":"0220","department_id":"02"},{"id":"022004","name":"MATACOTO","province_id":"0220","department_id":"02"},{"id":"022005","name":"QUILLO","province_id":"0220","department_id":"02"},{"id":"022006","name":"RANRAHIRCA","province_id":"0220","department_id":"02"},{"id":"022007","name":"SHUPLUY","province_id":"0220","department_id":"02"},{"id":"022008","name":"YANAMA","province_id":"0220","department_id":"02"},{"id":"030101","name":"ABANCAY","province_id":"0301","department_id":"03"},{"id":"030102","name":"CHACOCHE","province_id":"0301","department_id":"03"},{"id":"030103","name":"CIRCA","province_id":"0301","department_id":"03"},{"id":"030104","name":"CURAHUASI","province_id":"0301","department_id":"03"},{"id":"030105","name":"HUANIPACA","province_id":"0301","department_id":"03"},{"id":"030106","name":"LAMBRAMA","province_id":"0301","department_id":"03"},{"id":"030107","name":"PICHIRHUA","province_id":"0301","department_id":"03"},{"id":"030108","name":"SAN PEDRO DE CACHORA","province_id":"0301","department_id":"03"},{"id":"030109","name":"TAMBURCO","province_id":"0301","department_id":"03"},{"id":"030201","name":"ANDAHUAYLAS","province_id":"0302","department_id":"03"},{"id":"030202","name":"ANDARAPA","province_id":"0302","department_id":"03"},{"id":"030203","name":"CHIARA","province_id":"0302","department_id":"03"},{"id":"030204","name":"HUANCARAMA","province_id":"0302","department_id":"03"},{"id":"030205","name":"HUANCARAY","province_id":"0302","department_id":"03"},{"id":"030206","name":"HUAYANA","province_id":"0302","department_id":"03"},{"id":"030207","name":"KISHUARA","province_id":"0302","department_id":"03"},{"id":"030208","name":"PACOBAMBA","province_id":"0302","department_id":"03"},{"id":"030209","name":"PACUCHA","province_id":"0302","department_id":"03"},{"id":"030210","name":"PAMPACHIRI","province_id":"0302","department_id":"03"},{"id":"030211","name":"POMACOCHA","province_id":"0302","department_id":"03"},{"id":"030212","name":"SAN ANTONIO DE CACHI","province_id":"0302","department_id":"03"},{"id":"030213","name":"SAN JERÓNIMO","province_id":"0302","department_id":"03"},{"id":"030214","name":"SAN MIGUEL DE CHACCRAMPA","province_id":"0302","department_id":"03"},{"id":"030215","name":"SANTA MARÍA DE CHICMO","province_id":"0302","department_id":"03"},{"id":"030216","name":"TALAVERA","province_id":"0302","department_id":"03"},{"id":"030217","name":"TUMAY HUARACA","province_id":"0302","department_id":"03"},{"id":"030218","name":"TURPO","province_id":"0302","department_id":"03"},{"id":"030219","name":"KAQUIABAMBA","province_id":"0302","department_id":"03"},{"id":"030220","name":"JOSÉ MARÍA ARGUEDAS","province_id":"0302","department_id":"03"},{"id":"030301","name":"ANTABAMBA","province_id":"0303","department_id":"03"},{"id":"030302","name":"EL ORO","province_id":"0303","department_id":"03"},{"id":"030303","name":"HUAQUIRCA","province_id":"0303","department_id":"03"},{"id":"030304","name":"JUAN ESPINOZA MEDRANO","province_id":"0303","department_id":"03"},{"id":"030305","name":"OROPESA","province_id":"0303","department_id":"03"},{"id":"030306","name":"PACHACONAS","province_id":"0303","department_id":"03"},{"id":"030307","name":"SABAINO","province_id":"0303","department_id":"03"},{"id":"030401","name":"CHALHUANCA","province_id":"0304","department_id":"03"},{"id":"030402","name":"CAPAYA","province_id":"0304","department_id":"03"},{"id":"030403","name":"CARAYBAMBA","province_id":"0304","department_id":"03"},{"id":"030404","name":"CHAPIMARCA","province_id":"0304","department_id":"03"},{"id":"030405","name":"COLCABAMBA","province_id":"0304","department_id":"03"},{"id":"030406","name":"COTARUSE","province_id":"0304","department_id":"03"},{"id":"030407","name":"IHUAYLLO","province_id":"0304","department_id":"03"},{"id":"030408","name":"JUSTO APU SAHUARAURA","province_id":"0304","department_id":"03"},{"id":"030409","name":"LUCRE","province_id":"0304","department_id":"03"},{"id":"030410","name":"POCOHUANCA","province_id":"0304","department_id":"03"},{"id":"030411","name":"SAN JUAN DE CHACÑA","province_id":"0304","department_id":"03"},{"id":"030412","name":"SAÑAYCA","province_id":"0304","department_id":"03"},{"id":"030413","name":"SORAYA","province_id":"0304","department_id":"03"},{"id":"030414","name":"TAPAIRIHUA","province_id":"0304","department_id":"03"},{"id":"030415","name":"TINTAY","province_id":"0304","department_id":"03"},{"id":"030416","name":"TORAYA","province_id":"0304","department_id":"03"},{"id":"030417","name":"YANACA","province_id":"0304","department_id":"03"},{"id":"030501","name":"TAMBOBAMBA","province_id":"0305","department_id":"03"},{"id":"030502","name":"COTABAMBAS","province_id":"0305","department_id":"03"},{"id":"030503","name":"COYLLURQUI","province_id":"0305","department_id":"03"},{"id":"030504","name":"HAQUIRA","province_id":"0305","department_id":"03"},{"id":"030505","name":"MARA","province_id":"0305","department_id":"03"},{"id":"030506","name":"CHALLHUAHUACHO","province_id":"0305","department_id":"03"},{"id":"030601","name":"CHINCHEROS","province_id":"0306","department_id":"03"},{"id":"030602","name":"ANCO_HUALLO","province_id":"0306","department_id":"03"},{"id":"030603","name":"COCHARCAS","province_id":"0306","department_id":"03"},{"id":"030604","name":"HUACCANA","province_id":"0306","department_id":"03"},{"id":"030605","name":"OCOBAMBA","province_id":"0306","department_id":"03"},{"id":"030606","name":"ONGOY","province_id":"0306","department_id":"03"},{"id":"030607","name":"URANMARCA","province_id":"0306","department_id":"03"},{"id":"030608","name":"RANRACANCHA","province_id":"0306","department_id":"03"},{"id":"030609","name":"ROCCHACC","province_id":"0306","department_id":"03"},{"id":"030610","name":"EL PORVENIR","province_id":"0306","department_id":"03"},{"id":"030611","name":"LOS CHANKAS","province_id":"0306","department_id":"03"},{"id":"030701","name":"CHUQUIBAMBILLA","province_id":"0307","department_id":"03"},{"id":"030702","name":"CURPAHUASI","province_id":"0307","department_id":"03"},{"id":"030703","name":"GAMARRA","province_id":"0307","department_id":"03"},{"id":"030704","name":"HUAYLLATI","province_id":"0307","department_id":"03"},{"id":"030705","name":"MAMARA","province_id":"0307","department_id":"03"},{"id":"030706","name":"MICAELA BASTIDAS","province_id":"0307","department_id":"03"},{"id":"030707","name":"PATAYPAMPA","province_id":"0307","department_id":"03"},{"id":"030708","name":"PROGRESO","province_id":"0307","department_id":"03"},{"id":"030709","name":"SAN ANTONIO","province_id":"0307","department_id":"03"},{"id":"030710","name":"SANTA ROSA","province_id":"0307","department_id":"03"},{"id":"030711","name":"TURPAY","province_id":"0307","department_id":"03"},{"id":"030712","name":"VILCABAMBA","province_id":"0307","department_id":"03"},{"id":"030713","name":"VIRUNDO","province_id":"0307","department_id":"03"},{"id":"030714","name":"CURASCO","province_id":"0307","department_id":"03"},{"id":"040101","name":"AREQUIPA","province_id":"0401","department_id":"04"},{"id":"040102","name":"ALTO SELVA ALEGRE","province_id":"0401","department_id":"04"},{"id":"040103","name":"CAYMA","province_id":"0401","department_id":"04"},{"id":"040104","name":"CERRO COLORADO","province_id":"0401","department_id":"04"},{"id":"040105","name":"CHARACATO","province_id":"0401","department_id":"04"},{"id":"040106","name":"CHIGUATA","province_id":"0401","department_id":"04"},{"id":"040107","name":"JACOBO HUNTER","province_id":"0401","department_id":"04"},{"id":"040108","name":"LA JOYA","province_id":"0401","department_id":"04"},{"id":"040109","name":"MARIANO MELGAR","province_id":"0401","department_id":"04"},{"id":"040110","name":"MIRAFLORES","province_id":"0401","department_id":"04"},{"id":"040111","name":"MOLLEBAYA","province_id":"0401","department_id":"04"},{"id":"040112","name":"PAUCARPATA","province_id":"0401","department_id":"04"},{"id":"040113","name":"POCSI","province_id":"0401","department_id":"04"},{"id":"040114","name":"POLOBAYA","province_id":"0401","department_id":"04"},{"id":"040115","name":"QUEQUEÑA","province_id":"0401","department_id":"04"},{"id":"040116","name":"SABANDIA","province_id":"0401","department_id":"04"},{"id":"040117","name":"SACHACA","province_id":"0401","department_id":"04"},{"id":"040118","name":"SAN JUAN DE SIGUAS","province_id":"0401","department_id":"04"},{"id":"040119","name":"SAN JUAN DE TARUCANI","province_id":"0401","department_id":"04"},{"id":"040120","name":"SANTA ISABEL DE SIGUAS","province_id":"0401","department_id":"04"},{"id":"040121","name":"SANTA RITA DE SIGUAS","province_id":"0401","department_id":"04"},{"id":"040122","name":"SOCABAYA","province_id":"0401","department_id":"04"},{"id":"040123","name":"TIABAYA","province_id":"0401","department_id":"04"},{"id":"040124","name":"UCHUMAYO","province_id":"0401","department_id":"04"},{"id":"040125","name":"VITOR","province_id":"0401","department_id":"04"},{"id":"040126","name":"YANAHUARA","province_id":"0401","department_id":"04"},{"id":"040127","name":"YARABAMBA","province_id":"0401","department_id":"04"},{"id":"040128","name":"YURA","province_id":"0401","department_id":"04"},{"id":"040129","name":"JOSÉ LUIS BUSTAMANTE Y RIVERO","province_id":"0401","department_id":"04"},{"id":"040201","name":"CAMANÁ","province_id":"0402","department_id":"04"},{"id":"040202","name":"JOSÉ MARÍA QUIMPER","province_id":"0402","department_id":"04"},{"id":"040203","name":"MARIANO NICOLÁS VALCÁRCEL","province_id":"0402","department_id":"04"},{"id":"040204","name":"MARISCAL CÁCERES","province_id":"0402","department_id":"04"},{"id":"040205","name":"NICOLÁS DE PIEROLA","province_id":"0402","department_id":"04"},{"id":"040206","name":"OCOÑA","province_id":"0402","department_id":"04"},{"id":"040207","name":"QUILCA","province_id":"0402","department_id":"04"},{"id":"040208","name":"SAMUEL PASTOR","province_id":"0402","department_id":"04"},{"id":"040301","name":"CARAVELÍ","province_id":"0403","department_id":"04"},{"id":"040302","name":"ACARÍ","province_id":"0403","department_id":"04"},{"id":"040303","name":"ATICO","province_id":"0403","department_id":"04"},{"id":"040304","name":"ATIQUIPA","province_id":"0403","department_id":"04"},{"id":"040305","name":"BELLA UNIÓN","province_id":"0403","department_id":"04"},{"id":"040306","name":"CAHUACHO","province_id":"0403","department_id":"04"},{"id":"040307","name":"CHALA","province_id":"0403","department_id":"04"},{"id":"040308","name":"CHAPARRA","province_id":"0403","department_id":"04"},{"id":"040309","name":"HUANUHUANU","province_id":"0403","department_id":"04"},{"id":"040310","name":"JAQUI","province_id":"0403","department_id":"04"},{"id":"040311","name":"LOMAS","province_id":"0403","department_id":"04"},{"id":"040312","name":"QUICACHA","province_id":"0403","department_id":"04"},{"id":"040313","name":"YAUCA","province_id":"0403","department_id":"04"},{"id":"040401","name":"APLAO","province_id":"0404","department_id":"04"},{"id":"040402","name":"ANDAGUA","province_id":"0404","department_id":"04"},{"id":"040403","name":"AYO","province_id":"0404","department_id":"04"},{"id":"040404","name":"CHACHAS","province_id":"0404","department_id":"04"},{"id":"040405","name":"CHILCAYMARCA","province_id":"0404","department_id":"04"},{"id":"040406","name":"CHOCO","province_id":"0404","department_id":"04"},{"id":"040407","name":"HUANCARQUI","province_id":"0404","department_id":"04"},{"id":"040408","name":"MACHAGUAY","province_id":"0404","department_id":"04"},{"id":"040409","name":"ORCOPAMPA","province_id":"0404","department_id":"04"},{"id":"040410","name":"PAMPACOLCA","province_id":"0404","department_id":"04"},{"id":"040411","name":"TIPAN","province_id":"0404","department_id":"04"},{"id":"040412","name":"UÑON","province_id":"0404","department_id":"04"},{"id":"040413","name":"URACA","province_id":"0404","department_id":"04"},{"id":"040414","name":"VIRACO","province_id":"0404","department_id":"04"},{"id":"040501","name":"CHIVAY","province_id":"0405","department_id":"04"},{"id":"040502","name":"ACHOMA","province_id":"0405","department_id":"04"},{"id":"040503","name":"CABANACONDE","province_id":"0405","department_id":"04"},{"id":"040504","name":"CALLALLI","province_id":"0405","department_id":"04"},{"id":"040505","name":"CAYLLOMA","province_id":"0405","department_id":"04"},{"id":"040506","name":"COPORAQUE","province_id":"0405","department_id":"04"},{"id":"040507","name":"HUAMBO","province_id":"0405","department_id":"04"},{"id":"040508","name":"HUANCA","province_id":"0405","department_id":"04"},{"id":"040509","name":"ICHUPAMPA","province_id":"0405","department_id":"04"},{"id":"040510","name":"LARI","province_id":"0405","department_id":"04"},{"id":"040511","name":"LLUTA","province_id":"0405","department_id":"04"},{"id":"040512","name":"MACA","province_id":"0405","department_id":"04"},{"id":"040513","name":"MADRIGAL","province_id":"0405","department_id":"04"},{"id":"040514","name":"SAN ANTONIO DE CHUCA","province_id":"0405","department_id":"04"},{"id":"040515","name":"SIBAYO","province_id":"0405","department_id":"04"},{"id":"040516","name":"TAPAY","province_id":"0405","department_id":"04"},{"id":"040517","name":"TISCO","province_id":"0405","department_id":"04"},{"id":"040518","name":"TUTI","province_id":"0405","department_id":"04"},{"id":"040519","name":"YANQUE","province_id":"0405","department_id":"04"},{"id":"040520","name":"MAJES","province_id":"0405","department_id":"04"},{"id":"040601","name":"CHUQUIBAMBA","province_id":"0406","department_id":"04"},{"id":"040602","name":"ANDARAY","province_id":"0406","department_id":"04"},{"id":"040603","name":"CAYARANI","province_id":"0406","department_id":"04"},{"id":"040604","name":"CHICHAS","province_id":"0406","department_id":"04"},{"id":"040605","name":"IRAY","province_id":"0406","department_id":"04"},{"id":"040606","name":"RÍO GRANDE","province_id":"0406","department_id":"04"},{"id":"040607","name":"SALAMANCA","province_id":"0406","department_id":"04"},{"id":"040608","name":"YANAQUIHUA","province_id":"0406","department_id":"04"},{"id":"040701","name":"MOLLENDO","province_id":"0407","department_id":"04"},{"id":"040702","name":"COCACHACRA","province_id":"0407","department_id":"04"},{"id":"040703","name":"DEAN VALDIVIA","province_id":"0407","department_id":"04"},{"id":"040704","name":"ISLAY","province_id":"0407","department_id":"04"},{"id":"040705","name":"MEJIA","province_id":"0407","department_id":"04"},{"id":"040706","name":"PUNTA DE BOMBÓN","province_id":"0407","department_id":"04"},{"id":"040801","name":"COTAHUASI","province_id":"0408","department_id":"04"},{"id":"040802","name":"ALCA","province_id":"0408","department_id":"04"},{"id":"040803","name":"CHARCANA","province_id":"0408","department_id":"04"},{"id":"040804","name":"HUAYNACOTAS","province_id":"0408","department_id":"04"},{"id":"040805","name":"PAMPAMARCA","province_id":"0408","department_id":"04"},{"id":"040806","name":"PUYCA","province_id":"0408","department_id":"04"},{"id":"040807","name":"QUECHUALLA","province_id":"0408","department_id":"04"},{"id":"040808","name":"SAYLA","province_id":"0408","department_id":"04"},{"id":"040809","name":"TAURIA","province_id":"0408","department_id":"04"},{"id":"040810","name":"TOMEPAMPA","province_id":"0408","department_id":"04"},{"id":"040811","name":"TORO","province_id":"0408","department_id":"04"},{"id":"050101","name":"AYACUCHO","province_id":"0501","department_id":"05"},{"id":"050102","name":"ACOCRO","province_id":"0501","department_id":"05"},{"id":"050103","name":"ACOS VINCHOS","province_id":"0501","department_id":"05"},{"id":"050104","name":"CARMEN ALTO","province_id":"0501","department_id":"05"},{"id":"050105","name":"CHIARA","province_id":"0501","department_id":"05"},{"id":"050106","name":"OCROS","province_id":"0501","department_id":"05"},{"id":"050107","name":"PACAYCASA","province_id":"0501","department_id":"05"},{"id":"050108","name":"QUINUA","province_id":"0501","department_id":"05"},{"id":"050109","name":"SAN JOSÉ DE TICLLAS","province_id":"0501","department_id":"05"},{"id":"050110","name":"SAN JUAN BAUTISTA","province_id":"0501","department_id":"05"},{"id":"050111","name":"SANTIAGO DE PISCHA","province_id":"0501","department_id":"05"},{"id":"050112","name":"SOCOS","province_id":"0501","department_id":"05"},{"id":"050113","name":"TAMBILLO","province_id":"0501","department_id":"05"},{"id":"050114","name":"VINCHOS","province_id":"0501","department_id":"05"},{"id":"050115","name":"JESÚS NAZARENO","province_id":"0501","department_id":"05"},{"id":"050116","name":"ANDRÉS AVELINO CÁCERES DORREGARAY","province_id":"0501","department_id":"05"},{"id":"050201","name":"CANGALLO","province_id":"0502","department_id":"05"},{"id":"050202","name":"CHUSCHI","province_id":"0502","department_id":"05"},{"id":"050203","name":"LOS MOROCHUCOS","province_id":"0502","department_id":"05"},{"id":"050204","name":"MARÍA PARADO DE BELLIDO","province_id":"0502","department_id":"05"},{"id":"050205","name":"PARAS","province_id":"0502","department_id":"05"},{"id":"050206","name":"TOTOS","province_id":"0502","department_id":"05"},{"id":"050301","name":"SANCOS","province_id":"0503","department_id":"05"},{"id":"050302","name":"CARAPO","province_id":"0503","department_id":"05"},{"id":"050303","name":"SACSAMARCA","province_id":"0503","department_id":"05"},{"id":"050304","name":"SANTIAGO DE LUCANAMARCA","province_id":"0503","department_id":"05"},{"id":"050401","name":"HUANTA","province_id":"0504","department_id":"05"},{"id":"050402","name":"AYAHUANCO","province_id":"0504","department_id":"05"},{"id":"050403","name":"HUAMANGUILLA","province_id":"0504","department_id":"05"},{"id":"050404","name":"IGUAIN","province_id":"0504","department_id":"05"},{"id":"050405","name":"LURICOCHA","province_id":"0504","department_id":"05"},{"id":"050406","name":"SANTILLANA","province_id":"0504","department_id":"05"},{"id":"050407","name":"SIVIA","province_id":"0504","department_id":"05"},{"id":"050408","name":"LLOCHEGUA","province_id":"0504","department_id":"05"},{"id":"050409","name":"CANAYRE","province_id":"0504","department_id":"05"},{"id":"050410","name":"UCHURACCAY","province_id":"0504","department_id":"05"},{"id":"050411","name":"PUCACOLPA","province_id":"0504","department_id":"05"},{"id":"050412","name":"CHACA","province_id":"0504","department_id":"05"},{"id":"050501","name":"SAN MIGUEL","province_id":"0505","department_id":"05"},{"id":"050502","name":"ANCO","province_id":"0505","department_id":"05"},{"id":"050503","name":"AYNA","province_id":"0505","department_id":"05"},{"id":"050504","name":"CHILCAS","province_id":"0505","department_id":"05"},{"id":"050505","name":"CHUNGUI","province_id":"0505","department_id":"05"},{"id":"050506","name":"LUIS CARRANZA","province_id":"0505","department_id":"05"},{"id":"050507","name":"SANTA ROSA","province_id":"0505","department_id":"05"},{"id":"050508","name":"TAMBO","province_id":"0505","department_id":"05"},{"id":"050509","name":"SAMUGARI","province_id":"0505","department_id":"05"},{"id":"050510","name":"ANCHIHUAY","province_id":"0505","department_id":"05"},{"id":"050511","name":"ORONCCOY","province_id":"0505","department_id":"05"},{"id":"050601","name":"PUQUIO","province_id":"0506","department_id":"05"},{"id":"050602","name":"AUCARA","province_id":"0506","department_id":"05"},{"id":"050603","name":"CABANA","province_id":"0506","department_id":"05"},{"id":"050604","name":"CARMEN SALCEDO","province_id":"0506","department_id":"05"},{"id":"050605","name":"CHAVIÑA","province_id":"0506","department_id":"05"},{"id":"050606","name":"CHIPAO","province_id":"0506","department_id":"05"},{"id":"050607","name":"HUAC-HUAS","province_id":"0506","department_id":"05"},{"id":"050608","name":"LARAMATE","province_id":"0506","department_id":"05"},{"id":"050609","name":"LEONCIO PRADO","province_id":"0506","department_id":"05"},{"id":"050610","name":"LLAUTA","province_id":"0506","department_id":"05"},{"id":"050611","name":"LUCANAS","province_id":"0506","department_id":"05"},{"id":"050612","name":"OCAÑA","province_id":"0506","department_id":"05"},{"id":"050613","name":"OTOCA","province_id":"0506","department_id":"05"},{"id":"050614","name":"SAISA","province_id":"0506","department_id":"05"},{"id":"050615","name":"SAN CRISTÓBAL","province_id":"0506","department_id":"05"},{"id":"050616","name":"SAN JUAN","province_id":"0506","department_id":"05"},{"id":"050617","name":"SAN PEDRO","province_id":"0506","department_id":"05"},{"id":"050618","name":"SAN PEDRO DE PALCO","province_id":"0506","department_id":"05"},{"id":"050619","name":"SANCOS","province_id":"0506","department_id":"05"},{"id":"050620","name":"SANTA ANA DE HUAYCAHUACHO","province_id":"0506","department_id":"05"},{"id":"050621","name":"SANTA LUCIA","province_id":"0506","department_id":"05"},{"id":"050701","name":"CORACORA","province_id":"0507","department_id":"05"},{"id":"050702","name":"CHUMPI","province_id":"0507","department_id":"05"},{"id":"050703","name":"CORONEL CASTAÑEDA","province_id":"0507","department_id":"05"},{"id":"050704","name":"PACAPAUSA","province_id":"0507","department_id":"05"},{"id":"050705","name":"PULLO","province_id":"0507","department_id":"05"},{"id":"050706","name":"PUYUSCA","province_id":"0507","department_id":"05"},{"id":"050707","name":"SAN FRANCISCO DE RAVACAYCO","province_id":"0507","department_id":"05"},{"id":"050708","name":"UPAHUACHO","province_id":"0507","department_id":"05"},{"id":"050801","name":"PAUSA","province_id":"0508","department_id":"05"},{"id":"050802","name":"COLTA","province_id":"0508","department_id":"05"},{"id":"050803","name":"CORCULLA","province_id":"0508","department_id":"05"},{"id":"050804","name":"LAMPA","province_id":"0508","department_id":"05"},{"id":"050805","name":"MARCABAMBA","province_id":"0508","department_id":"05"},{"id":"050806","name":"OYOLO","province_id":"0508","department_id":"05"},{"id":"050807","name":"PARARCA","province_id":"0508","department_id":"05"},{"id":"050808","name":"SAN JAVIER DE ALPABAMBA","province_id":"0508","department_id":"05"},{"id":"050809","name":"SAN JOSÉ DE USHUA","province_id":"0508","department_id":"05"},{"id":"050810","name":"SARA SARA","province_id":"0508","department_id":"05"},{"id":"050901","name":"QUEROBAMBA","province_id":"0509","department_id":"05"},{"id":"050902","name":"BELÉN","province_id":"0509","department_id":"05"},{"id":"050903","name":"CHALCOS","province_id":"0509","department_id":"05"},{"id":"050904","name":"CHILCAYOC","province_id":"0509","department_id":"05"},{"id":"050905","name":"HUACAÑA","province_id":"0509","department_id":"05"},{"id":"050906","name":"MORCOLLA","province_id":"0509","department_id":"05"},{"id":"050907","name":"PAICO","province_id":"0509","department_id":"05"},{"id":"050908","name":"SAN PEDRO DE LARCAY","province_id":"0509","department_id":"05"},{"id":"050909","name":"SAN SALVADOR DE QUIJE","province_id":"0509","department_id":"05"},{"id":"050910","name":"SANTIAGO DE PAUCARAY","province_id":"0509","department_id":"05"},{"id":"050911","name":"SORAS","province_id":"0509","department_id":"05"},{"id":"051001","name":"HUANCAPI","province_id":"0510","department_id":"05"},{"id":"051002","name":"ALCAMENCA","province_id":"0510","department_id":"05"},{"id":"051003","name":"APONGO","province_id":"0510","department_id":"05"},{"id":"051004","name":"ASQUIPATA","province_id":"0510","department_id":"05"},{"id":"051005","name":"CANARIA","province_id":"0510","department_id":"05"},{"id":"051006","name":"CAYARA","province_id":"0510","department_id":"05"},{"id":"051007","name":"COLCA","province_id":"0510","department_id":"05"},{"id":"051008","name":"HUAMANQUIQUIA","province_id":"0510","department_id":"05"},{"id":"051009","name":"HUANCARAYLLA","province_id":"0510","department_id":"05"},{"id":"051010","name":"HUALLA","province_id":"0510","department_id":"05"},{"id":"051011","name":"SARHUA","province_id":"0510","department_id":"05"},{"id":"051012","name":"VILCANCHOS","province_id":"0510","department_id":"05"},{"id":"051101","name":"VILCAS HUAMAN","province_id":"0511","department_id":"05"},{"id":"051102","name":"ACCOMARCA","province_id":"0511","department_id":"05"},{"id":"051103","name":"CARHUANCA","province_id":"0511","department_id":"05"},{"id":"051104","name":"CONCEPCIÓN","province_id":"0511","department_id":"05"},{"id":"051105","name":"HUAMBALPA","province_id":"0511","department_id":"05"},{"id":"051106","name":"INDEPENDENCIA","province_id":"0511","department_id":"05"},{"id":"051107","name":"SAURAMA","province_id":"0511","department_id":"05"},{"id":"051108","name":"VISCHONGO","province_id":"0511","department_id":"05"},{"id":"060101","name":"CAJAMARCA","province_id":"0601","department_id":"06"},{"id":"060102","name":"ASUNCIÓN","province_id":"0601","department_id":"06"},{"id":"060103","name":"CHETILLA","province_id":"0601","department_id":"06"},{"id":"060104","name":"COSPAN","province_id":"0601","department_id":"06"},{"id":"060105","name":"ENCAÑADA","province_id":"0601","department_id":"06"},{"id":"060106","name":"JESÚS","province_id":"0601","department_id":"06"},{"id":"060107","name":"LLACANORA","province_id":"0601","department_id":"06"},{"id":"060108","name":"LOS BAÑOS DEL INCA","province_id":"0601","department_id":"06"},{"id":"060109","name":"MAGDALENA","province_id":"0601","department_id":"06"},{"id":"060110","name":"MATARA","province_id":"0601","department_id":"06"},{"id":"060111","name":"NAMORA","province_id":"0601","department_id":"06"},{"id":"060112","name":"SAN JUAN","province_id":"0601","department_id":"06"},{"id":"060201","name":"CAJABAMBA","province_id":"0602","department_id":"06"},{"id":"060202","name":"CACHACHI","province_id":"0602","department_id":"06"},{"id":"060203","name":"CONDEBAMBA","province_id":"0602","department_id":"06"},{"id":"060204","name":"SITACOCHA","province_id":"0602","department_id":"06"},{"id":"060301","name":"CELENDÍN","province_id":"0603","department_id":"06"},{"id":"060302","name":"CHUMUCH","province_id":"0603","department_id":"06"},{"id":"060303","name":"CORTEGANA","province_id":"0603","department_id":"06"},{"id":"060304","name":"HUASMIN","province_id":"0603","department_id":"06"},{"id":"060305","name":"JORGE CHÁVEZ","province_id":"0603","department_id":"06"},{"id":"060306","name":"JOSÉ GÁLVEZ","province_id":"0603","department_id":"06"},{"id":"060307","name":"MIGUEL IGLESIAS","province_id":"0603","department_id":"06"},{"id":"060308","name":"OXAMARCA","province_id":"0603","department_id":"06"},{"id":"060309","name":"SOROCHUCO","province_id":"0603","department_id":"06"},{"id":"060310","name":"SUCRE","province_id":"0603","department_id":"06"},{"id":"060311","name":"UTCO","province_id":"0603","department_id":"06"},{"id":"060312","name":"LA LIBERTAD DE PALLAN","province_id":"0603","department_id":"06"},{"id":"060401","name":"CHOTA","province_id":"0604","department_id":"06"},{"id":"060402","name":"ANGUIA","province_id":"0604","department_id":"06"},{"id":"060403","name":"CHADIN","province_id":"0604","department_id":"06"},{"id":"060404","name":"CHIGUIRIP","province_id":"0604","department_id":"06"},{"id":"060405","name":"CHIMBAN","province_id":"0604","department_id":"06"},{"id":"060406","name":"CHOROPAMPA","province_id":"0604","department_id":"06"},{"id":"060407","name":"COCHABAMBA","province_id":"0604","department_id":"06"},{"id":"060408","name":"CONCHAN","province_id":"0604","department_id":"06"},{"id":"060409","name":"HUAMBOS","province_id":"0604","department_id":"06"},{"id":"060410","name":"LAJAS","province_id":"0604","department_id":"06"},{"id":"060411","name":"LLAMA","province_id":"0604","department_id":"06"},{"id":"060412","name":"MIRACOSTA","province_id":"0604","department_id":"06"},{"id":"060413","name":"PACCHA","province_id":"0604","department_id":"06"},{"id":"060414","name":"PION","province_id":"0604","department_id":"06"},{"id":"060415","name":"QUEROCOTO","province_id":"0604","department_id":"06"},{"id":"060416","name":"SAN JUAN DE LICUPIS","province_id":"0604","department_id":"06"},{"id":"060417","name":"TACABAMBA","province_id":"0604","department_id":"06"},{"id":"060418","name":"TOCMOCHE","province_id":"0604","department_id":"06"},{"id":"060419","name":"CHALAMARCA","province_id":"0604","department_id":"06"},{"id":"060501","name":"CONTUMAZA","province_id":"0605","department_id":"06"},{"id":"060502","name":"CHILETE","province_id":"0605","department_id":"06"},{"id":"060503","name":"CUPISNIQUE","province_id":"0605","department_id":"06"},{"id":"060504","name":"GUZMANGO","province_id":"0605","department_id":"06"},{"id":"060505","name":"SAN BENITO","province_id":"0605","department_id":"06"},{"id":"060506","name":"SANTA CRUZ DE TOLEDO","province_id":"0605","department_id":"06"},{"id":"060507","name":"TANTARICA","province_id":"0605","department_id":"06"},{"id":"060508","name":"YONAN","province_id":"0605","department_id":"06"},{"id":"060601","name":"CUTERVO","province_id":"0606","department_id":"06"},{"id":"060602","name":"CALLAYUC","province_id":"0606","department_id":"06"},{"id":"060603","name":"CHOROS","province_id":"0606","department_id":"06"},{"id":"060604","name":"CUJILLO","province_id":"0606","department_id":"06"},{"id":"060605","name":"LA RAMADA","province_id":"0606","department_id":"06"},{"id":"060606","name":"PIMPINGOS","province_id":"0606","department_id":"06"},{"id":"060607","name":"QUEROCOTILLO","province_id":"0606","department_id":"06"},{"id":"060608","name":"SAN ANDRÉS DE CUTERVO","province_id":"0606","department_id":"06"},{"id":"060609","name":"SAN JUAN DE CUTERVO","province_id":"0606","department_id":"06"},{"id":"060610","name":"SAN LUIS DE LUCMA","province_id":"0606","department_id":"06"},{"id":"060611","name":"SANTA CRUZ","province_id":"0606","department_id":"06"},{"id":"060612","name":"SANTO DOMINGO DE LA CAPILLA","province_id":"0606","department_id":"06"},{"id":"060613","name":"SANTO TOMAS","province_id":"0606","department_id":"06"},{"id":"060614","name":"SOCOTA","province_id":"0606","department_id":"06"},{"id":"060615","name":"TORIBIO CASANOVA","province_id":"0606","department_id":"06"},{"id":"060701","name":"BAMBAMARCA","province_id":"0607","department_id":"06"},{"id":"060702","name":"CHUGUR","province_id":"0607","department_id":"06"},{"id":"060703","name":"HUALGAYOC","province_id":"0607","department_id":"06"},{"id":"060801","name":"JAÉN","province_id":"0608","department_id":"06"},{"id":"060802","name":"BELLAVISTA","province_id":"0608","department_id":"06"},{"id":"060803","name":"CHONTALI","province_id":"0608","department_id":"06"},{"id":"060804","name":"COLASAY","province_id":"0608","department_id":"06"},{"id":"060805","name":"HUABAL","province_id":"0608","department_id":"06"},{"id":"060806","name":"LAS PIRIAS","province_id":"0608","department_id":"06"},{"id":"060807","name":"POMAHUACA","province_id":"0608","department_id":"06"},{"id":"060808","name":"PUCARA","province_id":"0608","department_id":"06"},{"id":"060809","name":"SALLIQUE","province_id":"0608","department_id":"06"},{"id":"060810","name":"SAN FELIPE","province_id":"0608","department_id":"06"},{"id":"060811","name":"SAN JOSÉ DEL ALTO","province_id":"0608","department_id":"06"},{"id":"060812","name":"SANTA ROSA","province_id":"0608","department_id":"06"},{"id":"060901","name":"SAN IGNACIO","province_id":"0609","department_id":"06"},{"id":"060902","name":"CHIRINOS","province_id":"0609","department_id":"06"},{"id":"060903","name":"HUARANGO","province_id":"0609","department_id":"06"},{"id":"060904","name":"LA COIPA","province_id":"0609","department_id":"06"},{"id":"060905","name":"NAMBALLE","province_id":"0609","department_id":"06"},{"id":"060906","name":"SAN JOSÉ DE LOURDES","province_id":"0609","department_id":"06"},{"id":"060907","name":"TABACONAS","province_id":"0609","department_id":"06"},{"id":"061001","name":"PEDRO GÁLVEZ","province_id":"0610","department_id":"06"},{"id":"061002","name":"CHANCAY","province_id":"0610","department_id":"06"},{"id":"061003","name":"EDUARDO VILLANUEVA","province_id":"0610","department_id":"06"},{"id":"061004","name":"GREGORIO PITA","province_id":"0610","department_id":"06"},{"id":"061005","name":"ICHOCAN","province_id":"0610","department_id":"06"},{"id":"061006","name":"JOSÉ MANUEL QUIROZ","province_id":"0610","department_id":"06"},{"id":"061007","name":"JOSÉ SABOGAL","province_id":"0610","department_id":"06"},{"id":"061101","name":"SAN MIGUEL","province_id":"0611","department_id":"06"},{"id":"061102","name":"BOLÍVAR","province_id":"0611","department_id":"06"},{"id":"061103","name":"CALQUIS","province_id":"0611","department_id":"06"},{"id":"061104","name":"CATILLUC","province_id":"0611","department_id":"06"},{"id":"061105","name":"EL PRADO","province_id":"0611","department_id":"06"},{"id":"061106","name":"LA FLORIDA","province_id":"0611","department_id":"06"},{"id":"061107","name":"LLAPA","province_id":"0611","department_id":"06"},{"id":"061108","name":"NANCHOC","province_id":"0611","department_id":"06"},{"id":"061109","name":"NIEPOS","province_id":"0611","department_id":"06"},{"id":"061110","name":"SAN GREGORIO","province_id":"0611","department_id":"06"},{"id":"061111","name":"SAN SILVESTRE DE COCHAN","province_id":"0611","department_id":"06"},{"id":"061112","name":"TONGOD","province_id":"0611","department_id":"06"},{"id":"061113","name":"UNIÓN AGUA BLANCA","province_id":"0611","department_id":"06"},{"id":"061201","name":"SAN PABLO","province_id":"0612","department_id":"06"},{"id":"061202","name":"SAN BERNARDINO","province_id":"0612","department_id":"06"},{"id":"061203","name":"SAN LUIS","province_id":"0612","department_id":"06"},{"id":"061204","name":"TUMBADEN","province_id":"0612","department_id":"06"},{"id":"061301","name":"SANTA CRUZ","province_id":"0613","department_id":"06"},{"id":"061302","name":"ANDABAMBA","province_id":"0613","department_id":"06"},{"id":"061303","name":"CATACHE","province_id":"0613","department_id":"06"},{"id":"061304","name":"CHANCAYBAÑOS","province_id":"0613","department_id":"06"},{"id":"061305","name":"LA ESPERANZA","province_id":"0613","department_id":"06"},{"id":"061306","name":"NINABAMBA","province_id":"0613","department_id":"06"},{"id":"061307","name":"PULAN","province_id":"0613","department_id":"06"},{"id":"061308","name":"SAUCEPAMPA","province_id":"0613","department_id":"06"},{"id":"061309","name":"SEXI","province_id":"0613","department_id":"06"},{"id":"061310","name":"UTICYACU","province_id":"0613","department_id":"06"},{"id":"061311","name":"YAUYUCAN","province_id":"0613","department_id":"06"},{"id":"070101","name":"CALLAO","province_id":"0701","department_id":"07"},{"id":"070102","name":"BELLAVISTA","province_id":"0701","department_id":"07"},{"id":"070103","name":"CARMEN DE LA LEGUA REYNOSO","province_id":"0701","department_id":"07"},{"id":"070104","name":"LA PERLA","province_id":"0701","department_id":"07"},{"id":"070105","name":"LA PUNTA","province_id":"0701","department_id":"07"},{"id":"070106","name":"VENTANILLA","province_id":"0701","department_id":"07"},{"id":"070107","name":"MI PERÚ","province_id":"0701","department_id":"07"},{"id":"080101","name":"CUSCO","province_id":"0801","department_id":"08"},{"id":"080102","name":"CCORCA","province_id":"0801","department_id":"08"},{"id":"080103","name":"POROY","province_id":"0801","department_id":"08"},{"id":"080104","name":"SAN JERÓNIMO","province_id":"0801","department_id":"08"},{"id":"080105","name":"SAN SEBASTIAN","province_id":"0801","department_id":"08"},{"id":"080106","name":"SANTIAGO","province_id":"0801","department_id":"08"},{"id":"080107","name":"SAYLLA","province_id":"0801","department_id":"08"},{"id":"080108","name":"WANCHAQ","province_id":"0801","department_id":"08"},{"id":"080201","name":"ACOMAYO","province_id":"0802","department_id":"08"},{"id":"080202","name":"ACOPIA","province_id":"0802","department_id":"08"},{"id":"080203","name":"ACOS","province_id":"0802","department_id":"08"},{"id":"080204","name":"MOSOC LLACTA","province_id":"0802","department_id":"08"},{"id":"080205","name":"POMACANCHI","province_id":"0802","department_id":"08"},{"id":"080206","name":"RONDOCAN","province_id":"0802","department_id":"08"},{"id":"080207","name":"SANGARARA","province_id":"0802","department_id":"08"},{"id":"080301","name":"ANTA","province_id":"0803","department_id":"08"},{"id":"080302","name":"ANCAHUASI","province_id":"0803","department_id":"08"},{"id":"080303","name":"CACHIMAYO","province_id":"0803","department_id":"08"},{"id":"080304","name":"CHINCHAYPUJIO","province_id":"0803","department_id":"08"},{"id":"080305","name":"HUAROCONDO","province_id":"0803","department_id":"08"},{"id":"080306","name":"LIMATAMBO","province_id":"0803","department_id":"08"},{"id":"080307","name":"MOLLEPATA","province_id":"0803","department_id":"08"},{"id":"080308","name":"PUCYURA","province_id":"0803","department_id":"08"},{"id":"080309","name":"ZURITE","province_id":"0803","department_id":"08"},{"id":"080401","name":"CALCA","province_id":"0804","department_id":"08"},{"id":"080402","name":"COYA","province_id":"0804","department_id":"08"},{"id":"080403","name":"LAMAY","province_id":"0804","department_id":"08"},{"id":"080404","name":"LARES","province_id":"0804","department_id":"08"},{"id":"080405","name":"PISAC","province_id":"0804","department_id":"08"},{"id":"080406","name":"SAN SALVADOR","province_id":"0804","department_id":"08"},{"id":"080407","name":"TARAY","province_id":"0804","department_id":"08"},{"id":"080408","name":"YANATILE","province_id":"0804","department_id":"08"},{"id":"080501","name":"YANAOCA","province_id":"0805","department_id":"08"},{"id":"080502","name":"CHECCA","province_id":"0805","department_id":"08"},{"id":"080503","name":"KUNTURKANKI","province_id":"0805","department_id":"08"},{"id":"080504","name":"LANGUI","province_id":"0805","department_id":"08"},{"id":"080505","name":"LAYO","province_id":"0805","department_id":"08"},{"id":"080506","name":"PAMPAMARCA","province_id":"0805","department_id":"08"},{"id":"080507","name":"QUEHUE","province_id":"0805","department_id":"08"},{"id":"080508","name":"TUPAC AMARU","province_id":"0805","department_id":"08"},{"id":"080601","name":"SICUANI","province_id":"0806","department_id":"08"},{"id":"080602","name":"CHECACUPE","province_id":"0806","department_id":"08"},{"id":"080603","name":"COMBAPATA","province_id":"0806","department_id":"08"},{"id":"080604","name":"MARANGANI","province_id":"0806","department_id":"08"},{"id":"080605","name":"PITUMARCA","province_id":"0806","department_id":"08"},{"id":"080606","name":"SAN PABLO","province_id":"0806","department_id":"08"},{"id":"080607","name":"SAN PEDRO","province_id":"0806","department_id":"08"},{"id":"080608","name":"TINTA","province_id":"0806","department_id":"08"},{"id":"080701","name":"SANTO TOMAS","province_id":"0807","department_id":"08"},{"id":"080702","name":"CAPACMARCA","province_id":"0807","department_id":"08"},{"id":"080703","name":"CHAMACA","province_id":"0807","department_id":"08"},{"id":"080704","name":"COLQUEMARCA","province_id":"0807","department_id":"08"},{"id":"080705","name":"LIVITACA","province_id":"0807","department_id":"08"},{"id":"080706","name":"LLUSCO","province_id":"0807","department_id":"08"},{"id":"080707","name":"QUIÑOTA","province_id":"0807","department_id":"08"},{"id":"080708","name":"VELILLE","province_id":"0807","department_id":"08"},{"id":"080801","name":"ESPINAR","province_id":"0808","department_id":"08"},{"id":"080802","name":"CONDOROMA","province_id":"0808","department_id":"08"},{"id":"080803","name":"COPORAQUE","province_id":"0808","department_id":"08"},{"id":"080804","name":"OCORURO","province_id":"0808","department_id":"08"},{"id":"080805","name":"PALLPATA","province_id":"0808","department_id":"08"},{"id":"080806","name":"PICHIGUA","province_id":"0808","department_id":"08"},{"id":"080807","name":"SUYCKUTAMBO","province_id":"0808","department_id":"08"},{"id":"080808","name":"ALTO PICHIGUA","province_id":"0808","department_id":"08"},{"id":"080901","name":"SANTA ANA","province_id":"0809","department_id":"08"},{"id":"080902","name":"ECHARATE","province_id":"0809","department_id":"08"},{"id":"080903","name":"HUAYOPATA","province_id":"0809","department_id":"08"},{"id":"080904","name":"MARANURA","province_id":"0809","department_id":"08"},{"id":"080905","name":"OCOBAMBA","province_id":"0809","department_id":"08"},{"id":"080906","name":"QUELLOUNO","province_id":"0809","department_id":"08"},{"id":"080907","name":"KIMBIRI","province_id":"0809","department_id":"08"},{"id":"080908","name":"SANTA TERESA","province_id":"0809","department_id":"08"},{"id":"080909","name":"VILCABAMBA","province_id":"0809","department_id":"08"},{"id":"080910","name":"PICHARI","province_id":"0809","department_id":"08"},{"id":"080911","name":"INKAWASI","province_id":"0809","department_id":"08"},{"id":"080912","name":"VILLA VIRGEN","province_id":"0809","department_id":"08"},{"id":"080913","name":"VILLA KINTIARINA","province_id":"0809","department_id":"08"},{"id":"080914","name":"MEGANTONI","province_id":"0809","department_id":"08"},{"id":"081001","name":"PARURO","province_id":"0810","department_id":"08"},{"id":"081002","name":"ACCHA","province_id":"0810","department_id":"08"},{"id":"081003","name":"CCAPI","province_id":"0810","department_id":"08"},{"id":"081004","name":"COLCHA","province_id":"0810","department_id":"08"},{"id":"081005","name":"HUANOQUITE","province_id":"0810","department_id":"08"},{"id":"081006","name":"OMACHAÇ","province_id":"0810","department_id":"08"},{"id":"081007","name":"PACCARITAMBO","province_id":"0810","department_id":"08"},{"id":"081008","name":"PILLPINTO","province_id":"0810","department_id":"08"},{"id":"081009","name":"YAURISQUE","province_id":"0810","department_id":"08"},{"id":"081101","name":"PAUCARTAMBO","province_id":"0811","department_id":"08"},{"id":"081102","name":"CAICAY","province_id":"0811","department_id":"08"},{"id":"081103","name":"CHALLABAMBA","province_id":"0811","department_id":"08"},{"id":"081104","name":"COLQUEPATA","province_id":"0811","department_id":"08"},{"id":"081105","name":"HUANCARANI","province_id":"0811","department_id":"08"},{"id":"081106","name":"KOSÑIPATA","province_id":"0811","department_id":"08"},{"id":"081201","name":"URCOS","province_id":"0812","department_id":"08"},{"id":"081202","name":"ANDAHUAYLILLAS","province_id":"0812","department_id":"08"},{"id":"081203","name":"CAMANTI","province_id":"0812","department_id":"08"},{"id":"081204","name":"CCARHUAYO","province_id":"0812","department_id":"08"},{"id":"081205","name":"CCATCA","province_id":"0812","department_id":"08"},{"id":"081206","name":"CUSIPATA","province_id":"0812","department_id":"08"},{"id":"081207","name":"HUARO","province_id":"0812","department_id":"08"},{"id":"081208","name":"LUCRE","province_id":"0812","department_id":"08"},{"id":"081209","name":"MARCAPATA","province_id":"0812","department_id":"08"},{"id":"081210","name":"OCONGATE","province_id":"0812","department_id":"08"},{"id":"081211","name":"OROPESA","province_id":"0812","department_id":"08"},{"id":"081212","name":"QUIQUIJANA","province_id":"0812","department_id":"08"},{"id":"081301","name":"URUBAMBA","province_id":"0813","department_id":"08"},{"id":"081302","name":"CHINCHERO","province_id":"0813","department_id":"08"},{"id":"081303","name":"HUAYLLABAMBA","province_id":"0813","department_id":"08"},{"id":"081304","name":"MACHUPICCHU","province_id":"0813","department_id":"08"},{"id":"081305","name":"MARAS","province_id":"0813","department_id":"08"},{"id":"081306","name":"OLLANTAYTAMBO","province_id":"0813","department_id":"08"},{"id":"081307","name":"YUCAY","province_id":"0813","department_id":"08"},{"id":"090101","name":"HUANCAVELICA","province_id":"0901","department_id":"09"},{"id":"090102","name":"ACOBAMBILLA","province_id":"0901","department_id":"09"},{"id":"090103","name":"ACORIA","province_id":"0901","department_id":"09"},{"id":"090104","name":"CONAYCA","province_id":"0901","department_id":"09"},{"id":"090105","name":"CUENCA","province_id":"0901","department_id":"09"},{"id":"090106","name":"HUACHOCOLPA","province_id":"0901","department_id":"09"},{"id":"090107","name":"HUAYLLAHUARA","province_id":"0901","department_id":"09"},{"id":"090108","name":"IZCUCHACA","province_id":"0901","department_id":"09"},{"id":"090109","name":"LARIA","province_id":"0901","department_id":"09"},{"id":"090110","name":"MANTA","province_id":"0901","department_id":"09"},{"id":"090111","name":"MARISCAL CÁCERES","province_id":"0901","department_id":"09"},{"id":"090112","name":"MOYA","province_id":"0901","department_id":"09"},{"id":"090113","name":"NUEVO OCCORO","province_id":"0901","department_id":"09"},{"id":"090114","name":"PALCA","province_id":"0901","department_id":"09"},{"id":"090115","name":"PILCHACA","province_id":"0901","department_id":"09"},{"id":"090116","name":"VILCA","province_id":"0901","department_id":"09"},{"id":"090117","name":"YAULI","province_id":"0901","department_id":"09"},{"id":"090118","name":"ASCENSIÓN","province_id":"0901","department_id":"09"},{"id":"090119","name":"HUANDO","province_id":"0901","department_id":"09"},{"id":"090201","name":"ACOBAMBA","province_id":"0902","department_id":"09"},{"id":"090202","name":"ANDABAMBA","province_id":"0902","department_id":"09"},{"id":"090203","name":"ANTA","province_id":"0902","department_id":"09"},{"id":"090204","name":"CAJA","province_id":"0902","department_id":"09"},{"id":"090205","name":"MARCAS","province_id":"0902","department_id":"09"},{"id":"090206","name":"PAUCARA","province_id":"0902","department_id":"09"},{"id":"090207","name":"POMACOCHA","province_id":"0902","department_id":"09"},{"id":"090208","name":"ROSARIO","province_id":"0902","department_id":"09"},{"id":"090301","name":"LIRCAY","province_id":"0903","department_id":"09"},{"id":"090302","name":"ANCHONGA","province_id":"0903","department_id":"09"},{"id":"090303","name":"CALLANMARCA","province_id":"0903","department_id":"09"},{"id":"090304","name":"CCOCHACCASA","province_id":"0903","department_id":"09"},{"id":"090305","name":"CHINCHO","province_id":"0903","department_id":"09"},{"id":"090306","name":"CONGALLA","province_id":"0903","department_id":"09"},{"id":"090307","name":"HUANCA-HUANCA","province_id":"0903","department_id":"09"},{"id":"090308","name":"HUAYLLAY GRANDE","province_id":"0903","department_id":"09"},{"id":"090309","name":"JULCAMARCA","province_id":"0903","department_id":"09"},{"id":"090310","name":"SAN ANTONIO DE ANTAPARCO","province_id":"0903","department_id":"09"},{"id":"090311","name":"SANTO TOMAS DE PATA","province_id":"0903","department_id":"09"},{"id":"090312","name":"SECCLLA","province_id":"0903","department_id":"09"},{"id":"090401","name":"CASTROVIRREYNA","province_id":"0904","department_id":"09"},{"id":"090402","name":"ARMA","province_id":"0904","department_id":"09"},{"id":"090403","name":"AURAHUA","province_id":"0904","department_id":"09"},{"id":"090404","name":"CAPILLAS","province_id":"0904","department_id":"09"},{"id":"090405","name":"CHUPAMARCA","province_id":"0904","department_id":"09"},{"id":"090406","name":"COCAS","province_id":"0904","department_id":"09"},{"id":"090407","name":"HUACHOS","province_id":"0904","department_id":"09"},{"id":"090408","name":"HUAMATAMBO","province_id":"0904","department_id":"09"},{"id":"090409","name":"MOLLEPAMPA","province_id":"0904","department_id":"09"},{"id":"090410","name":"SAN JUAN","province_id":"0904","department_id":"09"},{"id":"090411","name":"SANTA ANA","province_id":"0904","department_id":"09"},{"id":"090412","name":"TANTARA","province_id":"0904","department_id":"09"},{"id":"090413","name":"TICRAPO","province_id":"0904","department_id":"09"},{"id":"090501","name":"CHURCAMPA","province_id":"0905","department_id":"09"},{"id":"090502","name":"ANCO","province_id":"0905","department_id":"09"},{"id":"090503","name":"CHINCHIHUASI","province_id":"0905","department_id":"09"},{"id":"090504","name":"EL CARMEN","province_id":"0905","department_id":"09"},{"id":"090505","name":"LA MERCED","province_id":"0905","department_id":"09"},{"id":"090506","name":"LOCROJA","province_id":"0905","department_id":"09"},{"id":"090507","name":"PAUCARBAMBA","province_id":"0905","department_id":"09"},{"id":"090508","name":"SAN MIGUEL DE MAYOCC","province_id":"0905","department_id":"09"},{"id":"090509","name":"SAN PEDRO DE CORIS","province_id":"0905","department_id":"09"},{"id":"090510","name":"PACHAMARCA","province_id":"0905","department_id":"09"},{"id":"090511","name":"COSME","province_id":"0905","department_id":"09"},{"id":"090601","name":"HUAYTARA","province_id":"0906","department_id":"09"},{"id":"090602","name":"AYAVI","province_id":"0906","department_id":"09"},{"id":"090603","name":"CÓRDOVA","province_id":"0906","department_id":"09"},{"id":"090604","name":"HUAYACUNDO ARMA","province_id":"0906","department_id":"09"},{"id":"090605","name":"LARAMARCA","province_id":"0906","department_id":"09"},{"id":"090606","name":"OCOYO","province_id":"0906","department_id":"09"},{"id":"090607","name":"PILPICHACA","province_id":"0906","department_id":"09"},{"id":"090608","name":"QUERCO","province_id":"0906","department_id":"09"},{"id":"090609","name":"QUITO-ARMA","province_id":"0906","department_id":"09"},{"id":"090610","name":"SAN ANTONIO DE CUSICANCHA","province_id":"0906","department_id":"09"},{"id":"090611","name":"SAN FRANCISCO DE SANGAYAICO","province_id":"0906","department_id":"09"},{"id":"090612","name":"SAN ISIDRO","province_id":"0906","department_id":"09"},{"id":"090613","name":"SANTIAGO DE CHOCORVOS","province_id":"0906","department_id":"09"},{"id":"090614","name":"SANTIAGO DE QUIRAHUARA","province_id":"0906","department_id":"09"},{"id":"090615","name":"SANTO DOMINGO DE CAPILLAS","province_id":"0906","department_id":"09"},{"id":"090616","name":"TAMBO","province_id":"0906","department_id":"09"},{"id":"090701","name":"PAMPAS","province_id":"0907","department_id":"09"},{"id":"090702","name":"ACOSTAMBO","province_id":"0907","department_id":"09"},{"id":"090703","name":"ACRAQUIA","province_id":"0907","department_id":"09"},{"id":"090704","name":"AHUAYCHA","province_id":"0907","department_id":"09"},{"id":"090705","name":"COLCABAMBA","province_id":"0907","department_id":"09"},{"id":"090706","name":"DANIEL HERNÁNDEZ","province_id":"0907","department_id":"09"},{"id":"090707","name":"HUACHOCOLPA","province_id":"0907","department_id":"09"},{"id":"090709","name":"HUARIBAMBA","province_id":"0907","department_id":"09"},{"id":"090710","name":"ÑAHUIMPUQUIO","province_id":"0907","department_id":"09"},{"id":"090711","name":"PAZOS","province_id":"0907","department_id":"09"},{"id":"090713","name":"QUISHUAR","province_id":"0907","department_id":"09"},{"id":"090714","name":"SALCABAMBA","province_id":"0907","department_id":"09"},{"id":"090715","name":"SALCAHUASI","province_id":"0907","department_id":"09"},{"id":"090716","name":"SAN MARCOS DE ROCCHAC","province_id":"0907","department_id":"09"},{"id":"090717","name":"SURCUBAMBA","province_id":"0907","department_id":"09"},{"id":"090718","name":"TINTAY PUNCU","province_id":"0907","department_id":"09"},{"id":"090719","name":"QUICHUAS","province_id":"0907","department_id":"09"},{"id":"090720","name":"ANDAYMARCA","province_id":"0907","department_id":"09"},{"id":"090721","name":"ROBLE","province_id":"0907","department_id":"09"},{"id":"090722","name":"PICHOS","province_id":"0907","department_id":"09"},{"id":"090723","name":"SANTIAGO DE TUCUMA","province_id":"0907","department_id":"09"},{"id":"100101","name":"HUANUCO","province_id":"1001","department_id":"10"},{"id":"100102","name":"AMARILIS","province_id":"1001","department_id":"10"},{"id":"100103","name":"CHINCHAO","province_id":"1001","department_id":"10"},{"id":"100104","name":"CHURUBAMBA","province_id":"1001","department_id":"10"},{"id":"100105","name":"MARGOS","province_id":"1001","department_id":"10"},{"id":"100106","name":"QUISQUI (KICHKI)","province_id":"1001","department_id":"10"},{"id":"100107","name":"SAN FRANCISCO DE CAYRAN","province_id":"1001","department_id":"10"},{"id":"100108","name":"SAN PEDRO DE CHAULAN","province_id":"1001","department_id":"10"},{"id":"100109","name":"SANTA MARÍA DEL VALLE","province_id":"1001","department_id":"10"},{"id":"100110","name":"YARUMAYO","province_id":"1001","department_id":"10"},{"id":"100111","name":"PILLCO MARCA","province_id":"1001","department_id":"10"},{"id":"100112","name":"YACUS","province_id":"1001","department_id":"10"},{"id":"100113","name":"SAN PABLO DE PILLAO","province_id":"1001","department_id":"10"},{"id":"100201","name":"AMBO","province_id":"1002","department_id":"10"},{"id":"100202","name":"CAYNA","province_id":"1002","department_id":"10"},{"id":"100203","name":"COLPAS","province_id":"1002","department_id":"10"},{"id":"100204","name":"CONCHAMARCA","province_id":"1002","department_id":"10"},{"id":"100205","name":"HUACAR","province_id":"1002","department_id":"10"},{"id":"100206","name":"SAN FRANCISCO","province_id":"1002","department_id":"10"},{"id":"100207","name":"SAN RAFAEL","province_id":"1002","department_id":"10"},{"id":"100208","name":"TOMAY KICHWA","province_id":"1002","department_id":"10"},{"id":"100301","name":"LA UNIÓN","province_id":"1003","department_id":"10"},{"id":"100307","name":"CHUQUIS","province_id":"1003","department_id":"10"},{"id":"100311","name":"MARÍAS","province_id":"1003","department_id":"10"},{"id":"100313","name":"PACHAS","province_id":"1003","department_id":"10"},{"id":"100316","name":"QUIVILLA","province_id":"1003","department_id":"10"},{"id":"100317","name":"RIPAN","province_id":"1003","department_id":"10"},{"id":"100321","name":"SHUNQUI","province_id":"1003","department_id":"10"},{"id":"100322","name":"SILLAPATA","province_id":"1003","department_id":"10"},{"id":"100323","name":"YANAS","province_id":"1003","department_id":"10"},{"id":"100401","name":"HUACAYBAMBA","province_id":"1004","department_id":"10"},{"id":"100402","name":"CANCHABAMBA","province_id":"1004","department_id":"10"},{"id":"100403","name":"COCHABAMBA","province_id":"1004","department_id":"10"},{"id":"100404","name":"PINRA","province_id":"1004","department_id":"10"},{"id":"100501","name":"LLATA","province_id":"1005","department_id":"10"},{"id":"100502","name":"ARANCAY","province_id":"1005","department_id":"10"},{"id":"100503","name":"CHAVÍN DE PARIARCA","province_id":"1005","department_id":"10"},{"id":"100504","name":"JACAS GRANDE","province_id":"1005","department_id":"10"},{"id":"100505","name":"JIRCAN","province_id":"1005","department_id":"10"},{"id":"100506","name":"MIRAFLORES","province_id":"1005","department_id":"10"},{"id":"100507","name":"MONZÓN","province_id":"1005","department_id":"10"},{"id":"100508","name":"PUNCHAO","province_id":"1005","department_id":"10"},{"id":"100509","name":"PUÑOS","province_id":"1005","department_id":"10"},{"id":"100510","name":"SINGA","province_id":"1005","department_id":"10"},{"id":"100511","name":"TANTAMAYO","province_id":"1005","department_id":"10"},{"id":"100601","name":"RUPA-RUPA","province_id":"1006","department_id":"10"},{"id":"100602","name":"DANIEL ALOMÍA ROBLES","province_id":"1006","department_id":"10"},{"id":"100603","name":"HERMÍLIO VALDIZAN","province_id":"1006","department_id":"10"},{"id":"100604","name":"JOSÉ CRESPO Y CASTILLO","province_id":"1006","department_id":"10"},{"id":"100605","name":"LUYANDO","province_id":"1006","department_id":"10"},{"id":"100606","name":"MARIANO DAMASO BERAUN","province_id":"1006","department_id":"10"},{"id":"100607","name":"PUCAYACU","province_id":"1006","department_id":"10"},{"id":"100608","name":"CASTILLO GRANDE","province_id":"1006","department_id":"10"},{"id":"100609","name":"PUEBLO NUEVO","province_id":"1006","department_id":"10"},{"id":"100610","name":"SANTO DOMINGO DE ANDA","province_id":"1006","department_id":"10"},{"id":"100701","name":"HUACRACHUCO","province_id":"1007","department_id":"10"},{"id":"100702","name":"CHOLON","province_id":"1007","department_id":"10"},{"id":"100703","name":"SAN BUENAVENTURA","province_id":"1007","department_id":"10"},{"id":"100704","name":"LA MORADA","province_id":"1007","department_id":"10"},{"id":"100705","name":"SANTA ROSA DE ALTO YANAJANCA","province_id":"1007","department_id":"10"},{"id":"100801","name":"PANAO","province_id":"1008","department_id":"10"},{"id":"100802","name":"CHAGLLA","province_id":"1008","department_id":"10"},{"id":"100803","name":"MOLINO","province_id":"1008","department_id":"10"},{"id":"100804","name":"UMARI","province_id":"1008","department_id":"10"},{"id":"100901","name":"PUERTO INCA","province_id":"1009","department_id":"10"},{"id":"100902","name":"CODO DEL POZUZO","province_id":"1009","department_id":"10"},{"id":"100903","name":"HONORIA","province_id":"1009","department_id":"10"},{"id":"100904","name":"TOURNAVISTA","province_id":"1009","department_id":"10"},{"id":"100905","name":"YUYAPICHIS","province_id":"1009","department_id":"10"},{"id":"101001","name":"JESÚS","province_id":"1010","department_id":"10"},{"id":"101002","name":"BAÑOS","province_id":"1010","department_id":"10"},{"id":"101003","name":"JIVIA","province_id":"1010","department_id":"10"},{"id":"101004","name":"QUEROPALCA","province_id":"1010","department_id":"10"},{"id":"101005","name":"RONDOS","province_id":"1010","department_id":"10"},{"id":"101006","name":"SAN FRANCISCO DE ASÍS","province_id":"1010","department_id":"10"},{"id":"101007","name":"SAN MIGUEL DE CAURI","province_id":"1010","department_id":"10"},{"id":"101101","name":"CHAVINILLO","province_id":"1011","department_id":"10"},{"id":"101102","name":"CAHUAC","province_id":"1011","department_id":"10"},{"id":"101103","name":"CHACABAMBA","province_id":"1011","department_id":"10"},{"id":"101104","name":"APARICIO POMARES","province_id":"1011","department_id":"10"},{"id":"101105","name":"JACAS CHICO","province_id":"1011","department_id":"10"},{"id":"101106","name":"OBAS","province_id":"1011","department_id":"10"},{"id":"101107","name":"PAMPAMARCA","province_id":"1011","department_id":"10"},{"id":"101108","name":"CHORAS","province_id":"1011","department_id":"10"},{"id":"110101","name":"ICA","province_id":"1101","department_id":"11"},{"id":"110102","name":"LA TINGUIÑA","province_id":"1101","department_id":"11"},{"id":"110103","name":"LOS AQUIJES","province_id":"1101","department_id":"11"},{"id":"110104","name":"OCUCAJE","province_id":"1101","department_id":"11"},{"id":"110105","name":"PACHACUTEC","province_id":"1101","department_id":"11"},{"id":"110106","name":"PARCONA","province_id":"1101","department_id":"11"},{"id":"110107","name":"PUEBLO NUEVO","province_id":"1101","department_id":"11"},{"id":"110108","name":"SALAS","province_id":"1101","department_id":"11"},{"id":"110109","name":"SAN JOSÉ DE LOS MOLINOS","province_id":"1101","department_id":"11"},{"id":"110110","name":"SAN JUAN BAUTISTA","province_id":"1101","department_id":"11"},{"id":"110111","name":"SANTIAGO","province_id":"1101","department_id":"11"},{"id":"110112","name":"SUBTANJALLA","province_id":"1101","department_id":"11"},{"id":"110113","name":"TATE","province_id":"1101","department_id":"11"},{"id":"110114","name":"YAUCA DEL ROSARIO","province_id":"1101","department_id":"11"},{"id":"110201","name":"CHINCHA ALTA","province_id":"1102","department_id":"11"},{"id":"110202","name":"ALTO LARAN","province_id":"1102","department_id":"11"},{"id":"110203","name":"CHAVIN","province_id":"1102","department_id":"11"},{"id":"110204","name":"CHINCHA BAJA","province_id":"1102","department_id":"11"},{"id":"110205","name":"EL CARMEN","province_id":"1102","department_id":"11"},{"id":"110206","name":"GROCIO PRADO","province_id":"1102","department_id":"11"},{"id":"110207","name":"PUEBLO NUEVO","province_id":"1102","department_id":"11"},{"id":"110208","name":"SAN JUAN DE YANAC","province_id":"1102","department_id":"11"},{"id":"110209","name":"SAN PEDRO DE HUACARPANA","province_id":"1102","department_id":"11"},{"id":"110210","name":"SUNAMPE","province_id":"1102","department_id":"11"},{"id":"110211","name":"TAMBO DE MORA","province_id":"1102","department_id":"11"},{"id":"110301","name":"NASCA","province_id":"1103","department_id":"11"},{"id":"110302","name":"CHANGUILLO","province_id":"1103","department_id":"11"},{"id":"110303","name":"EL INGENIO","province_id":"1103","department_id":"11"},{"id":"110304","name":"MARCONA","province_id":"1103","department_id":"11"},{"id":"110305","name":"VISTA ALEGRE","province_id":"1103","department_id":"11"},{"id":"110401","name":"PALPA","province_id":"1104","department_id":"11"},{"id":"110402","name":"LLIPATA","province_id":"1104","department_id":"11"},{"id":"110403","name":"RÍO GRANDE","province_id":"1104","department_id":"11"},{"id":"110404","name":"SANTA CRUZ","province_id":"1104","department_id":"11"},{"id":"110405","name":"TIBILLO","province_id":"1104","department_id":"11"},{"id":"110501","name":"PISCO","province_id":"1105","department_id":"11"},{"id":"110502","name":"HUANCANO","province_id":"1105","department_id":"11"},{"id":"110503","name":"HUMAY","province_id":"1105","department_id":"11"},{"id":"110504","name":"INDEPENDENCIA","province_id":"1105","department_id":"11"},{"id":"110505","name":"PARACAS","province_id":"1105","department_id":"11"},{"id":"110506","name":"SAN ANDRÉS","province_id":"1105","department_id":"11"},{"id":"110507","name":"SAN CLEMENTE","province_id":"1105","department_id":"11"},{"id":"110508","name":"TUPAC AMARU INCA","province_id":"1105","department_id":"11"},{"id":"120101","name":"HUANCAYO","province_id":"1201","department_id":"12"},{"id":"120104","name":"CARHUACALLANGA","province_id":"1201","department_id":"12"},{"id":"120105","name":"CHACAPAMPA","province_id":"1201","department_id":"12"},{"id":"120106","name":"CHICCHE","province_id":"1201","department_id":"12"},{"id":"120107","name":"CHILCA","province_id":"1201","department_id":"12"},{"id":"120108","name":"CHONGOS ALTO","province_id":"1201","department_id":"12"},{"id":"120111","name":"CHUPURO","province_id":"1201","department_id":"12"},{"id":"120112","name":"COLCA","province_id":"1201","department_id":"12"},{"id":"120113","name":"CULLHUAS","province_id":"1201","department_id":"12"},{"id":"120114","name":"EL TAMBO","province_id":"1201","department_id":"12"},{"id":"120116","name":"HUACRAPUQUIO","province_id":"1201","department_id":"12"},{"id":"120117","name":"HUALHUAS","province_id":"1201","department_id":"12"},{"id":"120119","name":"HUANCAN","province_id":"1201","department_id":"12"},{"id":"120120","name":"HUASICANCHA","province_id":"1201","department_id":"12"},{"id":"120121","name":"HUAYUCACHI","province_id":"1201","department_id":"12"},{"id":"120122","name":"INGENIO","province_id":"1201","department_id":"12"},{"id":"120124","name":"PARIAHUANCA","province_id":"1201","department_id":"12"},{"id":"120125","name":"PILCOMAYO","province_id":"1201","department_id":"12"},{"id":"120126","name":"PUCARA","province_id":"1201","department_id":"12"},{"id":"120127","name":"QUICHUAY","province_id":"1201","department_id":"12"},{"id":"120128","name":"QUILCAS","province_id":"1201","department_id":"12"},{"id":"120129","name":"SAN AGUSTÍN","province_id":"1201","department_id":"12"},{"id":"120130","name":"SAN JERÓNIMO DE TUNAN","province_id":"1201","department_id":"12"},{"id":"120132","name":"SAÑO","province_id":"1201","department_id":"12"},{"id":"120133","name":"SAPALLANGA","province_id":"1201","department_id":"12"},{"id":"120134","name":"SICAYA","province_id":"1201","department_id":"12"},{"id":"120135","name":"SANTO DOMINGO DE ACOBAMBA","province_id":"1201","department_id":"12"},{"id":"120136","name":"VIQUES","province_id":"1201","department_id":"12"},{"id":"120201","name":"CONCEPCIÓN","province_id":"1202","department_id":"12"},{"id":"120202","name":"ACO","province_id":"1202","department_id":"12"},{"id":"120203","name":"ANDAMARCA","province_id":"1202","department_id":"12"},{"id":"120204","name":"CHAMBARA","province_id":"1202","department_id":"12"},{"id":"120205","name":"COCHAS","province_id":"1202","department_id":"12"},{"id":"120206","name":"COMAS","province_id":"1202","department_id":"12"},{"id":"120207","name":"HEROÍNAS TOLEDO","province_id":"1202","department_id":"12"},{"id":"120208","name":"MANZANARES","province_id":"1202","department_id":"12"},{"id":"120209","name":"MARISCAL CASTILLA","province_id":"1202","department_id":"12"},{"id":"120210","name":"MATAHUASI","province_id":"1202","department_id":"12"},{"id":"120211","name":"MITO","province_id":"1202","department_id":"12"},{"id":"120212","name":"NUEVE DE JULIO","province_id":"1202","department_id":"12"},{"id":"120213","name":"ORCOTUNA","province_id":"1202","department_id":"12"},{"id":"120214","name":"SAN JOSÉ DE QUERO","province_id":"1202","department_id":"12"},{"id":"120215","name":"SANTA ROSA DE OCOPA","province_id":"1202","department_id":"12"},{"id":"120301","name":"CHANCHAMAYO","province_id":"1203","department_id":"12"},{"id":"120302","name":"PERENE","province_id":"1203","department_id":"12"},{"id":"120303","name":"PICHANAQUI","province_id":"1203","department_id":"12"},{"id":"120304","name":"SAN LUIS DE SHUARO","province_id":"1203","department_id":"12"},{"id":"120305","name":"SAN RAMÓN","province_id":"1203","department_id":"12"},{"id":"120306","name":"VITOC","province_id":"1203","department_id":"12"},{"id":"120401","name":"JAUJA","province_id":"1204","department_id":"12"},{"id":"120402","name":"ACOLLA","province_id":"1204","department_id":"12"},{"id":"120403","name":"APATA","province_id":"1204","department_id":"12"},{"id":"120404","name":"ATAURA","province_id":"1204","department_id":"12"},{"id":"120405","name":"CANCHAYLLO","province_id":"1204","department_id":"12"},{"id":"120406","name":"CURICACA","province_id":"1204","department_id":"12"},{"id":"120407","name":"EL MANTARO","province_id":"1204","department_id":"12"},{"id":"120408","name":"HUAMALI","province_id":"1204","department_id":"12"},{"id":"120409","name":"HUARIPAMPA","province_id":"1204","department_id":"12"},{"id":"120410","name":"HUERTAS","province_id":"1204","department_id":"12"},{"id":"120411","name":"JANJAILLO","province_id":"1204","department_id":"12"},{"id":"120412","name":"JULCÁN","province_id":"1204","department_id":"12"},{"id":"120413","name":"LEONOR ORDÓÑEZ","province_id":"1204","department_id":"12"},{"id":"120414","name":"LLOCLLAPAMPA","province_id":"1204","department_id":"12"},{"id":"120415","name":"MARCO","province_id":"1204","department_id":"12"},{"id":"120416","name":"MASMA","province_id":"1204","department_id":"12"},{"id":"120417","name":"MASMA CHICCHE","province_id":"1204","department_id":"12"},{"id":"120418","name":"MOLINOS","province_id":"1204","department_id":"12"},{"id":"120419","name":"MONOBAMBA","province_id":"1204","department_id":"12"},{"id":"120420","name":"MUQUI","province_id":"1204","department_id":"12"},{"id":"120421","name":"MUQUIYAUYO","province_id":"1204","department_id":"12"},{"id":"120422","name":"PACA","province_id":"1204","department_id":"12"},{"id":"120423","name":"PACCHA","province_id":"1204","department_id":"12"},{"id":"120424","name":"PANCAN","province_id":"1204","department_id":"12"},{"id":"120425","name":"PARCO","province_id":"1204","department_id":"12"},{"id":"120426","name":"POMACANCHA","province_id":"1204","department_id":"12"},{"id":"120427","name":"RICRAN","province_id":"1204","department_id":"12"},{"id":"120428","name":"SAN LORENZO","province_id":"1204","department_id":"12"},{"id":"120429","name":"SAN PEDRO DE CHUNAN","province_id":"1204","department_id":"12"},{"id":"120430","name":"SAUSA","province_id":"1204","department_id":"12"},{"id":"120431","name":"SINCOS","province_id":"1204","department_id":"12"},{"id":"120432","name":"TUNAN MARCA","province_id":"1204","department_id":"12"},{"id":"120433","name":"YAULI","province_id":"1204","department_id":"12"},{"id":"120434","name":"YAUYOS","province_id":"1204","department_id":"12"},{"id":"120501","name":"JUNIN","province_id":"1205","department_id":"12"},{"id":"120502","name":"CARHUAMAYO","province_id":"1205","department_id":"12"},{"id":"120503","name":"ONDORES","province_id":"1205","department_id":"12"},{"id":"120504","name":"ULCUMAYO","province_id":"1205","department_id":"12"},{"id":"120601","name":"SATIPO","province_id":"1206","department_id":"12"},{"id":"120602","name":"COVIRIALI","province_id":"1206","department_id":"12"},{"id":"120603","name":"LLAYLLA","province_id":"1206","department_id":"12"},{"id":"120604","name":"MAZAMARI","province_id":"1206","department_id":"12"},{"id":"120605","name":"PAMPA HERMOSA","province_id":"1206","department_id":"12"},{"id":"120606","name":"PANGOA","province_id":"1206","department_id":"12"},{"id":"120607","name":"RÍO NEGRO","province_id":"1206","department_id":"12"},{"id":"120608","name":"RÍO TAMBO","province_id":"1206","department_id":"12"},{"id":"120609","name":"VIZCATAN DEL ENE","province_id":"1206","department_id":"12"},{"id":"120701","name":"TARMA","province_id":"1207","department_id":"12"},{"id":"120702","name":"ACOBAMBA","province_id":"1207","department_id":"12"},{"id":"120703","name":"HUARICOLCA","province_id":"1207","department_id":"12"},{"id":"120704","name":"HUASAHUASI","province_id":"1207","department_id":"12"},{"id":"120705","name":"LA UNIÓN","province_id":"1207","department_id":"12"},{"id":"120706","name":"PALCA","province_id":"1207","department_id":"12"},{"id":"120707","name":"PALCAMAYO","province_id":"1207","department_id":"12"},{"id":"120708","name":"SAN PEDRO DE CAJAS","province_id":"1207","department_id":"12"},{"id":"120709","name":"TAPO","province_id":"1207","department_id":"12"},{"id":"120801","name":"LA OROYA","province_id":"1208","department_id":"12"},{"id":"120802","name":"CHACAPALPA","province_id":"1208","department_id":"12"},{"id":"120803","name":"HUAY-HUAY","province_id":"1208","department_id":"12"},{"id":"120804","name":"MARCAPOMACOCHA","province_id":"1208","department_id":"12"},{"id":"120805","name":"MOROCOCHA","province_id":"1208","department_id":"12"},{"id":"120806","name":"PACCHA","province_id":"1208","department_id":"12"},{"id":"120807","name":"SANTA BÁRBARA DE CARHUACAYAN","province_id":"1208","department_id":"12"},{"id":"120808","name":"SANTA ROSA DE SACCO","province_id":"1208","department_id":"12"},{"id":"120809","name":"SUITUCANCHA","province_id":"1208","department_id":"12"},{"id":"120810","name":"YAULI","province_id":"1208","department_id":"12"},{"id":"120901","name":"CHUPACA","province_id":"1209","department_id":"12"},{"id":"120902","name":"AHUAC","province_id":"1209","department_id":"12"},{"id":"120903","name":"CHONGOS BAJO","province_id":"1209","department_id":"12"},{"id":"120904","name":"HUACHAC","province_id":"1209","department_id":"12"},{"id":"120905","name":"HUAMANCACA CHICO","province_id":"1209","department_id":"12"},{"id":"120906","name":"SAN JUAN DE ISCOS","province_id":"1209","department_id":"12"},{"id":"120907","name":"SAN JUAN DE JARPA","province_id":"1209","department_id":"12"},{"id":"120908","name":"TRES DE DICIEMBRE","province_id":"1209","department_id":"12"},{"id":"120909","name":"YANACANCHA","province_id":"1209","department_id":"12"},{"id":"130101","name":"TRUJILLO","province_id":"1301","department_id":"13"},{"id":"130102","name":"EL PORVENIR","province_id":"1301","department_id":"13"},{"id":"130103","name":"FLORENCIA DE MORA","province_id":"1301","department_id":"13"},{"id":"130104","name":"HUANCHACO","province_id":"1301","department_id":"13"},{"id":"130105","name":"LA ESPERANZA","province_id":"1301","department_id":"13"},{"id":"130106","name":"LAREDO","province_id":"1301","department_id":"13"},{"id":"130107","name":"MOCHE","province_id":"1301","department_id":"13"},{"id":"130108","name":"POROTO","province_id":"1301","department_id":"13"},{"id":"130109","name":"SALAVERRY","province_id":"1301","department_id":"13"},{"id":"130110","name":"SIMBAL","province_id":"1301","department_id":"13"},{"id":"130111","name":"VICTOR LARCO HERRERA","province_id":"1301","department_id":"13"},{"id":"130201","name":"ASCOPE","province_id":"1302","department_id":"13"},{"id":"130202","name":"CHICAMA","province_id":"1302","department_id":"13"},{"id":"130203","name":"CHOCOPE","province_id":"1302","department_id":"13"},{"id":"130204","name":"MAGDALENA DE CAO","province_id":"1302","department_id":"13"},{"id":"130205","name":"PAIJAN","province_id":"1302","department_id":"13"},{"id":"130206","name":"RÁZURI","province_id":"1302","department_id":"13"},{"id":"130207","name":"SANTIAGO DE CAO","province_id":"1302","department_id":"13"},{"id":"130208","name":"CASA GRANDE","province_id":"1302","department_id":"13"},{"id":"130301","name":"BOLÍVAR","province_id":"1303","department_id":"13"},{"id":"130302","name":"BAMBAMARCA","province_id":"1303","department_id":"13"},{"id":"130303","name":"CONDORMARCA","province_id":"1303","department_id":"13"},{"id":"130304","name":"LONGOTEA","province_id":"1303","department_id":"13"},{"id":"130305","name":"UCHUMARCA","province_id":"1303","department_id":"13"},{"id":"130306","name":"UCUNCHA","province_id":"1303","department_id":"13"},{"id":"130401","name":"CHEPEN","province_id":"1304","department_id":"13"},{"id":"130402","name":"PACANGA","province_id":"1304","department_id":"13"},{"id":"130403","name":"PUEBLO NUEVO","province_id":"1304","department_id":"13"},{"id":"130501","name":"JULCAN","province_id":"1305","department_id":"13"},{"id":"130502","name":"CALAMARCA","province_id":"1305","department_id":"13"},{"id":"130503","name":"CARABAMBA","province_id":"1305","department_id":"13"},{"id":"130504","name":"HUASO","province_id":"1305","department_id":"13"},{"id":"130601","name":"OTUZCO","province_id":"1306","department_id":"13"},{"id":"130602","name":"AGALLPAMPA","province_id":"1306","department_id":"13"},{"id":"130604","name":"CHARAT","province_id":"1306","department_id":"13"},{"id":"130605","name":"HUARANCHAL","province_id":"1306","department_id":"13"},{"id":"130606","name":"LA CUESTA","province_id":"1306","department_id":"13"},{"id":"130608","name":"MACHE","province_id":"1306","department_id":"13"},{"id":"130610","name":"PARANDAY","province_id":"1306","department_id":"13"},{"id":"130611","name":"SALPO","province_id":"1306","department_id":"13"},{"id":"130613","name":"SINSICAP","province_id":"1306","department_id":"13"},{"id":"130614","name":"USQUIL","province_id":"1306","department_id":"13"},{"id":"130701","name":"SAN PEDRO DE LLOC","province_id":"1307","department_id":"13"},{"id":"130702","name":"GUADALUPE","province_id":"1307","department_id":"13"},{"id":"130703","name":"JEQUETEPEQUE","province_id":"1307","department_id":"13"},{"id":"130704","name":"PACASMAYO","province_id":"1307","department_id":"13"},{"id":"130705","name":"SAN JOSÉ","province_id":"1307","department_id":"13"},{"id":"130801","name":"TAYABAMBA","province_id":"1308","department_id":"13"},{"id":"130802","name":"BULDIBUYO","province_id":"1308","department_id":"13"},{"id":"130803","name":"CHILLIA","province_id":"1308","department_id":"13"},{"id":"130804","name":"HUANCASPATA","province_id":"1308","department_id":"13"},{"id":"130805","name":"HUAYLILLAS","province_id":"1308","department_id":"13"},{"id":"130806","name":"HUAYO","province_id":"1308","department_id":"13"},{"id":"130807","name":"ONGON","province_id":"1308","department_id":"13"},{"id":"130808","name":"PARCOY","province_id":"1308","department_id":"13"},{"id":"130809","name":"PATAZ","province_id":"1308","department_id":"13"},{"id":"130810","name":"PIAS","province_id":"1308","department_id":"13"},{"id":"130811","name":"SANTIAGO DE CHALLAS","province_id":"1308","department_id":"13"},{"id":"130812","name":"TAURIJA","province_id":"1308","department_id":"13"},{"id":"130813","name":"URPAY","province_id":"1308","department_id":"13"},{"id":"130901","name":"HUAMACHUCO","province_id":"1309","department_id":"13"},{"id":"130902","name":"CHUGAY","province_id":"1309","department_id":"13"},{"id":"130903","name":"COCHORCO","province_id":"1309","department_id":"13"},{"id":"130904","name":"CURGOS","province_id":"1309","department_id":"13"},{"id":"130905","name":"MARCABAL","province_id":"1309","department_id":"13"},{"id":"130906","name":"SANAGORAN","province_id":"1309","department_id":"13"},{"id":"130907","name":"SARIN","province_id":"1309","department_id":"13"},{"id":"130908","name":"SARTIMBAMBA","province_id":"1309","department_id":"13"},{"id":"131001","name":"SANTIAGO DE CHUCO","province_id":"1310","department_id":"13"},{"id":"131002","name":"ANGASMARCA","province_id":"1310","department_id":"13"},{"id":"131003","name":"CACHICADAN","province_id":"1310","department_id":"13"},{"id":"131004","name":"MOLLEBAMBA","province_id":"1310","department_id":"13"},{"id":"131005","name":"MOLLEPATA","province_id":"1310","department_id":"13"},{"id":"131006","name":"QUIRUVILCA","province_id":"1310","department_id":"13"},{"id":"131007","name":"SANTA CRUZ DE CHUCA","province_id":"1310","department_id":"13"},{"id":"131008","name":"SITABAMBA","province_id":"1310","department_id":"13"},{"id":"131101","name":"CASCAS","province_id":"1311","department_id":"13"},{"id":"131102","name":"LUCMA","province_id":"1311","department_id":"13"},{"id":"131103","name":"MARMOT","province_id":"1311","department_id":"13"},{"id":"131104","name":"SAYAPULLO","province_id":"1311","department_id":"13"},{"id":"131201","name":"VIRU","province_id":"1312","department_id":"13"},{"id":"131202","name":"CHAO","province_id":"1312","department_id":"13"},{"id":"131203","name":"GUADALUPITO","province_id":"1312","department_id":"13"},{"id":"140101","name":"CHICLAYO","province_id":"1401","department_id":"14"},{"id":"140102","name":"CHONGOYAPE","province_id":"1401","department_id":"14"},{"id":"140103","name":"ETEN","province_id":"1401","department_id":"14"},{"id":"140104","name":"ETEN PUERTO","province_id":"1401","department_id":"14"},{"id":"140105","name":"JOSÉ LEONARDO ORTIZ","province_id":"1401","department_id":"14"},{"id":"140106","name":"LA VICTORIA","province_id":"1401","department_id":"14"},{"id":"140107","name":"LAGUNAS","province_id":"1401","department_id":"14"},{"id":"140108","name":"MONSEFU","province_id":"1401","department_id":"14"},{"id":"140109","name":"NUEVA ARICA","province_id":"1401","department_id":"14"},{"id":"140110","name":"OYOTUN","province_id":"1401","department_id":"14"},{"id":"140111","name":"PICSI","province_id":"1401","department_id":"14"},{"id":"140112","name":"PIMENTEL","province_id":"1401","department_id":"14"},{"id":"140113","name":"REQUE","province_id":"1401","department_id":"14"},{"id":"140114","name":"SANTA ROSA","province_id":"1401","department_id":"14"},{"id":"140115","name":"SAÑA","province_id":"1401","department_id":"14"},{"id":"140116","name":"CAYALTI","province_id":"1401","department_id":"14"},{"id":"140117","name":"PATAPO","province_id":"1401","department_id":"14"},{"id":"140118","name":"POMALCA","province_id":"1401","department_id":"14"},{"id":"140119","name":"PUCALA","province_id":"1401","department_id":"14"},{"id":"140120","name":"TUMAN","province_id":"1401","department_id":"14"},{"id":"140201","name":"FERREÑAFE","province_id":"1402","department_id":"14"},{"id":"140202","name":"CAÑARIS","province_id":"1402","department_id":"14"},{"id":"140203","name":"INCAHUASI","province_id":"1402","department_id":"14"},{"id":"140204","name":"MANUEL ANTONIO MESONES MURO","province_id":"1402","department_id":"14"},{"id":"140205","name":"PITIPO","province_id":"1402","department_id":"14"},{"id":"140206","name":"PUEBLO NUEVO","province_id":"1402","department_id":"14"},{"id":"140301","name":"LAMBAYEQUE","province_id":"1403","department_id":"14"},{"id":"140302","name":"CHOCHOPE","province_id":"1403","department_id":"14"},{"id":"140303","name":"ILLIMO","province_id":"1403","department_id":"14"},{"id":"140304","name":"JAYANCA","province_id":"1403","department_id":"14"},{"id":"140305","name":"MOCHUMI","province_id":"1403","department_id":"14"},{"id":"140306","name":"MORROPE","province_id":"1403","department_id":"14"},{"id":"140307","name":"MOTUPE","province_id":"1403","department_id":"14"},{"id":"140308","name":"OLMOS","province_id":"1403","department_id":"14"},{"id":"140309","name":"PACORA","province_id":"1403","department_id":"14"},{"id":"140310","name":"SALAS","province_id":"1403","department_id":"14"},{"id":"140311","name":"SAN JOSÉ","province_id":"1403","department_id":"14"},{"id":"140312","name":"TUCUME","province_id":"1403","department_id":"14"},{"id":"150101","name":"LIMA","province_id":"1501","department_id":"15"},{"id":"150102","name":"ANCÓN","province_id":"1501","department_id":"15"},{"id":"150103","name":"ATE","province_id":"1501","department_id":"15"},{"id":"150104","name":"BARRANCO","province_id":"1501","department_id":"15"},{"id":"150105","name":"BREÑA","province_id":"1501","department_id":"15"},{"id":"150106","name":"CARABAYLLO","province_id":"1501","department_id":"15"},{"id":"150107","name":"CHACLACAYO","province_id":"1501","department_id":"15"},{"id":"150108","name":"CHORRILLOS","province_id":"1501","department_id":"15"},{"id":"150109","name":"CIENEGUILLA","province_id":"1501","department_id":"15"},{"id":"150110","name":"COMAS","province_id":"1501","department_id":"15"},{"id":"150111","name":"EL AGUSTINO","province_id":"1501","department_id":"15"},{"id":"150112","name":"INDEPENDENCIA","province_id":"1501","department_id":"15"},{"id":"150113","name":"JESÚS MARÍA","province_id":"1501","department_id":"15"},{"id":"150114","name":"LA MOLINA","province_id":"1501","department_id":"15"},{"id":"150115","name":"LA VICTORIA","province_id":"1501","department_id":"15"},{"id":"150116","name":"LINCE","province_id":"1501","department_id":"15"},{"id":"150117","name":"LOS OLIVOS","province_id":"1501","department_id":"15"},{"id":"150118","name":"LURIGANCHO","province_id":"1501","department_id":"15"},{"id":"150119","name":"LURIN","province_id":"1501","department_id":"15"},{"id":"150120","name":"MAGDALENA DEL MAR","province_id":"1501","department_id":"15"},{"id":"150121","name":"PUEBLO LIBRE","province_id":"1501","department_id":"15"},{"id":"150122","name":"MIRAFLORES","province_id":"1501","department_id":"15"},{"id":"150123","name":"PACHACAMAC","province_id":"1501","department_id":"15"},{"id":"150124","name":"PUCUSANA","province_id":"1501","department_id":"15"},{"id":"150125","name":"PUENTE PIEDRA","province_id":"1501","department_id":"15"},{"id":"150126","name":"PUNTA HERMOSA","province_id":"1501","department_id":"15"},{"id":"150127","name":"PUNTA NEGRA","province_id":"1501","department_id":"15"},{"id":"150128","name":"RÍMAC","province_id":"1501","department_id":"15"},{"id":"150129","name":"SAN BARTOLO","province_id":"1501","department_id":"15"},{"id":"150130","name":"SAN BORJA","province_id":"1501","department_id":"15"},{"id":"150131","name":"SAN ISIDRO","province_id":"1501","department_id":"15"},{"id":"150132","name":"SAN JUAN DE LURIGANCHO","province_id":"1501","department_id":"15"},{"id":"150133","name":"SAN JUAN DE MIRAFLORES","province_id":"1501","department_id":"15"},{"id":"150134","name":"SAN LUIS","province_id":"1501","department_id":"15"},{"id":"150135","name":"SAN MARTÍN DE PORRES","province_id":"1501","department_id":"15"},{"id":"150136","name":"SAN MIGUEL","province_id":"1501","department_id":"15"},{"id":"150137","name":"SANTA ANITA","province_id":"1501","department_id":"15"},{"id":"150138","name":"SANTA MARÍA DEL MAR","province_id":"1501","department_id":"15"},{"id":"150139","name":"SANTA ROSA","province_id":"1501","department_id":"15"},{"id":"150140","name":"SANTIAGO DE SURCO","province_id":"1501","department_id":"15"},{"id":"150141","name":"SURQUILLO","province_id":"1501","department_id":"15"},{"id":"150142","name":"VILLA EL SALVADOR","province_id":"1501","department_id":"15"},{"id":"150143","name":"VILLA MARÍA DEL TRIUNFO","province_id":"1501","department_id":"15"},{"id":"150201","name":"BARRANCA","province_id":"1502","department_id":"15"},{"id":"150202","name":"PARAMONGA","province_id":"1502","department_id":"15"},{"id":"150203","name":"PATIVILCA","province_id":"1502","department_id":"15"},{"id":"150204","name":"SUPE","province_id":"1502","department_id":"15"},{"id":"150205","name":"SUPE PUERTO","province_id":"1502","department_id":"15"},{"id":"150301","name":"CAJATAMBO","province_id":"1503","department_id":"15"},{"id":"150302","name":"COPA","province_id":"1503","department_id":"15"},{"id":"150303","name":"GORGOR","province_id":"1503","department_id":"15"},{"id":"150304","name":"HUANCAPON","province_id":"1503","department_id":"15"},{"id":"150305","name":"MANAS","province_id":"1503","department_id":"15"},{"id":"150401","name":"CANTA","province_id":"1504","department_id":"15"},{"id":"150402","name":"ARAHUAY","province_id":"1504","department_id":"15"},{"id":"150403","name":"HUAMANTANGA","province_id":"1504","department_id":"15"},{"id":"150404","name":"HUAROS","province_id":"1504","department_id":"15"},{"id":"150405","name":"LACHAQUI","province_id":"1504","department_id":"15"},{"id":"150406","name":"SAN BUENAVENTURA","province_id":"1504","department_id":"15"},{"id":"150407","name":"SANTA ROSA DE QUIVES","province_id":"1504","department_id":"15"},{"id":"150501","name":"SAN VICENTE DE CAÑETE","province_id":"1505","department_id":"15"},{"id":"150502","name":"ASIA","province_id":"1505","department_id":"15"},{"id":"150503","name":"CALANGO","province_id":"1505","department_id":"15"},{"id":"150504","name":"CERRO AZUL","province_id":"1505","department_id":"15"},{"id":"150505","name":"CHILCA","province_id":"1505","department_id":"15"},{"id":"150506","name":"COAYLLO","province_id":"1505","department_id":"15"},{"id":"150507","name":"IMPERIAL","province_id":"1505","department_id":"15"},{"id":"150508","name":"LUNAHUANA","province_id":"1505","department_id":"15"},{"id":"150509","name":"MALA","province_id":"1505","department_id":"15"},{"id":"150510","name":"NUEVO IMPERIAL","province_id":"1505","department_id":"15"},{"id":"150511","name":"PACARAN","province_id":"1505","department_id":"15"},{"id":"150512","name":"QUILMANA","province_id":"1505","department_id":"15"},{"id":"150513","name":"SAN ANTONIO","province_id":"1505","department_id":"15"},{"id":"150514","name":"SAN LUIS","province_id":"1505","department_id":"15"},{"id":"150515","name":"SANTA CRUZ DE FLORES","province_id":"1505","department_id":"15"},{"id":"150516","name":"ZÚÑIGA","province_id":"1505","department_id":"15"},{"id":"150601","name":"HUARAL","province_id":"1506","department_id":"15"},{"id":"150602","name":"ATAVILLOS ALTO","province_id":"1506","department_id":"15"},{"id":"150603","name":"ATAVILLOS BAJO","province_id":"1506","department_id":"15"},{"id":"150604","name":"AUCALLAMA","province_id":"1506","department_id":"15"},{"id":"150605","name":"CHANCAY","province_id":"1506","department_id":"15"},{"id":"150606","name":"IHUARI","province_id":"1506","department_id":"15"},{"id":"150607","name":"LAMPIAN","province_id":"1506","department_id":"15"},{"id":"150608","name":"PACARAOS","province_id":"1506","department_id":"15"},{"id":"150609","name":"SAN MIGUEL DE ACOS","province_id":"1506","department_id":"15"},{"id":"150610","name":"SANTA CRUZ DE ANDAMARCA","province_id":"1506","department_id":"15"},{"id":"150611","name":"SUMBILCA","province_id":"1506","department_id":"15"},{"id":"150612","name":"VEINTISIETE DE NOVIEMBRE","province_id":"1506","department_id":"15"},{"id":"150701","name":"MATUCANA","province_id":"1507","department_id":"15"},{"id":"150702","name":"ANTIOQUIA","province_id":"1507","department_id":"15"},{"id":"150703","name":"CALLAHUANCA","province_id":"1507","department_id":"15"},{"id":"150704","name":"CARAMPOMA","province_id":"1507","department_id":"15"},{"id":"150705","name":"CHICLA","province_id":"1507","department_id":"15"},{"id":"150706","name":"CUENCA","province_id":"1507","department_id":"15"},{"id":"150707","name":"HUACHUPAMPA","province_id":"1507","department_id":"15"},{"id":"150708","name":"HUANZA","province_id":"1507","department_id":"15"},{"id":"150709","name":"HUAROCHIRI","province_id":"1507","department_id":"15"},{"id":"150710","name":"LAHUAYTAMBO","province_id":"1507","department_id":"15"},{"id":"150711","name":"LANGA","province_id":"1507","department_id":"15"},{"id":"150712","name":"LARAOS","province_id":"1507","department_id":"15"},{"id":"150713","name":"MARIATANA","province_id":"1507","department_id":"15"},{"id":"150714","name":"RICARDO PALMA","province_id":"1507","department_id":"15"},{"id":"150715","name":"SAN ANDRÉS DE TUPICOCHA","province_id":"1507","department_id":"15"},{"id":"150716","name":"SAN ANTONIO","province_id":"1507","department_id":"15"},{"id":"150717","name":"SAN BARTOLOMÉ","province_id":"1507","department_id":"15"},{"id":"150718","name":"SAN DAMIAN","province_id":"1507","department_id":"15"},{"id":"150719","name":"SAN JUAN DE IRIS","province_id":"1507","department_id":"15"},{"id":"150720","name":"SAN JUAN DE TANTARANCHE","province_id":"1507","department_id":"15"},{"id":"150721","name":"SAN LORENZO DE QUINTI","province_id":"1507","department_id":"15"},{"id":"150722","name":"SAN MATEO","province_id":"1507","department_id":"15"},{"id":"150723","name":"SAN MATEO DE OTAO","province_id":"1507","department_id":"15"},{"id":"150724","name":"SAN PEDRO DE CASTA","province_id":"1507","department_id":"15"},{"id":"150725","name":"SAN PEDRO DE HUANCAYRE","province_id":"1507","department_id":"15"},{"id":"150726","name":"SANGALLAYA","province_id":"1507","department_id":"15"},{"id":"150727","name":"SANTA CRUZ DE COCACHACRA","province_id":"1507","department_id":"15"},{"id":"150728","name":"SANTA EULALIA","province_id":"1507","department_id":"15"},{"id":"150729","name":"SANTIAGO DE ANCHUCAYA","province_id":"1507","department_id":"15"},{"id":"150730","name":"SANTIAGO DE TUNA","province_id":"1507","department_id":"15"},{"id":"150731","name":"SANTO DOMINGO DE LOS OLLEROS","province_id":"1507","department_id":"15"},{"id":"150732","name":"SURCO","province_id":"1507","department_id":"15"},{"id":"150801","name":"HUACHO","province_id":"1508","department_id":"15"},{"id":"150802","name":"AMBAR","province_id":"1508","department_id":"15"},{"id":"150803","name":"CALETA DE CARQUIN","province_id":"1508","department_id":"15"},{"id":"150804","name":"CHECRAS","province_id":"1508","department_id":"15"},{"id":"150805","name":"HUALMAY","province_id":"1508","department_id":"15"},{"id":"150806","name":"HUAURA","province_id":"1508","department_id":"15"},{"id":"150807","name":"LEONCIO PRADO","province_id":"1508","department_id":"15"},{"id":"150808","name":"PACCHO","province_id":"1508","department_id":"15"},{"id":"150809","name":"SANTA LEONOR","province_id":"1508","department_id":"15"},{"id":"150810","name":"SANTA MARÍA","province_id":"1508","department_id":"15"},{"id":"150811","name":"SAYAN","province_id":"1508","department_id":"15"},{"id":"150812","name":"VEGUETA","province_id":"1508","department_id":"15"},{"id":"150901","name":"OYON","province_id":"1509","department_id":"15"},{"id":"150902","name":"ANDAJES","province_id":"1509","department_id":"15"},{"id":"150903","name":"CAUJUL","province_id":"1509","department_id":"15"},{"id":"150904","name":"COCHAMARCA","province_id":"1509","department_id":"15"},{"id":"150905","name":"NAVAN","province_id":"1509","department_id":"15"},{"id":"150906","name":"PACHANGARA","province_id":"1509","department_id":"15"},{"id":"151001","name":"YAUYOS","province_id":"1510","department_id":"15"},{"id":"151002","name":"ALIS","province_id":"1510","department_id":"15"},{"id":"151003","name":"ALLAUCA","province_id":"1510","department_id":"15"},{"id":"151004","name":"AYAVIRI","province_id":"1510","department_id":"15"},{"id":"151005","name":"AZÁNGARO","province_id":"1510","department_id":"15"},{"id":"151006","name":"CACRA","province_id":"1510","department_id":"15"},{"id":"151007","name":"CARANIA","province_id":"1510","department_id":"15"},{"id":"151008","name":"CATAHUASI","province_id":"1510","department_id":"15"},{"id":"151009","name":"CHOCOS","province_id":"1510","department_id":"15"},{"id":"151010","name":"COCHAS","province_id":"1510","department_id":"15"},{"id":"151011","name":"COLONIA","province_id":"1510","department_id":"15"},{"id":"151012","name":"HONGOS","province_id":"1510","department_id":"15"},{"id":"151013","name":"HUAMPARA","province_id":"1510","department_id":"15"},{"id":"151014","name":"HUANCAYA","province_id":"1510","department_id":"15"},{"id":"151015","name":"HUANGASCAR","province_id":"1510","department_id":"15"},{"id":"151016","name":"HUANTAN","province_id":"1510","department_id":"15"},{"id":"151017","name":"HUAÑEC","province_id":"1510","department_id":"15"},{"id":"151018","name":"LARAOS","province_id":"1510","department_id":"15"},{"id":"151019","name":"LINCHA","province_id":"1510","department_id":"15"},{"id":"151020","name":"MADEAN","province_id":"1510","department_id":"15"},{"id":"151021","name":"MIRAFLORES","province_id":"1510","department_id":"15"},{"id":"151022","name":"OMAS","province_id":"1510","department_id":"15"},{"id":"151023","name":"PUTINZA","province_id":"1510","department_id":"15"},{"id":"151024","name":"QUINCHES","province_id":"1510","department_id":"15"},{"id":"151025","name":"QUINOCAY","province_id":"1510","department_id":"15"},{"id":"151026","name":"SAN JOAQUÍN","province_id":"1510","department_id":"15"},{"id":"151027","name":"SAN PEDRO DE PILAS","province_id":"1510","department_id":"15"},{"id":"151028","name":"TANTA","province_id":"1510","department_id":"15"},{"id":"151029","name":"TAURIPAMPA","province_id":"1510","department_id":"15"},{"id":"151030","name":"TOMAS","province_id":"1510","department_id":"15"},{"id":"151031","name":"TUPE","province_id":"1510","department_id":"15"},{"id":"151032","name":"VIÑAC","province_id":"1510","department_id":"15"},{"id":"151033","name":"VITIS","province_id":"1510","department_id":"15"},{"id":"160101","name":"IQUITOS","province_id":"1601","department_id":"16"},{"id":"160102","name":"ALTO NANAY","province_id":"1601","department_id":"16"},{"id":"160103","name":"FERNANDO LORES","province_id":"1601","department_id":"16"},{"id":"160104","name":"INDIANA","province_id":"1601","department_id":"16"},{"id":"160105","name":"LAS AMAZONAS","province_id":"1601","department_id":"16"},{"id":"160106","name":"MAZAN","province_id":"1601","department_id":"16"},{"id":"160107","name":"NAPO","province_id":"1601","department_id":"16"},{"id":"160108","name":"PUNCHANA","province_id":"1601","department_id":"16"},{"id":"160110","name":"TORRES CAUSANA","province_id":"1601","department_id":"16"},{"id":"160112","name":"BELÉN","province_id":"1601","department_id":"16"},{"id":"160113","name":"SAN JUAN BAUTISTA","province_id":"1601","department_id":"16"},{"id":"160201","name":"YURIMAGUAS","province_id":"1602","department_id":"16"},{"id":"160202","name":"BALSAPUERTO","province_id":"1602","department_id":"16"},{"id":"160205","name":"JEBEROS","province_id":"1602","department_id":"16"},{"id":"160206","name":"LAGUNAS","province_id":"1602","department_id":"16"},{"id":"160210","name":"SANTA CRUZ","province_id":"1602","department_id":"16"},{"id":"160211","name":"TENIENTE CESAR LÓPEZ ROJAS","province_id":"1602","department_id":"16"},{"id":"160301","name":"NAUTA","province_id":"1603","department_id":"16"},{"id":"160302","name":"PARINARI","province_id":"1603","department_id":"16"},{"id":"160303","name":"TIGRE","province_id":"1603","department_id":"16"},{"id":"160304","name":"TROMPETEROS","province_id":"1603","department_id":"16"},{"id":"160305","name":"URARINAS","province_id":"1603","department_id":"16"},{"id":"160401","name":"RAMÓN CASTILLA","province_id":"1604","department_id":"16"},{"id":"160402","name":"PEBAS","province_id":"1604","department_id":"16"},{"id":"160403","name":"YAVARI","province_id":"1604","department_id":"16"},{"id":"160404","name":"SAN PABLO","province_id":"1604","department_id":"16"},{"id":"160501","name":"REQUENA","province_id":"1605","department_id":"16"},{"id":"160502","name":"ALTO TAPICHE","province_id":"1605","department_id":"16"},{"id":"160503","name":"CAPELO","province_id":"1605","department_id":"16"},{"id":"160504","name":"EMILIO SAN MARTÍN","province_id":"1605","department_id":"16"},{"id":"160505","name":"MAQUIA","province_id":"1605","department_id":"16"},{"id":"160506","name":"PUINAHUA","province_id":"1605","department_id":"16"},{"id":"160507","name":"SAQUENA","province_id":"1605","department_id":"16"},{"id":"160508","name":"SOPLIN","province_id":"1605","department_id":"16"},{"id":"160509","name":"TAPICHE","province_id":"1605","department_id":"16"},{"id":"160510","name":"JENARO HERRERA","province_id":"1605","department_id":"16"},{"id":"160511","name":"YAQUERANA","province_id":"1605","department_id":"16"},{"id":"160601","name":"CONTAMANA","province_id":"1606","department_id":"16"},{"id":"160602","name":"INAHUAYA","province_id":"1606","department_id":"16"},{"id":"160603","name":"PADRE MÁRQUEZ","province_id":"1606","department_id":"16"},{"id":"160604","name":"PAMPA HERMOSA","province_id":"1606","department_id":"16"},{"id":"160605","name":"SARAYACU","province_id":"1606","department_id":"16"},{"id":"160606","name":"VARGAS GUERRA","province_id":"1606","department_id":"16"},{"id":"160701","name":"BARRANCA","province_id":"1607","department_id":"16"},{"id":"160702","name":"CAHUAPANAS","province_id":"1607","department_id":"16"},{"id":"160703","name":"MANSERICHE","province_id":"1607","department_id":"16"},{"id":"160704","name":"MORONA","province_id":"1607","department_id":"16"},{"id":"160705","name":"PASTAZA","province_id":"1607","department_id":"16"},{"id":"160706","name":"ANDOAS","province_id":"1607","department_id":"16"},{"id":"160801","name":"PUTUMAYO","province_id":"1608","department_id":"16"},{"id":"160802","name":"ROSA PANDURO","province_id":"1608","department_id":"16"},{"id":"160803","name":"TENIENTE MANUEL CLAVERO","province_id":"1608","department_id":"16"},{"id":"160804","name":"YAGUAS","province_id":"1608","department_id":"16"},{"id":"170101","name":"TAMBOPATA","province_id":"1701","department_id":"17"},{"id":"170102","name":"INAMBARI","province_id":"1701","department_id":"17"},{"id":"170103","name":"LAS PIEDRAS","province_id":"1701","department_id":"17"},{"id":"170104","name":"LABERINTO","province_id":"1701","department_id":"17"},{"id":"170201","name":"MANU","province_id":"1702","department_id":"17"},{"id":"170202","name":"FITZCARRALD","province_id":"1702","department_id":"17"},{"id":"170203","name":"MADRE DE DIOS","province_id":"1702","department_id":"17"},{"id":"170204","name":"HUEPETUHE","province_id":"1702","department_id":"17"},{"id":"170301","name":"IÑAPARI","province_id":"1703","department_id":"17"},{"id":"170302","name":"IBERIA","province_id":"1703","department_id":"17"},{"id":"170303","name":"TAHUAMANU","province_id":"1703","department_id":"17"},{"id":"180101","name":"MOQUEGUA","province_id":"1801","department_id":"18"},{"id":"180102","name":"CARUMAS","province_id":"1801","department_id":"18"},{"id":"180103","name":"CUCHUMBAYA","province_id":"1801","department_id":"18"},{"id":"180104","name":"SAMEGUA","province_id":"1801","department_id":"18"},{"id":"180105","name":"SAN CRISTÓBAL","province_id":"1801","department_id":"18"},{"id":"180106","name":"TORATA","province_id":"1801","department_id":"18"},{"id":"180201","name":"OMATE","province_id":"1802","department_id":"18"},{"id":"180202","name":"CHOJATA","province_id":"1802","department_id":"18"},{"id":"180203","name":"COALAQUE","province_id":"1802","department_id":"18"},{"id":"180204","name":"ICHUÑA","province_id":"1802","department_id":"18"},{"id":"180205","name":"LA CAPILLA","province_id":"1802","department_id":"18"},{"id":"180206","name":"LLOQUE","province_id":"1802","department_id":"18"},{"id":"180207","name":"MATALAQUE","province_id":"1802","department_id":"18"},{"id":"180208","name":"PUQUINA","province_id":"1802","department_id":"18"},{"id":"180209","name":"QUINISTAQUILLAS","province_id":"1802","department_id":"18"},{"id":"180210","name":"UBINAS","province_id":"1802","department_id":"18"},{"id":"180211","name":"YUNGA","province_id":"1802","department_id":"18"},{"id":"180301","name":"ILO","province_id":"1803","department_id":"18"},{"id":"180302","name":"EL ALGARROBAL","province_id":"1803","department_id":"18"},{"id":"180303","name":"PACOCHA","province_id":"1803","department_id":"18"},{"id":"190101","name":"CHAUPIMARCA","province_id":"1901","department_id":"19"},{"id":"190102","name":"HUACHON","province_id":"1901","department_id":"19"},{"id":"190103","name":"HUARIACA","province_id":"1901","department_id":"19"},{"id":"190104","name":"HUAYLLAY","province_id":"1901","department_id":"19"},{"id":"190105","name":"NINACACA","province_id":"1901","department_id":"19"},{"id":"190106","name":"PALLANCHACRA","province_id":"1901","department_id":"19"},{"id":"190107","name":"PAUCARTAMBO","province_id":"1901","department_id":"19"},{"id":"190108","name":"SAN FRANCISCO DE ASÍS DE YARUSYACAN","province_id":"1901","department_id":"19"},{"id":"190109","name":"SIMON BOLÍVAR","province_id":"1901","department_id":"19"},{"id":"190110","name":"TICLACAYAN","province_id":"1901","department_id":"19"},{"id":"190111","name":"TINYAHUARCO","province_id":"1901","department_id":"19"},{"id":"190112","name":"VICCO","province_id":"1901","department_id":"19"},{"id":"190113","name":"YANACANCHA","province_id":"1901","department_id":"19"},{"id":"190201","name":"YANAHUANCA","province_id":"1902","department_id":"19"},{"id":"190202","name":"CHACAYAN","province_id":"1902","department_id":"19"},{"id":"190203","name":"GOYLLARISQUIZGA","province_id":"1902","department_id":"19"},{"id":"190204","name":"PAUCAR","province_id":"1902","department_id":"19"},{"id":"190205","name":"SAN PEDRO DE PILLAO","province_id":"1902","department_id":"19"},{"id":"190206","name":"SANTA ANA DE TUSI","province_id":"1902","department_id":"19"},{"id":"190207","name":"TAPUC","province_id":"1902","department_id":"19"},{"id":"190208","name":"VILCABAMBA","province_id":"1902","department_id":"19"},{"id":"190301","name":"OXAPAMPA","province_id":"1903","department_id":"19"},{"id":"190302","name":"CHONTABAMBA","province_id":"1903","department_id":"19"},{"id":"190303","name":"HUANCABAMBA","province_id":"1903","department_id":"19"},{"id":"190304","name":"PALCAZU","province_id":"1903","department_id":"19"},{"id":"190305","name":"POZUZO","province_id":"1903","department_id":"19"},{"id":"190306","name":"PUERTO BERMÚDEZ","province_id":"1903","department_id":"19"},{"id":"190307","name":"VILLA RICA","province_id":"1903","department_id":"19"},{"id":"190308","name":"CONSTITUCIÓN","province_id":"1903","department_id":"19"},{"id":"200101","name":"PIURA","province_id":"2001","department_id":"20"},{"id":"200104","name":"CASTILLA","province_id":"2001","department_id":"20"},{"id":"200105","name":"CATACAOS","province_id":"2001","department_id":"20"},{"id":"200107","name":"CURA MORI","province_id":"2001","department_id":"20"},{"id":"200108","name":"EL TALLAN","province_id":"2001","department_id":"20"},{"id":"200109","name":"LA ARENA","province_id":"2001","department_id":"20"},{"id":"200110","name":"LA UNIÓN","province_id":"2001","department_id":"20"},{"id":"200111","name":"LAS LOMAS","province_id":"2001","department_id":"20"},{"id":"200114","name":"TAMBO GRANDE","province_id":"2001","department_id":"20"},{"id":"200115","name":"VEINTISEIS DE OCTUBRE","province_id":"2001","department_id":"20"},{"id":"200201","name":"AYABACA","province_id":"2002","department_id":"20"},{"id":"200202","name":"FRIAS","province_id":"2002","department_id":"20"},{"id":"200203","name":"JILILI","province_id":"2002","department_id":"20"},{"id":"200204","name":"LAGUNAS","province_id":"2002","department_id":"20"},{"id":"200205","name":"MONTERO","province_id":"2002","department_id":"20"},{"id":"200206","name":"PACAIPAMPA","province_id":"2002","department_id":"20"},{"id":"200207","name":"PAIMAS","province_id":"2002","department_id":"20"},{"id":"200208","name":"SAPILLICA","province_id":"2002","department_id":"20"},{"id":"200209","name":"SICCHEZ","province_id":"2002","department_id":"20"},{"id":"200210","name":"SUYO","province_id":"2002","department_id":"20"},{"id":"200301","name":"HUANCABAMBA","province_id":"2003","department_id":"20"},{"id":"200302","name":"CANCHAQUE","province_id":"2003","department_id":"20"},{"id":"200303","name":"EL CARMEN DE LA FRONTERA","province_id":"2003","department_id":"20"},{"id":"200304","name":"HUARMACA","province_id":"2003","department_id":"20"},{"id":"200305","name":"LALAQUIZ","province_id":"2003","department_id":"20"},{"id":"200306","name":"SAN MIGUEL DE EL FAIQUE","province_id":"2003","department_id":"20"},{"id":"200307","name":"SONDOR","province_id":"2003","department_id":"20"},{"id":"200308","name":"SONDORILLO","province_id":"2003","department_id":"20"},{"id":"200401","name":"CHULUCANAS","province_id":"2004","department_id":"20"},{"id":"200402","name":"BUENOS AIRES","province_id":"2004","department_id":"20"},{"id":"200403","name":"CHALACO","province_id":"2004","department_id":"20"},{"id":"200404","name":"LA MATANZA","province_id":"2004","department_id":"20"},{"id":"200405","name":"MORROPON","province_id":"2004","department_id":"20"},{"id":"200406","name":"SALITRAL","province_id":"2004","department_id":"20"},{"id":"200407","name":"SAN JUAN DE BIGOTE","province_id":"2004","department_id":"20"},{"id":"200408","name":"SANTA CATALINA DE MOSSA","province_id":"2004","department_id":"20"},{"id":"200409","name":"SANTO DOMINGO","province_id":"2004","department_id":"20"},{"id":"200410","name":"YAMANGO","province_id":"2004","department_id":"20"},{"id":"200501","name":"PAITA","province_id":"2005","department_id":"20"},{"id":"200502","name":"AMOTAPE","province_id":"2005","department_id":"20"},{"id":"200503","name":"ARENAL","province_id":"2005","department_id":"20"},{"id":"200504","name":"COLAN","province_id":"2005","department_id":"20"},{"id":"200505","name":"LA HUACA","province_id":"2005","department_id":"20"},{"id":"200506","name":"TAMARINDO","province_id":"2005","department_id":"20"},{"id":"200507","name":"VICHAYAL","province_id":"2005","department_id":"20"},{"id":"200601","name":"SULLANA","province_id":"2006","department_id":"20"},{"id":"200602","name":"BELLAVISTA","province_id":"2006","department_id":"20"},{"id":"200603","name":"IGNACIO ESCUDERO","province_id":"2006","department_id":"20"},{"id":"200604","name":"LANCONES","province_id":"2006","department_id":"20"},{"id":"200605","name":"MARCAVELICA","province_id":"2006","department_id":"20"},{"id":"200606","name":"MIGUEL CHECA","province_id":"2006","department_id":"20"},{"id":"200607","name":"QUERECOTILLO","province_id":"2006","department_id":"20"},{"id":"200608","name":"SALITRAL","province_id":"2006","department_id":"20"},{"id":"200701","name":"PARIÑAS","province_id":"2007","department_id":"20"},{"id":"200702","name":"EL ALTO","province_id":"2007","department_id":"20"},{"id":"200703","name":"LA BREA","province_id":"2007","department_id":"20"},{"id":"200704","name":"LOBITOS","province_id":"2007","department_id":"20"},{"id":"200705","name":"LOS ORGANOS","province_id":"2007","department_id":"20"},{"id":"200706","name":"MANCORA","province_id":"2007","department_id":"20"},{"id":"200801","name":"SECHURA","province_id":"2008","department_id":"20"},{"id":"200802","name":"BELLAVISTA DE LA UNIÓN","province_id":"2008","department_id":"20"},{"id":"200803","name":"BERNAL","province_id":"2008","department_id":"20"},{"id":"200804","name":"CRISTO NOS VALGA","province_id":"2008","department_id":"20"},{"id":"200805","name":"VICE","province_id":"2008","department_id":"20"},{"id":"200806","name":"RINCONADA LLICUAR","province_id":"2008","department_id":"20"},{"id":"210101","name":"PUNO","province_id":"2101","department_id":"21"},{"id":"210102","name":"ACORA","province_id":"2101","department_id":"21"},{"id":"210103","name":"AMANTANI","province_id":"2101","department_id":"21"},{"id":"210104","name":"ATUNCOLLA","province_id":"2101","department_id":"21"},{"id":"210105","name":"CAPACHICA","province_id":"2101","department_id":"21"},{"id":"210106","name":"CHUCUITO","province_id":"2101","department_id":"21"},{"id":"210107","name":"COATA","province_id":"2101","department_id":"21"},{"id":"210108","name":"HUATA","province_id":"2101","department_id":"21"},{"id":"210109","name":"MAÑAZO","province_id":"2101","department_id":"21"},{"id":"210110","name":"PAUCARCOLLA","province_id":"2101","department_id":"21"},{"id":"210111","name":"PICHACANI","province_id":"2101","department_id":"21"},{"id":"210112","name":"PLATERIA","province_id":"2101","department_id":"21"},{"id":"210113","name":"SAN ANTONIO","province_id":"2101","department_id":"21"},{"id":"210114","name":"TIQUILLACA","province_id":"2101","department_id":"21"},{"id":"210115","name":"VILQUE","province_id":"2101","department_id":"21"},{"id":"210201","name":"AZÁNGARO","province_id":"2102","department_id":"21"},{"id":"210202","name":"ACHAYA","province_id":"2102","department_id":"21"},{"id":"210203","name":"ARAPA","province_id":"2102","department_id":"21"},{"id":"210204","name":"ASILLO","province_id":"2102","department_id":"21"},{"id":"210205","name":"CAMINACA","province_id":"2102","department_id":"21"},{"id":"210206","name":"CHUPA","province_id":"2102","department_id":"21"},{"id":"210207","name":"JOSÉ DOMINGO CHOQUEHUANCA","province_id":"2102","department_id":"21"},{"id":"210208","name":"MUÑANI","province_id":"2102","department_id":"21"},{"id":"210209","name":"POTONI","province_id":"2102","department_id":"21"},{"id":"210210","name":"SAMAN","province_id":"2102","department_id":"21"},{"id":"210211","name":"SAN ANTON","province_id":"2102","department_id":"21"},{"id":"210212","name":"SAN JOSÉ","province_id":"2102","department_id":"21"},{"id":"210213","name":"SAN JUAN DE SALINAS","province_id":"2102","department_id":"21"},{"id":"210214","name":"SANTIAGO DE PUPUJA","province_id":"2102","department_id":"21"},{"id":"210215","name":"TIRAPATA","province_id":"2102","department_id":"21"},{"id":"210301","name":"MACUSANI","province_id":"2103","department_id":"21"},{"id":"210302","name":"AJOYANI","province_id":"2103","department_id":"21"},{"id":"210303","name":"AYAPATA","province_id":"2103","department_id":"21"},{"id":"210304","name":"COASA","province_id":"2103","department_id":"21"},{"id":"210305","name":"CORANI","province_id":"2103","department_id":"21"},{"id":"210306","name":"CRUCERO","province_id":"2103","department_id":"21"},{"id":"210307","name":"ITUATA","province_id":"2103","department_id":"21"},{"id":"210308","name":"OLLACHEA","province_id":"2103","department_id":"21"},{"id":"210309","name":"SAN GABAN","province_id":"2103","department_id":"21"},{"id":"210310","name":"USICAYOS","province_id":"2103","department_id":"21"},{"id":"210401","name":"JULI","province_id":"2104","department_id":"21"},{"id":"210402","name":"DESAGUADERO","province_id":"2104","department_id":"21"},{"id":"210403","name":"HUACULLANI","province_id":"2104","department_id":"21"},{"id":"210404","name":"KELLUYO","province_id":"2104","department_id":"21"},{"id":"210405","name":"PISACOMA","province_id":"2104","department_id":"21"},{"id":"210406","name":"POMATA","province_id":"2104","department_id":"21"},{"id":"210407","name":"ZEPITA","province_id":"2104","department_id":"21"},{"id":"210501","name":"ILAVE","province_id":"2105","department_id":"21"},{"id":"210502","name":"CAPAZO","province_id":"2105","department_id":"21"},{"id":"210503","name":"PILCUYO","province_id":"2105","department_id":"21"},{"id":"210504","name":"SANTA ROSA","province_id":"2105","department_id":"21"},{"id":"210505","name":"CONDURIRI","province_id":"2105","department_id":"21"},{"id":"210601","name":"HUANCANE","province_id":"2106","department_id":"21"},{"id":"210602","name":"COJATA","province_id":"2106","department_id":"21"},{"id":"210603","name":"HUATASANI","province_id":"2106","department_id":"21"},{"id":"210604","name":"INCHUPALLA","province_id":"2106","department_id":"21"},{"id":"210605","name":"PUSI","province_id":"2106","department_id":"21"},{"id":"210606","name":"ROSASPATA","province_id":"2106","department_id":"21"},{"id":"210607","name":"TARACO","province_id":"2106","department_id":"21"},{"id":"210608","name":"VILQUE CHICO","province_id":"2106","department_id":"21"},{"id":"210701","name":"LAMPA","province_id":"2107","department_id":"21"},{"id":"210702","name":"CABANILLA","province_id":"2107","department_id":"21"},{"id":"210703","name":"CALAPUJA","province_id":"2107","department_id":"21"},{"id":"210704","name":"NICASIO","province_id":"2107","department_id":"21"},{"id":"210705","name":"OCUVIRI","province_id":"2107","department_id":"21"},{"id":"210706","name":"PALCA","province_id":"2107","department_id":"21"},{"id":"210707","name":"PARATIA","province_id":"2107","department_id":"21"},{"id":"210708","name":"PUCARA","province_id":"2107","department_id":"21"},{"id":"210709","name":"SANTA LUCIA","province_id":"2107","department_id":"21"},{"id":"210710","name":"VILAVILA","province_id":"2107","department_id":"21"},{"id":"210801","name":"AYAVIRI","province_id":"2108","department_id":"21"},{"id":"210802","name":"ANTAUTA","province_id":"2108","department_id":"21"},{"id":"210803","name":"CUPI","province_id":"2108","department_id":"21"},{"id":"210804","name":"LLALLI","province_id":"2108","department_id":"21"},{"id":"210805","name":"MACARI","province_id":"2108","department_id":"21"},{"id":"210806","name":"NUÑOA","province_id":"2108","department_id":"21"},{"id":"210807","name":"ORURILLO","province_id":"2108","department_id":"21"},{"id":"210808","name":"SANTA ROSA","province_id":"2108","department_id":"21"},{"id":"210809","name":"UMACHIRI","province_id":"2108","department_id":"21"},{"id":"210901","name":"MOHO","province_id":"2109","department_id":"21"},{"id":"210902","name":"CONIMA","province_id":"2109","department_id":"21"},{"id":"210903","name":"HUAYRAPATA","province_id":"2109","department_id":"21"},{"id":"210904","name":"TILALI","province_id":"2109","department_id":"21"},{"id":"211001","name":"PUTINA","province_id":"2110","department_id":"21"},{"id":"211002","name":"ANANEA","province_id":"2110","department_id":"21"},{"id":"211003","name":"PEDRO VILCA APAZA","province_id":"2110","department_id":"21"},{"id":"211004","name":"QUILCAPUNCU","province_id":"2110","department_id":"21"},{"id":"211005","name":"SINA","province_id":"2110","department_id":"21"},{"id":"211101","name":"JULIACA","province_id":"2111","department_id":"21"},{"id":"211102","name":"CABANA","province_id":"2111","department_id":"21"},{"id":"211103","name":"CABANILLAS","province_id":"2111","department_id":"21"},{"id":"211104","name":"CARACOTO","province_id":"2111","department_id":"21"},{"id":"211105","name":"SAN MIGUEL","province_id":"2111","department_id":"21"},{"id":"211201","name":"SANDIA","province_id":"2112","department_id":"21"},{"id":"211202","name":"CUYOCUYO","province_id":"2112","department_id":"21"},{"id":"211203","name":"LIMBANI","province_id":"2112","department_id":"21"},{"id":"211204","name":"PATAMBUCO","province_id":"2112","department_id":"21"},{"id":"211205","name":"PHARA","province_id":"2112","department_id":"21"},{"id":"211206","name":"QUIACA","province_id":"2112","department_id":"21"},{"id":"211207","name":"SAN JUAN DEL ORO","province_id":"2112","department_id":"21"},{"id":"211208","name":"YANAHUAYA","province_id":"2112","department_id":"21"},{"id":"211209","name":"ALTO INAMBARI","province_id":"2112","department_id":"21"},{"id":"211210","name":"SAN PEDRO DE PUTINA PUNCO","province_id":"2112","department_id":"21"},{"id":"211301","name":"YUNGUYO","province_id":"2113","department_id":"21"},{"id":"211302","name":"ANAPIA","province_id":"2113","department_id":"21"},{"id":"211303","name":"COPANI","province_id":"2113","department_id":"21"},{"id":"211304","name":"CUTURAPI","province_id":"2113","department_id":"21"},{"id":"211305","name":"OLLARAYA","province_id":"2113","department_id":"21"},{"id":"211306","name":"TINICACHI","province_id":"2113","department_id":"21"},{"id":"211307","name":"UNICACHI","province_id":"2113","department_id":"21"},{"id":"220101","name":"MOYOBAMBA","province_id":"2201","department_id":"22"},{"id":"220102","name":"CALZADA","province_id":"2201","department_id":"22"},{"id":"220103","name":"HABANA","province_id":"2201","department_id":"22"},{"id":"220104","name":"JEPELACIO","province_id":"2201","department_id":"22"},{"id":"220105","name":"SORITOR","province_id":"2201","department_id":"22"},{"id":"220106","name":"YANTALO","province_id":"2201","department_id":"22"},{"id":"220201","name":"BELLAVISTA","province_id":"2202","department_id":"22"},{"id":"220202","name":"ALTO BIAVO","province_id":"2202","department_id":"22"},{"id":"220203","name":"BAJO BIAVO","province_id":"2202","department_id":"22"},{"id":"220204","name":"HUALLAGA","province_id":"2202","department_id":"22"},{"id":"220205","name":"SAN PABLO","province_id":"2202","department_id":"22"},{"id":"220206","name":"SAN RAFAEL","province_id":"2202","department_id":"22"},{"id":"220301","name":"SAN JOSÉ DE SISA","province_id":"2203","department_id":"22"},{"id":"220302","name":"AGUA BLANCA","province_id":"2203","department_id":"22"},{"id":"220303","name":"SAN MARTÍN","province_id":"2203","department_id":"22"},{"id":"220304","name":"SANTA ROSA","province_id":"2203","department_id":"22"},{"id":"220305","name":"SHATOJA","province_id":"2203","department_id":"22"},{"id":"220401","name":"SAPOSOA","province_id":"2204","department_id":"22"},{"id":"220402","name":"ALTO SAPOSOA","province_id":"2204","department_id":"22"},{"id":"220403","name":"EL ESLABÓN","province_id":"2204","department_id":"22"},{"id":"220404","name":"PISCOYACU","province_id":"2204","department_id":"22"},{"id":"220405","name":"SACANCHE","province_id":"2204","department_id":"22"},{"id":"220406","name":"TINGO DE SAPOSOA","province_id":"2204","department_id":"22"},{"id":"220501","name":"LAMAS","province_id":"2205","department_id":"22"},{"id":"220502","name":"ALONSO DE ALVARADO","province_id":"2205","department_id":"22"},{"id":"220503","name":"BARRANQUITA","province_id":"2205","department_id":"22"},{"id":"220504","name":"CAYNARACHI","province_id":"2205","department_id":"22"},{"id":"220505","name":"CUÑUMBUQUI","province_id":"2205","department_id":"22"},{"id":"220506","name":"PINTO RECODO","province_id":"2205","department_id":"22"},{"id":"220507","name":"RUMISAPA","province_id":"2205","department_id":"22"},{"id":"220508","name":"SAN ROQUE DE CUMBAZA","province_id":"2205","department_id":"22"},{"id":"220509","name":"SHANAO","province_id":"2205","department_id":"22"},{"id":"220510","name":"TABALOSOS","province_id":"2205","department_id":"22"},{"id":"220511","name":"ZAPATERO","province_id":"2205","department_id":"22"},{"id":"220601","name":"JUANJUÍ","province_id":"2206","department_id":"22"},{"id":"220602","name":"CAMPANILLA","province_id":"2206","department_id":"22"},{"id":"220603","name":"HUICUNGO","province_id":"2206","department_id":"22"},{"id":"220604","name":"PACHIZA","province_id":"2206","department_id":"22"},{"id":"220605","name":"PAJARILLO","province_id":"2206","department_id":"22"},{"id":"220701","name":"PICOTA","province_id":"2207","department_id":"22"},{"id":"220702","name":"BUENOS AIRES","province_id":"2207","department_id":"22"},{"id":"220703","name":"CASPISAPA","province_id":"2207","department_id":"22"},{"id":"220704","name":"PILLUANA","province_id":"2207","department_id":"22"},{"id":"220705","name":"PUCACACA","province_id":"2207","department_id":"22"},{"id":"220706","name":"SAN CRISTÓBAL","province_id":"2207","department_id":"22"},{"id":"220707","name":"SAN HILARIÓN","province_id":"2207","department_id":"22"},{"id":"220708","name":"SHAMBOYACU","province_id":"2207","department_id":"22"},{"id":"220709","name":"TINGO DE PONASA","province_id":"2207","department_id":"22"},{"id":"220710","name":"TRES UNIDOS","province_id":"2207","department_id":"22"},{"id":"220801","name":"RIOJA","province_id":"2208","department_id":"22"},{"id":"220802","name":"AWAJUN","province_id":"2208","department_id":"22"},{"id":"220803","name":"ELÍAS SOPLIN VARGAS","province_id":"2208","department_id":"22"},{"id":"220804","name":"NUEVA CAJAMARCA","province_id":"2208","department_id":"22"},{"id":"220805","name":"PARDO MIGUEL","province_id":"2208","department_id":"22"},{"id":"220806","name":"POSIC","province_id":"2208","department_id":"22"},{"id":"220807","name":"SAN FERNANDO","province_id":"2208","department_id":"22"},{"id":"220808","name":"YORONGOS","province_id":"2208","department_id":"22"},{"id":"220809","name":"YURACYACU","province_id":"2208","department_id":"22"},{"id":"220901","name":"TARAPOTO","province_id":"2209","department_id":"22"},{"id":"220902","name":"ALBERTO LEVEAU","province_id":"2209","department_id":"22"},{"id":"220903","name":"CACATACHI","province_id":"2209","department_id":"22"},{"id":"220904","name":"CHAZUTA","province_id":"2209","department_id":"22"},{"id":"220905","name":"CHIPURANA","province_id":"2209","department_id":"22"},{"id":"220906","name":"EL PORVENIR","province_id":"2209","department_id":"22"},{"id":"220907","name":"HUIMBAYOC","province_id":"2209","department_id":"22"},{"id":"220908","name":"JUAN GUERRA","province_id":"2209","department_id":"22"},{"id":"220909","name":"LA BANDA DE SHILCAYO","province_id":"2209","department_id":"22"},{"id":"220910","name":"MORALES","province_id":"2209","department_id":"22"},{"id":"220911","name":"PAPAPLAYA","province_id":"2209","department_id":"22"},{"id":"220912","name":"SAN ANTONIO","province_id":"2209","department_id":"22"},{"id":"220913","name":"SAUCE","province_id":"2209","department_id":"22"},{"id":"220914","name":"SHAPAJA","province_id":"2209","department_id":"22"},{"id":"221001","name":"TOCACHE","province_id":"2210","department_id":"22"},{"id":"221002","name":"NUEVO PROGRESO","province_id":"2210","department_id":"22"},{"id":"221003","name":"POLVORA","province_id":"2210","department_id":"22"},{"id":"221004","name":"SHUNTE","province_id":"2210","department_id":"22"},{"id":"221005","name":"UCHIZA","province_id":"2210","department_id":"22"},{"id":"230101","name":"TACNA","province_id":"2301","department_id":"23"},{"id":"230102","name":"ALTO DE LA ALIANZA","province_id":"2301","department_id":"23"},{"id":"230103","name":"CALANA","province_id":"2301","department_id":"23"},{"id":"230104","name":"CIUDAD NUEVA","province_id":"2301","department_id":"23"},{"id":"230105","name":"INCLAN","province_id":"2301","department_id":"23"},{"id":"230106","name":"PACHIA","province_id":"2301","department_id":"23"},{"id":"230107","name":"PALCA","province_id":"2301","department_id":"23"},{"id":"230108","name":"POCOLLAY","province_id":"2301","department_id":"23"},{"id":"230109","name":"SAMA","province_id":"2301","department_id":"23"},{"id":"230110","name":"CORONEL GREGORIO ALBARRACÍN LANCHIPA","province_id":"2301","department_id":"23"},{"id":"230111","name":"LA YARADA LOS PALOS","province_id":"2301","department_id":"23"},{"id":"230201","name":"CANDARAVE","province_id":"2302","department_id":"23"},{"id":"230202","name":"CAIRANI","province_id":"2302","department_id":"23"},{"id":"230203","name":"CAMILACA","province_id":"2302","department_id":"23"},{"id":"230204","name":"CURIBAYA","province_id":"2302","department_id":"23"},{"id":"230205","name":"HUANUARA","province_id":"2302","department_id":"23"},{"id":"230206","name":"QUILAHUANI","province_id":"2302","department_id":"23"},{"id":"230301","name":"LOCUMBA","province_id":"2303","department_id":"23"},{"id":"230302","name":"ILABAYA","province_id":"2303","department_id":"23"},{"id":"230303","name":"ITE","province_id":"2303","department_id":"23"},{"id":"230401","name":"TARATA","province_id":"2304","department_id":"23"},{"id":"230402","name":"HÉROES ALBARRACÍN","province_id":"2304","department_id":"23"},{"id":"230403","name":"ESTIQUE","province_id":"2304","department_id":"23"},{"id":"230404","name":"ESTIQUE-PAMPA","province_id":"2304","department_id":"23"},{"id":"230405","name":"SITAJARA","province_id":"2304","department_id":"23"},{"id":"230406","name":"SUSAPAYA","province_id":"2304","department_id":"23"},{"id":"230407","name":"TARUCACHI","province_id":"2304","department_id":"23"},{"id":"230408","name":"TICACO","province_id":"2304","department_id":"23"},{"id":"240101","name":"TUMBES","province_id":"2401","department_id":"24"},{"id":"240102","name":"CORRALES","province_id":"2401","department_id":"24"},{"id":"240103","name":"LA CRUZ","province_id":"2401","department_id":"24"},{"id":"240104","name":"PAMPAS DE HOSPITAL","province_id":"2401","department_id":"24"},{"id":"240105","name":"SAN JACINTO","province_id":"2401","department_id":"24"},{"id":"240106","name":"SAN JUAN DE LA VIRGEN","province_id":"2401","department_id":"24"},{"id":"240201","name":"ZORRITOS","province_id":"2402","department_id":"24"},{"id":"240202","name":"CASITAS","province_id":"2402","department_id":"24"},{"id":"240203","name":"CANOAS DE PUNTA SAL","province_id":"2402","department_id":"24"},{"id":"240301","name":"ZARUMILLA","province_id":"2403","department_id":"24"},{"id":"240302","name":"AGUAS VERDES","province_id":"2403","department_id":"24"},{"id":"240303","name":"MATAPALO","province_id":"2403","department_id":"24"},{"id":"240304","name":"PAPAYAL","province_id":"2403","department_id":"24"},{"id":"250101","name":"CALLERIA","province_id":"2501","department_id":"25"},{"id":"250102","name":"CAMPOVERDE","province_id":"2501","department_id":"25"},{"id":"250103","name":"IPARIA","province_id":"2501","department_id":"25"},{"id":"250104","name":"MASISEA","province_id":"2501","department_id":"25"},{"id":"250105","name":"YARINACOCHA","province_id":"2501","department_id":"25"},{"id":"250106","name":"NUEVA REQUENA","province_id":"2501","department_id":"25"},{"id":"250107","name":"MANANTAY","province_id":"2501","department_id":"25"},{"id":"250201","name":"RAYMONDI","province_id":"2502","department_id":"25"},{"id":"250202","name":"SEPAHUA","province_id":"2502","department_id":"25"},{"id":"250203","name":"TAHUANIA","province_id":"2502","department_id":"25"},{"id":"250204","name":"YURUA","province_id":"2502","department_id":"25"},{"id":"250301","name":"PADRE ABAD","province_id":"2503","department_id":"25"},{"id":"250302","name":"IRAZOLA","province_id":"2503","department_id":"25"},{"id":"250303","name":"CURIMANA","province_id":"2503","department_id":"25"},{"id":"250304","name":"NESHUYA","province_id":"2503","department_id":"25"},{"id":"250305","name":"ALEXANDER VON HUMBOLDT","province_id":"2503","department_id":"25"},{"id":"250401","name":"PURUS","province_id":"2504","department_id":"25"}]');
;// CONCATENATED MODULE: ./components/organisms/Dashboard/useUbigeo.js




const useUbigeo = ()=>{
    const { 0: departments , 1: setDepartments  } = (0,external_react_.useState)([]);
    const { 0: provinces , 1: setProvinces  } = (0,external_react_.useState)([]);
    const { 0: districts , 1: setDistricts  } = (0,external_react_.useState)([]);
    const handleDepartaments = ()=>{
        const temp = [];
        departments_namespaceObject.map((d)=>temp.push({
                label: d.name,
                value: d.name
            }));
        setDepartments(temp);
    };
    const handleProvinces = (department)=>{
        setProvinces([]);
        const departmentT = departments_namespaceObject.filter((values)=>values.name == department);
        const temp = [];
        if (departmentT[0]?.id !== undefined) {
            for(let index = 0; index < provinces_namespaceObject.length; index++){
                provinces_namespaceObject[index].department_id == departmentT[0].id && temp.push({
                    label: provinces_namespaceObject[index].name,
                    value: provinces_namespaceObject[index].name
                });
            }
        }
        setProvinces(temp);
    };
    const handleDistricts = (province)=>{
        setDistricts([]);
        const provinceT = provinces_namespaceObject.filter((values)=>values.name == province);
        const temp = [];
        if (provinceT[0]?.id !== undefined) {
            for(let index = 0; index < districts_namespaceObject.length; index++){
                districts_namespaceObject[index].province_id == provinceT[0].id && temp.push({
                    label: districts_namespaceObject[index].name,
                    value: districts_namespaceObject[index].name
                });
            }
        }
        setDistricts(temp);
    };
    return {
        departments,
        provinces,
        districts,
        handleDepartaments,
        handleProvinces,
        handleDistricts
    };
};


/***/ }),

/***/ 4068:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "$": () => (/* binding */ Footer)
});

// EXTERNAL MODULE: external "react/jsx-runtime"
var jsx_runtime_ = __webpack_require__(997);
// EXTERNAL MODULE: external "react"
var external_react_ = __webpack_require__(6689);
// EXTERNAL MODULE: ./components/organisms/Footer/components/Copyright/copyright.module.scss
var copyright_module = __webpack_require__(4908);
var copyright_module_default = /*#__PURE__*/__webpack_require__.n(copyright_module);
;// CONCATENATED MODULE: ./components/organisms/Footer/components/Copyright/Copyright.jsx



const Copyright = ()=>{
    return /*#__PURE__*/ jsx_runtime_.jsx("div", {
        className: (copyright_module_default()).copyright,
        children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
            className: (copyright_module_default()).copyright__container,
            children: [
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Copyright \xa92022 | Todos los derechos reservados"
                }),
                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                    children: "Dise\xf1ado por Renian"
                })
            ]
        })
    });
};

// EXTERNAL MODULE: ./node_modules/next/image.js
var next_image = __webpack_require__(5675);
var image_default = /*#__PURE__*/__webpack_require__.n(next_image);
// EXTERNAL MODULE: ./components/organisms/Footer/footer.module.scss
var footer_module = __webpack_require__(4982);
var footer_module_default = /*#__PURE__*/__webpack_require__.n(footer_module);
;// CONCATENATED MODULE: ./components/organisms/Footer/Footer.jsx





const Footer = ()=>{
    return /*#__PURE__*/ (0,jsx_runtime_.jsxs)(jsx_runtime_.Fragment, {
        children: [
            /*#__PURE__*/ jsx_runtime_.jsx("footer", {
                className: (footer_module_default()).footer,
                children: /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                    className: (footer_module_default()).footer__container,
                    children: [
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).footer__description,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("div", {
                                    className: (footer_module_default()).footer__descriptionImage,
                                    children: /*#__PURE__*/ jsx_runtime_.jsx((image_default()), {
                                        src: "/svg/renian-logo-white.svg",
                                        layout: "responsive",
                                        width: 80,
                                        height: 30,
                                        alt: "image"
                                    })
                                }),
                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                    children: "Somos una fundacion procupada por la proteccion y defensa del bienestar animal. Identificamos, registramos y contribuimos a la localizacion de mascotas en el territorio Peruano."
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("div", {
                            className: (footer_module_default()).footer__contact,
                            children: [
                                /*#__PURE__*/ jsx_runtime_.jsx("h3", {
                                    children: "Contactanos"
                                }),
                                /*#__PURE__*/ (0,jsx_runtime_.jsxs)("ul", {
                                    children: [
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("lord-icon", {
                                                    src: "https://cdn.lordicon.com/gwklwoti.json",
                                                    // trigger="loop"
                                                    colors: "primary:#ffffff,secondary:#ffffff",
                                                    style: {
                                                        width: "30px",
                                                        height: "30px"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Av. Mariategui 1030, Jesus Maria"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("lord-icon", {
                                                    src: "https://cdn.lordicon.com/iguuenru.json",
                                                    // trigger="loop"
                                                    colors: "primary:#ffffff,secondary:#ffffff",
                                                    style: {
                                                        width: "30px",
                                                        height: "30px"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "(+51) 759-4451"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("lord-icon", {
                                                    src: "https://cdn.lordicon.com/egpbfgcp.json",
                                                    // trigger="loop"
                                                    colors: "primary:#ffffff,secondary:#ffffff",
                                                    style: {
                                                        width: "30px",
                                                        height: "30px"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "info@renian.org"
                                                })
                                            ]
                                        }),
                                        /*#__PURE__*/ (0,jsx_runtime_.jsxs)("li", {
                                            children: [
                                                /*#__PURE__*/ jsx_runtime_.jsx("lord-icon", {
                                                    src: "https://cdn.lordicon.com/uutnmngi.json",
                                                    // trigger="loop"
                                                    colors: "primary:#ffffff,secondary:#ffffff",
                                                    style: {
                                                        width: "30px",
                                                        height: "30px"
                                                    }
                                                }),
                                                /*#__PURE__*/ jsx_runtime_.jsx("p", {
                                                    children: "Lun-Vie 09:00 am | 6:00 pm"
                                                })
                                            ]
                                        })
                                    ]
                                })
                            ]
                        })
                    ]
                })
            }),
            /*#__PURE__*/ jsx_runtime_.jsx(Copyright, {})
        ]
    });
};


/***/ }),

/***/ 4151:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "h": () => (/* binding */ Header)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(1664);
/* harmony import */ var next_link__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_link__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_3___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_3__);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var _components_ContactHead_ContactHead__WEBPACK_IMPORTED_MODULE_5__ = __webpack_require__(5574);
/* harmony import */ var _header_module_scss__WEBPACK_IMPORTED_MODULE_6__ = __webpack_require__(9986);
/* harmony import */ var _header_module_scss__WEBPACK_IMPORTED_MODULE_6___default = /*#__PURE__*/__webpack_require__.n(_header_module_scss__WEBPACK_IMPORTED_MODULE_6__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components_ContactHead_ContactHead__WEBPACK_IMPORTED_MODULE_5__]);
_components_ContactHead_ContactHead__WEBPACK_IMPORTED_MODULE_5__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];







const Header = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components_ContactHead_ContactHead__WEBPACK_IMPORTED_MODULE_5__/* .ContactHead */ .g, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("header", {
                className: (_header_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header),
                children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
                    className: (_header_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header__container),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                            href: "/",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_1___default()), {
                                    src: "/svg/renian-logo.svg",
                                    width: 160,
                                    height: 50,
                                    alt: "renian-icon"
                                })
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("nav", {
                            className: (_header_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header__links),
                            children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                                children: [
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: "Nosotros"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: "Microship"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                                        children: "Mision"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/news",
                                        children: "Noticias"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/questions",
                                        children: "Preguntas Frecuntes"
                                    }),
                                    /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_link__WEBPACK_IMPORTED_MODULE_2___default()), {
                                        href: "/contact",
                                        children: "Contacto"
                                    })
                                ]
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
                            className: (_header_module_scss__WEBPACK_IMPORTED_MODULE_6___default().header__login),
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("button", {
                                onClick: ()=>router.push("/login"),
                                children: "Ingresar"
                            })
                        })
                    ]
                })
            })
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5574:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "g": () => (/* binding */ ContactHead)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(7765);
/* harmony import */ var _contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(_contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4__);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5675);
/* harmony import */ var next_image__WEBPACK_IMPORTED_MODULE_2___default = /*#__PURE__*/__webpack_require__.n(next_image__WEBPACK_IMPORTED_MODULE_2__);
/* harmony import */ var _react_hook_hover__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(6881);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__]);
_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const ContactHead = ()=>{
    const targetDir = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const targetHours = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const targetNumb = (0,react__WEBPACK_IMPORTED_MODULE_1__.useRef)(null);
    const hoverDir = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(targetDir);
    const hoverHours = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(targetHours);
    const hoverNumb = (0,_react_hook_hover__WEBPACK_IMPORTED_MODULE_3__["default"])(targetNumb);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("div", {
        className: (_contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contact),
        children: /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("main", {
            className: (_contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contact__container),
            children: [
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contact__info),
                    children: [
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                    src: "https://cdn.lordicon.com/gwklwoti.json",
                                    trigger: hoverDir ? "loop" : "none",
                                    colors: "primary:#000000,secondary:#dd0000",
                                    style: {
                                        width: "30px",
                                        height: "30px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    ref: targetDir,
                                    children: "Av. Mariategui 1030, Jes\xfas Mar\xeda"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                    src: "https://cdn.lordicon.com/uutnmngi.json",
                                    trigger: hoverHours ? "loop" : "none",
                                    colors: "primary:#000000,secondary:#dd0000",
                                    style: {
                                        width: "25px",
                                        height: "25px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    ref: targetHours,
                                    children: "Lun-Vie 09:00 am | 6:00 pm"
                                })
                            ]
                        }),
                        /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                            children: [
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("lord-icon", {
                                    src: "https://cdn.lordicon.com/iguuenru.json",
                                    trigger: hoverNumb ? "loop" : "none",
                                    colors: "primary:#000000,secondary:#dd0000",
                                    style: {
                                        width: "30px",
                                        height: "30px"
                                    }
                                }),
                                /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("p", {
                                    ref: targetNumb,
                                    children: "(+51) 759-4451"
                                })
                            ]
                        })
                    ]
                }),
                /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)("div", {
                    className: (_contact_head_module_scss__WEBPACK_IMPORTED_MODULE_4___default().contact__networks),
                    children: [
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "https://www.facebook.com/RenianPeru/",
                            target: "_blank",
                            rel: "noreferrer noopener",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/svg/networks/facebook-icon.svg",
                                width: 28,
                                height: 28,
                                alt: "fb-icon"
                            })
                        }),
                        /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx("a", {
                            href: "https://www.instagram.com/renian_peru/?hl=es-la",
                            target: "_blank",
                            rel: "noreferrer noopener",
                            children: /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx((next_image__WEBPACK_IMPORTED_MODULE_2___default()), {
                                src: "/svg/networks/instagram-icon.svg",
                                width: 28,
                                height: 28,
                                alt: "ins-icon"
                            })
                        })
                    ]
                })
            ]
        })
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 6732:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Q": () => (/* binding */ CPanelView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _hook_useConnect__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(5208);
/* harmony import */ var _organisms_Dashboard_Dashboard__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5846);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_organisms_Dashboard_Dashboard__WEBPACK_IMPORTED_MODULE_3__]);
_organisms_Dashboard_Dashboard__WEBPACK_IMPORTED_MODULE_3__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const CPanelView = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { auth , loading  } = (0,_hook_useConnect__WEBPACK_IMPORTED_MODULE_2__/* .useConnect */ .$)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loading && !auth && router.push("/login");
    }, [
        auth,
        loading
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: loading && auth && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_organisms_Dashboard_Dashboard__WEBPACK_IMPORTED_MODULE_3__/* ["default"] */ .Z, {})
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 4748:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "u": () => (/* binding */ HomeView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6959);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_2__]);
_components__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];



const HomeView = ()=>{
    return /*#__PURE__*/ (0,react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsxs)(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: [
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Banner */ .jL, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .CardSection */ .uO, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .About */ .CL, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .PlayVideo */ .dh, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Microchip */ .mb, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Advantage */ .IN, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Projection */ .kv, {}),
            /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .Mission */ .$U, {})
        ]
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 9003:
/***/ ((module, __webpack_exports__, __webpack_require__) => {

"use strict";
__webpack_require__.a(module, async (__webpack_handle_async_dependencies__, __webpack_async_result__) => { try {
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "q": () => (/* binding */ LoginView)
/* harmony export */ });
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(997);
/* harmony import */ var react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_1___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_1__);
/* harmony import */ var _components__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(6959);
/* harmony import */ var _hook_useConnect__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(5208);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4__ = __webpack_require__(1853);
/* harmony import */ var next_router__WEBPACK_IMPORTED_MODULE_4___default = /*#__PURE__*/__webpack_require__.n(next_router__WEBPACK_IMPORTED_MODULE_4__);
var __webpack_async_dependencies__ = __webpack_handle_async_dependencies__([_components__WEBPACK_IMPORTED_MODULE_2__]);
_components__WEBPACK_IMPORTED_MODULE_2__ = (__webpack_async_dependencies__.then ? (await __webpack_async_dependencies__)() : __webpack_async_dependencies__)[0];





const LoginView = ()=>{
    const router = (0,next_router__WEBPACK_IMPORTED_MODULE_4__.useRouter)();
    const { auth , loading  } = (0,_hook_useConnect__WEBPACK_IMPORTED_MODULE_3__/* .useConnect */ .$)();
    (0,react__WEBPACK_IMPORTED_MODULE_1__.useEffect)(()=>{
        loading && auth && router.push("/cpanel");
    }, [
        auth,
        loading
    ]);
    return /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.Fragment, {
        children: loading && !auth && /*#__PURE__*/ react_jsx_runtime__WEBPACK_IMPORTED_MODULE_0__.jsx(_components__WEBPACK_IMPORTED_MODULE_2__/* .LoginOwner */ .Q1, {})
    });
};

__webpack_async_result__();
} catch(e) { __webpack_async_result__(e); } });

/***/ }),

/***/ 5208:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "$": () => (/* binding */ useConnect)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);
/* harmony import */ var _utils_war_auth__WEBPACK_IMPORTED_MODULE_1__ = __webpack_require__(2858);
/* harmony import */ var _utils_web3__WEBPACK_IMPORTED_MODULE_3__ = __webpack_require__(7464);
/* harmony import */ var _contexts_Web3_Web3Context__WEBPACK_IMPORTED_MODULE_2__ = __webpack_require__(3918);




const useConnect = (init = false)=>{
    const { web3 , handleToken , handleWeb3  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useContext)(_contexts_Web3_Web3Context__WEBPACK_IMPORTED_MODULE_2__/* .Web3Context */ .S);
    const { 0: auth , 1: setAuth  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(init);
    const { 0: loading , 1: setLoading  } = (0,react__WEBPACK_IMPORTED_MODULE_0__.useState)(init);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        (0,_utils_web3__WEBPACK_IMPORTED_MODULE_3__/* .getConnected */ .N)().then((response)=>response && handleWeb3(response.provider, response.providerString));
    }, []);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        if (web3.wallet !== null && web3.account) {
            handleToken(sessionStorage.getItem("auth_token_" + String(web3.account).toUpperCase()), sessionStorage.getItem("auth_timeOut_" + String(web3.account).toUpperCase()));
        }
    }, [
        web3.wallet,
        web3.account
    ]);
    (0,react__WEBPACK_IMPORTED_MODULE_0__.useEffect)(()=>{
        (0,_utils_war_auth__WEBPACK_IMPORTED_MODULE_1__/* .handleValidate */ .yg)(web3.authToken, web3.authTimeOut, setAuth, setLoading);
    }, [
        web3.authToken
    ]);
    return {
        auth,
        loading
    };
};


/***/ }),

/***/ 4108:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Z": () => (/* binding */ isObjEmpty),
/* harmony export */   "b": () => (/* binding */ objectUppercase)
/* harmony export */ });
const isObjEmpty = (obj)=>{
    for(var prop in obj){
        if (obj.hasOwnProperty(prop)) return false;
    }
    return true;
};
const objectUppercase = (object, includes = [
    ""
])=>{
    Object.keys(object).map((key)=>{
        if (typeof object[key] === "string" && key != "_id" && key != "user" && !includes.includes(key)) {
            object[key] = String(object[key]).toUpperCase();
        }
    });
    return object;
};


/***/ }),

/***/ 3820:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "b": () => (/* binding */ getResponsibility)
});

// EXTERNAL MODULE: ./config/index.js + 6 modules
var config = __webpack_require__(8104);
;// CONCATENATED MODULE: ./config/abi/war/RegisteringEntities.json
const RegisteringEntities_namespaceObject = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"address","name":"_address","type":"address"},{"internalType":"uint8","name":"_access","type":"uint8"}],"name":"getAccess","outputs":[{"internalType":"uint8[]","name":"","type":"uint8[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"getEntityAll","outputs":[{"internalType":"string[]","name":"","type":"string[]"},{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"getPermission","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"getQuantity","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"getRegisteringEntity","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"getResponsibility","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"uint256","name":"","type":"uint256"}],"name":"idRegisteringEntity","outputs":[{"internalType":"address","name":"","type":"address"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"indexOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"price","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"registeringEntity","outputs":[{"internalType":"bool","name":"permission","type":"bool"},{"internalType":"uint256","name":"time","type":"uint256"},{"internalType":"uint16","name":"quantity","type":"uint16"},{"internalType":"uint16","name":"max","type":"uint16"},{"internalType":"string","name":"data","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_addrees","type":"address"}],"name":"setAdministrators","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint256","name":"_idRegisteringEntity","type":"uint256"},{"internalType":"address","name":"_address","type":"address"}],"name":"setIdRegisteringEntity","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint16","name":"_increment","type":"uint16"},{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"uint256","name":"_amountInMax","type":"uint256"},{"internalType":"address","name":"_coin","type":"address"}],"name":"setIncrementMax","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setPermisition","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"bool","name":"status","type":"bool"},{"internalType":"address","name":"_address","type":"address"},{"internalType":"address","name":"_addressContract","type":"address"}],"name":"setQuantity","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"},{"internalType":"bool","name":"_permission","type":"bool"},{"internalType":"string","name":"_data","type":"string"},{"internalType":"uint16","name":"max","type":"uint16"},{"internalType":"uint256","name":"_time","type":"uint256"},{"internalType":"bool","name":"_operation","type":"bool"},{"internalType":"uint8[]","name":"_access","type":"uint8[]"},{"internalType":"uint8[][]","name":"_accessValue","type":"uint8[][]"}],"name":"setRegisteringEntity","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"uint16","name":"_max","type":"uint16"},{"internalType":"uint256","name":"_amountOut","type":"uint256"},{"internalType":"uint256","name":"_amountInMax","type":"uint256"},{"internalType":"address","name":"_coin","type":"address"}],"name":"setRenovation","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"},{"internalType":"uint256","name":"_time","type":"uint256"}],"name":"setTime","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
// EXTERNAL MODULE: ./utils/war/address.js
var war_address = __webpack_require__(7225);
;// CONCATENATED MODULE: ./utils/war/RegisteringEntities.js



const getResponsibility = async (web3, address)=>{
    address = (0,war_address/* toChecksumAddress */.P)(web3, address);
    try {
        const contract = new web3.eth.Contract(RegisteringEntities_namespaceObject, config/* CONTRACTS_WAR.RegisteringEntities */.oX.RegisteringEntities);
        const response = await contract.methods.getResponsibility(address).call();
        return response;
    } catch (e) {
        console.log(e);
    }
};


/***/ }),

/***/ 8095:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "Q": () => (/* binding */ Users)
});

// UNUSED EXPORTS: deleteUser, getAccess, getAccessAll, getErUsers, setUsers

// EXTERNAL MODULE: ./config/index.js + 6 modules
var config = __webpack_require__(8104);
;// CONCATENATED MODULE: ./config/abi/war/UsersSystem.json
const UsersSystem_namespaceObject = JSON.parse('[{"inputs":[],"stateMutability":"nonpayable","type":"constructor"},{"inputs":[{"internalType":"address","name":"","type":"address"}],"name":"Users","outputs":[{"internalType":"bool","name":"status","type":"bool"},{"internalType":"bool","name":"permission","type":"bool"},{"internalType":"address","name":"registeringEntity","type":"address"},{"internalType":"string","name":"data","type":"string"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"deleteUser","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"},{"internalType":"uint8","name":"_module","type":"uint8"},{"internalType":"uint8","name":"_value","type":"uint8"}],"name":"getAccess","outputs":[{"internalType":"bool","name":"","type":"bool"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"},{"internalType":"uint8","name":"_access","type":"uint8"}],"name":"getAccessAll","outputs":[{"internalType":"uint8[]","name":"","type":"uint8[]"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"getErUsers","outputs":[{"internalType":"address[]","name":"","type":"address[]"}],"stateMutability":"view","type":"function"},{"inputs":[],"name":"indexOf","outputs":[{"internalType":"uint256","name":"","type":"uint256"}],"stateMutability":"view","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"}],"name":"setPermisition","outputs":[],"stateMutability":"nonpayable","type":"function"},{"inputs":[{"internalType":"address","name":"_address","type":"address"},{"internalType":"bool","name":"_permission","type":"bool"},{"internalType":"string","name":"_data","type":"string"},{"internalType":"uint8[]","name":"_module","type":"uint8[]"},{"internalType":"uint8[][]","name":"_value","type":"uint8[][]"}],"name":"setUsers","outputs":[],"stateMutability":"nonpayable","type":"function"}]');
// EXTERNAL MODULE: ./utils/war/address.js
var war_address = __webpack_require__(7225);
;// CONCATENATED MODULE: ./utils/war/UsersSystem.js



const Users = async (web3, account)=>{
    try {
        const address = (0,war_address/* toChecksumAddress */.P)(web3, account);
        const contract = new web3.eth.Contract(UsersSystem_namespaceObject, config/* CONTRACTS_WAR.UsersSystem */.oX.UsersSystem);
        const response = await contract.methods.Users(address).call();
        return response;
    } catch (e) {
        console.log(e);
    }
};
const getErUsers = async (web3, account)=>{
    try {
        const address = toChecksumAddress(web3, account);
        const contract = new web3.eth.Contract(ABIUSER, CONTRACTS_WAR.UsersSystem);
        const response = await contract.methods.getErUsers(address).call();
        return response;
    } catch (e) {
        console.log(e);
    }
};
const getAccess = async (web3, account, module, value)=>{
    try {
        const address = toChecksumAddress(web3, account);
        const contract = new web3.eth.Contract(ABIUSER, CONTRACTS_WAR.UsersSystem);
        const response = await contract.methods.getAccess(address, module, value).call();
        return response;
    } catch (e) {
        console.log(e);
    }
};
const getAccessAll = async (web3, account, access)=>{
    try {
        const address = toChecksumAddress(web3, account);
        const contract = new web3.eth.Contract(ABIUSER, CONTRACTS_WAR.UsersSystem);
        const response = await contract.methods.getAccessAll(address, access).call();
        return response;
    } catch (e) {
        console.log(e);
    }
};
const deleteUser = async (web3, account, address)=>{
    try {
        const accountChecksum = toChecksumAddress(web3, account);
        const contract = new web3.eth.Contract(ABIUSER, CONTRACTS_WAR.UsersSystem);
        const response = await contract.methods.deleteUser(toChecksumAddress(web3, address)).send({
            from: accountChecksum,
            value: 0
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};
const setUsers = async (web3, account, address, permission, data, access, accessValues)=>{
    try {
        const accountChecksum = toChecksumAddress(web3, account);
        const addressChecksum = toChecksumAddress(web3, address);
        const contract = new web3.eth.Contract(ABIUSER, CONTRACTS_WAR.UsersSystem);
        const response = await contract.methods.setUsers(addressChecksum, permission, data, access, accessValues).send({
            from: accountChecksum,
            value: 0
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};


/***/ }),

/***/ 7225:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "P": () => (/* binding */ toChecksumAddress)
/* harmony export */ });
const toChecksumAddress = (web3, address)=>{
    return web3?.utils.isAddress(address) ? web3.utils.toChecksumAddress(address) : 0x0000000000000000000000000000000000000000;
};


/***/ }),

/***/ 7756:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "B$": () => (/* binding */ handlePost)
/* harmony export */ });
/* unused harmony exports getExist, handleAdopter, handleAdopterAddress, handleAdopterPublic */
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8104);

const getExist = async (token, route, value)=>{
    try {
        const response = await fetch(`${API.war}adopters/${route}?${route}=${value}`, {
            headers: {
                "Content-Type": "application/json",
                "x-token": token
            }
        }).then((content)=>{
            if (content.ok) {
                return content.json();
            }
            throw new Error("Something went wrong");
        }).then((responseJson)=>{
            return responseJson;
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handleAdopter = async (token, country, document, documentNumber)=>{
    try {
        const response = await fetch(`${API.war}adopters?country=${country}&document=${document}&documentNumber=${documentNumber}`, {
            headers: {
                "Content-Type": "application/json",
                "x-token": token
            }
        }).then((content)=>{
            if (content.ok) {
                return content.json();
            }
            throw new Error("Something went wrong");
        }).then((responseJson)=>{
            return responseJson;
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handlePost = async (data, token, method, id = "")=>{
    try {
        const content = await fetch(`${_config__WEBPACK_IMPORTED_MODULE_0__/* .API.war */ .bl.war}adopters/${id}`, {
            body: JSON.stringify(data),
            headers: {
                "Content-Type": "application/json",
                "x-token": token
            },
            method
        });
        const response = await content.json();
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handleAdopterAddress = async (token, address)=>{
    try {
        const response = await fetch(`${API.war}adopters/address?address=${address}`, {
            headers: {
                "Content-Type": "application/json",
                "x-token": token
            }
        }).then((content)=>{
            if (content.ok) {
                return content.json();
            }
            throw new Error("Something went wrong");
        }).then((responseJson)=>{
            return responseJson;
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handleAdopterPublic = async (address)=>{
    try {
        const response = await fetch(`${API.war}adopters/public?address=${address}`, {
            headers: {
                "Content-Type": "application/json"
            }
        }).then((content)=>{
            if (content.ok) {
                return content.json();
            }
            throw new Error("Something went wrong");
        }).then((responseJson)=>{
            return responseJson;
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};


/***/ }),

/***/ 2858:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";
/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "Eu": () => (/* binding */ handleUser),
/* harmony export */   "im": () => (/* binding */ handleAuthenticate),
/* harmony export */   "jD": () => (/* binding */ handleSignMessage),
/* harmony export */   "kS": () => (/* binding */ logout),
/* harmony export */   "yg": () => (/* binding */ handleValidate)
/* harmony export */ });
/* unused harmony exports timeStamp, handleSignup */
/* harmony import */ var _config__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(8104);

const timeStamp = ()=>{
    return Math.floor(Date.now() / 1000);
};
const handleUser = async (publicAddress)=>{
    try {
        const content = await fetch(`${_config__WEBPACK_IMPORTED_MODULE_0__/* .API.war */ .bl.war}auth?publicAddress=${publicAddress}`);
        const response = await content.json();
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handleSignup = async (publicAddress, rol, rolNew, token)=>{
    try {
        const response = await fetch(`${API.war}auth/new`, {
            body: JSON.stringify({
                publicAddress,
                rol,
                rolNew
            }),
            headers: {
                "Content-Type": "application/json",
                "x-token": token
            },
            method: "POST"
        });
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handleSignMessage = async (web3, publicAddress, nonce)=>{
    try {
        const response = await web3.eth.personal.sign(web3.utils.utf8ToHex(`0x${nonce}`), publicAddress);
        return response;
    } catch (error) {
        console.log(error);
    }
};
const handleAuthenticate = async (publicAddress, signature, handleToken)=>{
    try {
        const content = await fetch(`${_config__WEBPACK_IMPORTED_MODULE_0__/* .API.war */ .bl.war}auth/`, {
            body: JSON.stringify({
                publicAddress,
                signature
            }),
            headers: {
                "Content-Type": "application/json"
            },
            method: "POST"
        });
        const response = await content.json();
        if (response?.token) {
            sessionStorage.setItem("auth_token_" + String(publicAddress).toUpperCase(), response?.token);
            sessionStorage.setItem("auth_timeOut_" + String(publicAddress).toUpperCase(), String(timeStamp() + 43200));
            handleToken(response?.token, String(timeStamp() + 43200));
        }
    } catch (error) {
        console.log(error);
    }
};
const handleValidate = (token, timeOut, setAuth, setLoading)=>{
    if (token != "" && parseInt(timeOut ?? "0") > timeStamp()) {
        setAuth(true);
    } else {
        setAuth(false);
    }
    setLoading(true);
};
const logout = async (web3, handleWeb3, handleToken, handleAccount)=>{
    try {
        sessionStorage.removeItem("auth_token_" + String(web3.account).toUpperCase());
        sessionStorage.removeItem("auth_timeOut_" + String(web3.account).toUpperCase());
        if (web3.providerString === "walletconnect") {
            await web3.provider.disconnect();
        }
        handleWeb3(null, null);
        handleToken("", "");
        handleAccount("");
    } catch (error) {
        console.log(error);
    }
};


/***/ }),

/***/ 7464:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

"use strict";

// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "N": () => (/* binding */ getConnected),
  "r": () => (/* binding */ web3Provider)
});

;// CONCATENATED MODULE: ./utils/providers.js
// import WalletConnectProvider from "@walletconnect/web3-provider";
const metamaskInstall = ()=>{
    window.open("https://chrome.google.com/webstore/detail/metamask/nkbihfbeogaeaoehlefnkodbefgpgknn?hl=es", "_blank", "noopener");
    return true;
};
const providers = (string)=>{
    switch(string){
        // case "walletconnect":
        //   return new WalletConnectProvider({
        //     rpc: {
        //       97: "https://data-seed-prebsc-1-s1.binance.org:8545",
        //       1285: "https://moonriver.api.onfinality.io/rpc?apikey=4cc1072b-afe8-4d8d-b11b-53b298e6e6bc",
        //     },
        //     qrcodeModalOptions: {
        //       mobileLinks: ["metamask", "trust"],
        //     },
        //     chainId: 1285,
        //   });
        default:
            return typeof window.ethereum !== "undefined" ? window.ethereum : {
                validate: true
            };
    }
};
const validateMetamask = (provider, message)=>{
    provider.validate && message && metamaskInstall();
    !provider.validate && window.ethereum.request({
        method: "eth_requestAccounts"
    });
};

;// CONCATENATED MODULE: ./utils/web3.js

const web3Connect = async (handleWeb3, providerString, provider)=>{
    try {
        if (providerString === "walletconnect") {
            provider.networkId = 1285;
            await provider.enable();
        }
        handleWeb3(provider, providerString);
    } catch (e) {
        console.log("cancelado");
    }
};
const web3Provider = (handleWeb3, providerString, message = true)=>{
    const provider = providers(providerString);
    providerString === "metamask" && validateMetamask(provider, message);
    if (!provider.validate) {
        web3Connect(handleWeb3, providerString, provider);
    }
    return provider;
};
const getConnected = async ()=>{
    try {
        if (typeof window.ethereum !== undefined) {
            const accounts = await window.ethereum.request({
                method: "eth_accounts"
            });
            if (accounts.length > 0) {
                return {
                    provider: window.ethereum,
                    providerString: "metamask"
                };
            }
        }
        return false;
    } catch (err) {
        return false;
    }
};


/***/ })

};
;