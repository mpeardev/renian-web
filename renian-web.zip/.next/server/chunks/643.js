"use strict";
exports.id = 643;
exports.ids = [643];
exports.modules = {

/***/ 8104:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {


// EXPORTS
__webpack_require__.d(__webpack_exports__, {
  "bl": () => (/* binding */ API),
  "oX": () => (/* binding */ CONTRACTS_WAR),
  "nH": () => (/* binding */ WEB3_NETWORK),
  "iw": () => (/* binding */ WEB3_NETWORKWAR)
});

// UNUSED EXPORTS: CHAIN_ID, CONTRACTS, CONTRACTS_SPECIES, IPFS, NETWORK_MAINNET, PAIRS, PRODUCTION, ROUTER_METHODS, TOKENS, URL, URL_EXPLORER, URL_WAR

;// CONCATENATED MODULE: ./config/constants/contracts.js
/**
 * @MAINNETCONTRACT
 */ const contracts_MOON_CONTRACT = {
    swap: "0xbd651583D386e9F3b3C1c026a57C18A57ee03cC5",
    swapRouter: "0xe6FE3Db4c5A2e4a9Ab3301201b38724E578B35cA",
    war: "0x41F4aF9A89bcFd3e2747c59b4E83F04713B0106B",
    factory: "0xf36AE63d89983E3aeA8AaaD1086C3280eb01438D",
    firutopics: "0x1D7A2C9345E25aBab6e2Ce11A4D03E66D05f79F7",
    founders: "0xfb736292fB3A47961926ac3c47A65Ea28fFc18a4"
};
const MOON_CONTRACT_WAR = {
    Administrators: "0xf18Ee3ADE88C92C0BA487392B673a3d4aF069FCe",
    Cost: "0x56F2948531FA1b326787585853efF932a8Cc0927",
    RegisteringEntities: "0xc777AA93438541e640c715e689773257b99406F7",
    UsersSystem: "0x927627a7f24ad598ab6dBbC041121e3e9532698E",
    Search: "0xeeFA2A8513DD7BFA8271f1fa94916F491D14EC78",
    Bridge: "0xc83141E594720Ae218bB40eA6e4867d7b78b16D5",
    Crud: "0x0d6B62c82496bCbEebF1E42fD0dA50ed590c3Aa4"
};
const contracts_MOON_CONTRACT_SPECIES = {
    DOG: "0xe770b6DfBe56Fc46228057c89FFeEa028ccE4A70",
    CAT: "0xbc89d7eaf25282C0E5255EED6A28311fDDeC5F70"
};
/**
 * @TESNETCONTRACT
 */ const contracts_TESNET_CONTRACT = {
    swap: "0x550Ec97e3958cCACE6d268E66e350280e7561a2e",
    swapRouter: "0xaac55436adC045E14163e700D9d668F79F9a3800",
    factory: "0x126511DD37320B8BEFD50C6d393678714d56742C",
    firutopics: "0xd7A226F9D4db826Dc9c91700e773E6E1d86446Ca",
    founders: "0xE09C2CBd4Ff7326D0e656061D502cec20EBeb4EE",
    war: "0x41F4aF9A89bcFd3e2747c59b4E83F04713B0106B"
};
const TESNET_CONTRACT_WAR = {
    Administrators: "0x9F8f2ea631Bc08437679D03B28987BE8Ebe5fc3E",
    Cost: "0xa8E2526927536Ac0cDC1Cd49394b542dd6Ce6e36",
    RegisteringEntities: "0xd96b9e8C8Ad2eCF9C60A8956630b6057bc0d15d1",
    UsersSystem: "0x7fa2C7CC74eC86C21f585045553b50acd6E694ed",
    Search: "0x28ed7c139a83Fd9bdBa1326A940EE7F54e969B75",
    Bridge: "0x4e5CE6913CFc64d9aC907ddb66FaebBC5cE386E6",
    Crud: "0x5703d36545eF77032eD7aad49723B493f5517351"
};
const contracts_TESNET_CONTRACT_SPECIES = {
    DOG: "0x9115f4429756A7c5d093ef5878D7c4490ef3dd74",
    CAT: "0xFAC5140eCd75492AC77D89cc42ef3356577ce5c7"
};

;// CONCATENATED MODULE: ./config/constants/endpoints.js
const endpoints_URL_MAINET = "https://firulaixcoin.finance/";
const URL_TESNET = "http://localhost:3000/";
const endpoints_URL_WAR_MAINET = "https://firulaixcoin.finance/";
const endpoints_URL_WAR_TESNET = "https://test.firulaixcoin.finance/";
const endpoints_URL_EXPLORER_MAINET = "https://moonriver.moonscan.io/";
const endpoints_URL_EXPLORER_TESNET = "https://moonbase.moonscan.io/";
const endpoints_IPFS_MAINET = "https://gateway.pinata.cloud/ipfs/";
const endpoints_IPFS_TESNET = "https://gateway.pinata.cloud/ipfs/";
const API_MAINET = {
    firulaix: "https://firuapi1.firulaixcoin.finance/api/",
    firulaixPublic: "https://firuapi1.firulaixcoin.finance/",
    war: "https://firu.alejandroaguilar.dev/api/"
};
const API_TESNET = {
    firulaix: "https://firuapi1.firulaixcoin.finance/api/",
    firulaixPublic: "https://firuapi1.firulaixcoin.finance/",
    war: "https://firuTestnet.alejandroaguilar.dev/api/"
};

;// CONCATENATED MODULE: ./config/constants/methodsSwap.js
const methodsSwap_METHODS_MAINET = {
    swapExactTokensForTokens: "swapExactTokensForTokens",
    swapExactNativeCurrencyForTokens: "swapExactNativeCurrencyForTokens",
    swapExactTokensForNativeCurrency: "swapExactTokensForNativeCurrency"
};
const methodsSwap_METHODS_TESNET = {
    swapExactTokensForTokens: "swapExactTokensForTokens",
    swapExactNativeCurrencyForTokens: "swapExactETHForTokens",
    swapExactTokensForNativeCurrency: "swapExactTokensForETH"
};

;// CONCATENATED MODULE: ./config/constants/pair.js
const pair_PAIRS_MAINNET = {
    DAI_MOVR: {
        pair: "0x73Be3000E4331F099F6ad148dCEAf3C865d1b7F8",
        token0: "0x80A16016cC4A2E6a2CACA8a4a498b1699fF0f844"
    },
    FIRU_MOVR: {
        pair: "0x1010265d890Bbcb18D0267CE5A33a1e39d1c4e4A",
        token0: "0x2FBE6b6F1e3e2EFC69495F0c380A01c003e47225"
    },
    MOVR_USDC: {
        pair: "0x042e54B2B28265A7cE171F97391334BD47FE384C",
        token0: "0x98878B06940aE243284CA214f92Bb71a2b032B8A"
    },
    MOVR_USDT: {
        pair: "0x12a815a6494Fa88db3389F097EEF2B1Dc01BeB49",
        token0: "0x98878B06940aE243284CA214f92Bb71a2b032B8A"
    },
    BUSD_MOVR: {
        pair: "0x6F36585d6abd63cb63Bb0863A20028ea8E0f4a95",
        token0: "0x5D9ab5522c64E1F6ef5e3627ECCc093f56167818"
    },
    ZLK_MOVR: {
        pair: "0xee2f7c7c92a5D3dcE94c1854a0be7d21D99CFA71",
        token0: "0x0f47ba9d9Bde3442b42175e51d6A367928A1173B"
    },
    BNB_MOVR: {
        pair: "0xe9f385940F341A06DC048558CB6a7835130FBA3F",
        token0: "0x2bF9b864cdc97b08B6D79ad4663e71B8aB65c45c"
    },
    MOVR_xcRMRK: {
        pair: "0x7bB381ccE526BBa5dc4841B6F7950d9024636508",
        token0: "0x98878B06940aE243284CA214f92Bb71a2b032B8A"
    },
    MOVR_xcKSM: {
        pair: "0x61F8c893c458b2E89dF98C4ddcb67BfF59D6960c",
        token0: "0x98878B06940aE243284CA214f92Bb71a2b032B8A"
    },
    FIRU_USDC: {
        pair: "0x2Cc4c7D5aaB47bF4D3E70299690AAcd0dC43d0eD",
        token0: "0x2FBE6b6F1e3e2EFC69495F0c380A01c003e47225"
    },
    MOVR_xcKINT: {
        pair: "0xe7Ed65F8eA198AdB2B890c6797022f341bB5D425",
        token0: "0x98878B06940aE243284CA214f92Bb71a2b032B8A"
    },
    DAI_USDC: {
        pair: "0xfE2076A723C76F3F3b30d6D6977c6AeAA435FDFb",
        token0: "0x80A16016cC4A2E6a2CACA8a4a498b1699fF0f844"
    },
    BUSD_USDC: {
        pair: "0x16cBa1cF7278885b5a7df5e4E70E1845D695962C",
        token0: "0x5D9ab5522c64E1F6ef5e3627ECCc093f56167818"
    },
    ETH_USDC: {
        pair: "0x23FA9fA6ea199efEc986cF90D3740C01a6033ac9",
        token0: "0x639A647fbe20b6c8ac19E48E2de44ea792c62c5C"
    },
    WBTC_USDC: {
        pair: "0x8F917C1E86d978320cA0271E06f0db2163e31739",
        token0: "0x6aB6d61428fde76768D7b45D8BFeec19c6eF91A8"
    },
    BNB_USDC: {
        pair: "0x90DAB1c00a4474AaCA891ba70dc926E104cE4fe3",
        token0: "0x2bF9b864cdc97b08B6D79ad4663e71B8aB65c45c"
    },
    USDC_xcKSM: {
        pair: "0x1caAF75Ef37b6B96676beA6BcEA04FFd201e8e1f",
        token0: "0xE3F5a90F9cb311505cd691a46596599aA1A0AD7D"
    },
    ZLK_USDC: {
        pair: "0xf0a04c05fe6ff6D52F4Ff04C1B53857A2A48A9Fc",
        token0: "0x0f47ba9d9Bde3442b42175e51d6A367928A1173B"
    },
    USDT_USDC: {
        pair: "0x83E73CC91f6dAC35812ceB5f3da42cF57F33b4eE",
        token0: "0xB44a9B6905aF7c801311e8F4E76932ee959c663C"
    },
    ETH_MOVR: {
        pair: "0x92b8ccDcd31a3343E77d6F9e717A43D12a2EC7a6",
        token0: "0x639A647fbe20b6c8ac19E48E2de44ea792c62c5C"
    },
    BNB_BUSD: {
        pair: "0x6EB2e1b2e65Bac71DF0E24D27618cE0bb54B391a",
        token0: "0x2bF9b864cdc97b08B6D79ad4663e71B8aB65c45c"
    },
    vETH_ETH: {
        pair: "0xd0A57f59A7Ff9CB61e64feFc987245FfB1f963EA",
        token0: "0x3b25BC1dC591D24d60560d0135D6750A561D4764"
    },
    xcKSM_xcRMRK: {
        pair: "0x5B03F7c33a297afB2F2530B92ABC81d6368306Bf",
        token0: "0xFfFFfFff1FcaCBd218EDc0EbA20Fc2308C778080"
    }
};
const pair_PAIRS_TESTNET = {
    MOVR_USDC: {
        pair: "0xFA023C442B0AeE4D13d61e54bc480AC0D41A2577",
        token0: "0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715"
    },
    MOVR_ETH: {
        pair: "0x1D27fdf324714bd966Aa6bfed01619D66166855E",
        token0: "0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715"
    },
    USDC_FIRU: {
        pair: "0xDb0fdac3cA02117BA80aF599CE973a10f43a886b",
        token0: "0x4b5ad0a6bC440F0Fd8a445359d6BB2d921734cdE"
    },
    MOVR_ZLK: {
        pair: "0x1D27fdf324714bd966Aa6bfed01619D66166855E",
        token0: "0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715"
    },
    MOVR_xcRMRK: {
        pair: "0xd29147c31FD077F658a1A155bAbf65A5c2240411",
        token0: "0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715"
    },
    DAI_USDC: {
        pair: "0x58CFf98aDADBfAdDF5B7219D62c06bFb454e2c11",
        token0: "0x0Ec449159B39e2df3154A0D01cdfB8C1111bDBE8"
    },
    USDC_ETH: {
        pair: "0x7D93A13A6993487d16597B986f346c4631E3937f",
        token0: "0x4b5ad0a6bC440F0Fd8a445359d6BB2d921734cdE"
    },
    USDC_ZLK: {
        pair: "0x7D93A13A6993487d16597B986f346c4631E3937f",
        token0: "0x4b5ad0a6bC440F0Fd8a445359d6BB2d921734cdE"
    },
    USDC_WBTC: {
        pair: "0x8f50DEF25bAA41d8342fC7D03f2e163ffB97B0a6",
        token0: "0x4b5ad0a6bC440F0Fd8a445359d6BB2d921734cdE"
    },
    USDT_BUSD: {
        pair: "0xDb39d80B1caDF46a89fdDfb09651ca389300BAfA",
        token0: "0xBb5fa19E007086f3b9875387960FB1E80E4EF892"
    }
};

;// CONCATENATED MODULE: ./config/constants/tokens.js
const TOKEN_ARRAY = (/* unused pure expression or super */ null && ([
    "MOVR",
    "FIRU",
    "USDC",
    "DAI",
    "BUSD",
    "USDT",
    "ETH",
    "BNB",
    "WBTC",
    "ZLK",
    "vETH",
    "xcKSM",
    "xcRMRK",
    "xcKINT",
    "xcKAR", 
]));
const tokens_TOKEN_MAINNET = {
    MOVR: {
        type: "crypto",
        address: "0x98878b06940ae243284ca214f92bb71a2b032b8a",
        symbol: "MOVR",
        decimals: 18,
        image: ""
    },
    FIRU: {
        type: "token",
        address: "0x2fbe6b6f1e3e2efc69495f0c380a01c003e47225",
        symbol: "FIRU",
        decimals: 8,
        image: "https://raw.githubusercontent.com/zenlinkpro/assets/master/blockchains/moonriver/assets/0x2FBE6b6F1e3e2EFC69495F0c380A01c003e47225/logo.png"
    },
    USDC: {
        type: "token",
        address: "0xE3F5a90F9cb311505cd691a46596599aA1A0AD7D",
        symbol: "USDC",
        decimals: 6,
        image: "https://raw.githubusercontent.com/zenlinkpro/assets/master/blockchains/moonriver/assets/0xE3F5a90F9cb311505cd691a46596599aA1A0AD7D/logo.png"
    },
    DAI: {
        type: "token",
        address: "0x80A16016cC4A2E6a2CACA8a4a498b1699fF0f844",
        symbol: "DAI",
        decimals: 18,
        image: ""
    },
    BUSD: {
        type: "token",
        address: "0x5D9ab5522c64E1F6ef5e3627ECCc093f56167818",
        symbol: "BUSD",
        decimals: 18,
        image: ""
    },
    USDT: {
        type: "token",
        address: "0xB44a9B6905aF7c801311e8F4E76932ee959c663C",
        symbol: "USDT",
        decimals: 6,
        image: ""
    },
    ETH: {
        type: "token",
        address: "0x639A647fbe20b6c8ac19E48E2de44ea792c62c5C",
        symbol: "ETH",
        decimals: 18,
        image: ""
    },
    BNB: {
        type: "token",
        address: "0x2bF9b864cdc97b08B6D79ad4663e71B8aB65c45c",
        symbol: "BNB",
        decimals: 18,
        image: ""
    },
    WBTC: {
        type: "token",
        address: "0x6aB6d61428fde76768D7b45D8BFeec19c6eF91A8",
        symbol: "WBTC",
        decimals: 8,
        image: ""
    },
    ZLK: {
        type: "token",
        address: "0x0f47ba9d9Bde3442b42175e51d6A367928A1173B",
        symbol: "ZLK",
        decimals: 18,
        image: ""
    },
    vETH: {
        type: "token",
        address: "0x3b25BC1dC591D24d60560d0135D6750A561D4764",
        symbol: "vETH",
        decimals: 18,
        image: ""
    },
    xcKSM: {
        type: "token",
        address: "0xFfFFfFff1FcaCBd218EDc0EbA20Fc2308C778080",
        symbol: "xcKSM",
        decimals: 12,
        image: ""
    },
    xcRMRK: {
        type: "token",
        address: "0xffffffFF893264794d9d57E1E0E21E0042aF5A0A",
        symbol: "MOVR",
        decimals: 10,
        image: ""
    },
    xcKINT: {
        type: "token",
        address: "0xfffFFFFF83F4f317d3cbF6EC6250AeC3697b3fF2",
        symbol: "MOVR",
        decimals: 12,
        image: ""
    },
    xcKAR: {
        type: "token",
        address: "0xFfFFFFfF08220AD2E6e157f26eD8bD22A336A0A5",
        symbol: "xcKINT",
        decimals: 12,
        image: ""
    }
};
const tokens_TOKEN_TESTNET = {
    MOVR: {
        type: "crypto",
        address: "0x1436aE0dF0A8663F18c0Ec51d7e2E46591730715",
        symbol: "MOVR",
        decimals: 18,
        image: ""
    },
    FIRU: {
        type: "token",
        address: "0xcBD619e2A77182353dbAe59000275C7c81d6f615",
        symbol: "FIRU",
        decimals: 8,
        image: "https://raw.githubusercontent.com/zenlinkpro/assets/master/blockchains/moonriver/assets/0x2FBE6b6F1e3e2EFC69495F0c380A01c003e47225/logo.png"
    },
    USDC: {
        type: "token",
        address: "0x4b5ad0a6bC440F0Fd8a445359d6BB2d921734cdE",
        symbol: "USDC",
        decimals: 18,
        image: "https://raw.githubusercontent.com/zenlinkpro/assets/master/blockchains/moonriver/assets/0xE3F5a90F9cb311505cd691a46596599aA1A0AD7D/logo.png"
    },
    DAI: {
        type: "token",
        address: "0x0Ec449159B39e2df3154A0D01cdfB8C1111bDBE8",
        symbol: "DAI",
        decimals: 18,
        image: ""
    },
    BUSD: {
        type: "token",
        address: "0xC4f73f347699f4dd24Cdc353f891940094B88925",
        symbol: "BUSD",
        decimals: 18,
        image: ""
    },
    USDT: {
        type: "token",
        address: "0xBb5fa19E007086f3b9875387960FB1E80E4EF892",
        symbol: "USDT",
        decimals: 6,
        image: ""
    },
    ETH: {
        type: "token",
        address: "0x744eB7c95eCe05B849e84c45A3574e943EeF665B",
        symbol: "ETH",
        decimals: 18,
        image: ""
    },
    BNB: {
        type: "token",
        address: "0xf266a0B8d779d7B756BA288E2315a7eeEB644032",
        symbol: "BNB",
        decimals: 18,
        image: ""
    },
    WBTC: {
        type: "token",
        address: "0xFfFFfFff1FcaCBd218EDc0EbA20Fc2308C778080",
        symbol: "WBTC",
        decimals: 0,
        image: ""
    },
    ZLK: {
        type: "token",
        address: "0x744eB7c95eCe05B849e84c45A3574e943EeF665B",
        symbol: "ZLK",
        decimals: 18,
        image: ""
    },
    vETH: {
        type: "token",
        address: "",
        symbol: "vETH",
        decimals: 18,
        image: ""
    },
    xcKSM: {
        type: "token",
        address: "",
        symbol: "xcKSM",
        decimals: 12,
        image: ""
    },
    xcRMRK: {
        type: "token",
        address: "0xFFffffFfd2aaD7f60626608Fa4a5d34768F7892d",
        symbol: "MOVR",
        decimals: 10,
        image: ""
    },
    xcKINT: {
        type: "token",
        address: "",
        symbol: "MOVR",
        decimals: 12,
        image: ""
    },
    xcKAR: {
        type: "token",
        address: "",
        symbol: "xcKINT",
        decimals: 12,
        image: ""
    }
};

;// CONCATENATED MODULE: ./config/constants/networks.js
const NETWORKS = {
    mainnet: {
        chainId: `0x${Number(1285).toString(16)}`,
        chainName: "Moonriver",
        nativeCurrency: {
            name: "Moonriver",
            symbol: "MOVR",
            decimals: 18
        },
        rpcUrls: [
            "https://rpc.moonriver.moonbeam.network"
        ],
        blockExplorerUrls: [
            "https://moonriver.moonscan.io/"
        ],
        iconUrls: [
            "https://raw.githubusercontent.com/zenlinkpro/assets/master/blockchains/moonriver/assets/0x98878B06940aE243284CA214f92Bb71a2b032B8A/logo.png", 
        ]
    },
    testnet: {
        chainId: `0x${Number(1287).toString(16)}`,
        chainName: "Moombeam Alpha",
        nativeCurrency: {
            name: "DEV",
            symbol: "DEV",
            decimals: 18
        },
        rpcUrls: [
            "https://rpc.api.moonbase.moonbeam.network"
        ],
        blockExplorerUrls: [
            "https://moonbase.moonscan.io"
        ]
    }
};
const WEB3_NETWORK_MAINNET = "https://moonriver.api.onfinality.io/rpc?apikey=4cc1072b-afe8-4d8d-b11b-53b298e6e6bc";
const WEB3_NETWORK_TESTNET = "https://moonbeam-alpha.api.onfinality.io/rpc?apikey=4cc1072b-afe8-4d8d-b11b-53b298e6e6bc";
const WEB3_NETWORKWAR_MAINNET = "https://moonriver.blastapi.io/f2852ea6-ff68-4a6b-a159-0c870b206601";
const networks_CHAIN_ID_MAINNET = `0x${Number(1285).toString(16)}`;
const networks_CHAIN_ID_TESTNET = `0x${Number(1287).toString(16)}`; // export interface INativeCurrency {
 // 	name: string;
 // 	symbol: string;
 // 	decimals: number;
 // }
 // export interface INetwork {
 // 	chainId: string;
 // 	chainName: string;
 // 	nativeCurrency: INativeCurrency;
 // 	rpcUrls: string[];
 // 	blockExplorerUrls: string[];
 // 	iconUrls: string[];
 // }
 // export interface INetworks {
 // 	mainnet: INetwork;
 // 	testnet: INetwork;
 // }

;// CONCATENATED MODULE: ./config/index.js






/**
 * @ENTORNO
 */ const PRODUCTION = true;
/**
 * @NETWORKS
 * @BLOCKCHAIN
 */ const CHAIN_ID = (/* unused pure expression or super */ null && (PRODUCTION ? CHAIN_ID_MAINNET : CHAIN_ID_TESTNET));
const NETWORK_MAINNET = (/* unused pure expression or super */ null && (PRODUCTION ? "mainnet" : "testnet"));
const WEB3_NETWORK = PRODUCTION ? WEB3_NETWORK_MAINNET : WEB3_NETWORK_TESTNET;
const WEB3_NETWORKWAR = PRODUCTION ? WEB3_NETWORKWAR_MAINNET : WEB3_NETWORK_TESTNET;
/**
 * @CONTRACTS
 * @ABI
 * @TOKENS
 */ const CONTRACTS = (/* unused pure expression or super */ null && (PRODUCTION ? MOON_CONTRACT : TESNET_CONTRACT));
const CONTRACTS_WAR = PRODUCTION ? MOON_CONTRACT_WAR : TESNET_CONTRACT_WAR;
const CONTRACTS_SPECIES = (/* unused pure expression or super */ null && (PRODUCTION ? MOON_CONTRACT_SPECIES : TESNET_CONTRACT_SPECIES));
const ROUTER_METHODS = (/* unused pure expression or super */ null && (PRODUCTION ? METHODS_MAINET : METHODS_TESNET));
const TOKENS = (/* unused pure expression or super */ null && (PRODUCTION ? TOKEN_MAINNET : TOKEN_TESTNET));
const PAIRS = (/* unused pure expression or super */ null && (PRODUCTION ? PAIRS_MAINNET : PAIRS_TESTNET));
/**
 * @ENDPOINTS
 */ const URL = (/* unused pure expression or super */ null && (PRODUCTION ? URL_MAINET : URL_MAINET));
const URL_WAR = (/* unused pure expression or super */ null && (PRODUCTION ? URL_WAR_MAINET : URL_WAR_TESNET));
const URL_EXPLORER = (/* unused pure expression or super */ null && (PRODUCTION ? URL_EXPLORER_MAINET : URL_EXPLORER_TESNET));
const API = PRODUCTION ? API_MAINET : API_TESNET;
const IPFS = (/* unused pure expression or super */ null && (PRODUCTION ? IPFS_MAINET : IPFS_TESNET));


/***/ }),

/***/ 3918:
/***/ ((__unused_webpack_module, __webpack_exports__, __webpack_require__) => {

/* harmony export */ __webpack_require__.d(__webpack_exports__, {
/* harmony export */   "S": () => (/* binding */ Web3Context)
/* harmony export */ });
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0__ = __webpack_require__(6689);
/* harmony import */ var react__WEBPACK_IMPORTED_MODULE_0___default = /*#__PURE__*/__webpack_require__.n(react__WEBPACK_IMPORTED_MODULE_0__);

const INIT = {
    web3: null,
    handleWeb3: null,
    handleAccount: null,
    handleChainId: null,
    handleToken: null
};
const Web3Context = /*#__PURE__*/ (0,react__WEBPACK_IMPORTED_MODULE_0__.createContext)(INIT);


/***/ })

};
;