import DOG from "../../../public/Json/race/Dogs.json";
import CAT from "../../../public/Json/race/Cats.json";

export const racesJson = {
  DOG,
  CAT,
};
