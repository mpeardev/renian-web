export default function Contact() {
  return (
    <>
      <h1>Contact Page</h1>
      <p>This is Contact page</p>
    </>
  );
}
