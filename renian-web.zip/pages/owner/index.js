export default function Owner() {
  return (
    <>
      <h1>Owner Page</h1>
      <p>This is Owner page</p>
    </>
  );
}
