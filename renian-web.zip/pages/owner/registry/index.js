export default function OwnerRegistry() {
  return (
    <>
      <h1>Owner Registry Page</h1>
      <p>This is Owner Registry page</p>
    </>
  );
}
