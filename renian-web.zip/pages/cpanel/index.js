import { CPanelView } from "../../components";

export default function CPanel() {
  return <CPanelView />;
}
