export default function News() {
  return (
    <>
      <h1>News Page</h1>
      <p>This is News page</p>
    </>
  );
}
