export default function Questions() {
  return (
    <>
      <h1>Questions Page</h1>
      <p>This is Questions page</p>
    </>
  );
}
