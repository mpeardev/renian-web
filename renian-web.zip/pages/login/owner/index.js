import { OwnerLoginView } from "../../../components";

export default function LoginOwner() {
	return <>{/* <OwnerLoginView />; */}</>;
}
