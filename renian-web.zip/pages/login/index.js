import { LoginView } from "../../components";

export default function Login() {
  return <LoginView />;
}
